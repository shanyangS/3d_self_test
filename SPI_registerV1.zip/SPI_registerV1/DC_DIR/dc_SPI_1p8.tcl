reset_design 
remove_design
define_design_lib WORK -path ./work
set_host_options -max_cores 8
set proj_path "/home/zhangli_eda/Project/ONC18-2022/SPI_digital/"
set output_dir "$proj_path/DC_DIR/OUT/1p8"
#set cell_path "/home/andy/foundry/ONSEMI18/onc18/ddk/core/stdcell/liberty/onnn180cxoscu/Rev2.004"
set cell_path "$proj_path/DC_DIR/LIBS/1p8"
#set io_path "/home/andy/foundry/SMIC.11/IO/SPC011D3RP_V0p3d/syn/1p8v"
#set ram_path "$proj_path/RAM_IP"
set rtl_path "$proj_path/VCODE"
set syn_path [list /opt/synopsys/syn/O-2018.06-SP1/libraries/syn /opt/synopsys/syn/O-2018.06-SP1/minpower/syn /opt/synopsys/syn/O-2018.06-SP1/dw/syn_ver /opt/synopsys/syn/O-2018.06-SP1/dw/sim_ver ]
set synthetic_library /opt/synopsys/syn/O-2018.06-SP1/libraries/syn/dw_foundation.sldb
set search_path [concat $syn_path \
 $cell_path \
 $rtl_path \
 ];
  # $io_path \
 # $ram_path/S011HD1P_X256Y2D73 \
 # $ram_path/S011HDDP_X128Y4D64_BW \
 # $rtl_path/top \
 # $rtl_path/axi \
 # $rtl_path/cpu \
 # $rtl_path/dw_i2c \
 # $rtl_path/dw_uart \
 # $rtl_path/ram \
 # $rtl_path/sd_IPs \
 # $rtl_path/spi_debug_api \
 # $rtl_path/spi_flash_ip \
 # $rtl_path/tci_dma
set target_path [list  $cell_path ]
#########get link files#############
set linkfile ""
foreach dir_link $search_path {
  set linkfile [concat $linkfile [concat [glob -nocomplain $dir_link/*.db]]]
}
#########get target files############# //*_ss_1.08v_85c
set targetfile ""
foreach tar_dir $target_path {
  set targetfile [concat $targetfile [concat [glob -nocomplain $tar_dir/*_1.7v_125c.db]]]
}
###############set library
set link_library  " * $linkfile $synthetic_library"
   
set target_library  $targetfile

#set symbol_library [list /home/andy/foundry/SMIC.11/std_cell/UHD/SCC011UMS_UHD_RVT_V1p0/symbol/scc011ums_uhd_rvt.sdb \ ]
#########get verilog files#############
set dirs [glob -nocomplain -join -type d -directory $rtl_path *]
set vfile ""
foreach dir $dirs {
  set vfile [concat $vfile [concat [glob -nocomplain $dir/*.v]]]
}

analyze -library WORK -format verilog $vfile

set TOP_NAME "spi_top"

elaborate $TOP_NAME -architecture verilog -library WORK

link
current_design $TOP_NAME
uniquify

#check_design
##################################################
#   set operating conditions
##################################################
#set_operating_conditions -min_library onnn180cxoscu_ff_1.32v_m10c -min ff_1.32v_m10c  -max_library onnn180cxoscu_ss_1.08v_85c -max ss_1.08v_85c
set_operating_conditions -min_library onnn180cxoscu_ff_1.8v_25c -min ff_1.8v_25c  -max_library onnn180cxoscu_ss_1.7v_125c -max ss_1.7v_125c
##################################################
#   set wire load model
##################################################
#set_wire_load_model -name enG50K -library fsh0l_ers_generic_core_ss0p99v125c
set_app_var auto_wire_load_selection true
#set_zero_interconnect_delay_mode true
#set_wire_load_model -name 100000 -library onnn180cxoscu_wlm
set_wire_load_model -name zero -library onnn180cxoscu_wlm
##################################################
#   clock
##################################################
create_clock -name "clk_50" -period 20 -waveform { 0 10  }  [get_ports clk  ] ; #700M=1.43   600M=1.5
set_clock_latency 1 [get_clocks clk_50]
set_clock_uncertainty -setup 1 [get_clocks clk_50]
set_clock_transition 1 [get_clocks clk_50]
set_dont_touch_network {clk}
set_ideal_network {clk}

##################################################
#   set reset or false pins
##################################################
set_false_path -from [get_ports rst_n]


##################################################
#   delay
################################################## 
set input_pins_pad [get_ports {SPI_CLK SPI_MOSI SPI_SS}]
set output_pins_pad [get_ports {SPI_MISO}]

set input_pins [get_ports {status_i}]
set output_pins [get_ports {control_o}]

set_input_delay -clock clk_50 -max 5  $input_pins_pad
set_input_delay -add_delay -clock clk_50 -min 3  $input_pins_pad

set_output_delay -clock clk_50 -max 5  $output_pins_pad
set_output_delay -add_delay -clock clk_50  -min 3  $output_pins_pad

set_input_delay -clock clk_50 -max 5  $input_pins
set_input_delay -add_delay -clock clk_50 -min 3  $input_pins

set_output_delay -clock clk_50 -max 5  $output_pins
set_output_delay -add_delay -clock clk_50  -min 3  $output_pins




# ##################################################
# #   set drive
# ##################################################
set all_in_ex_clk [remove_from_collection [all_inputs] [list [get_ports {clk}]]]
set all_out_ex_clk [remove_from_collection [all_outputs] [list [get_ports {clk}]]]
set_input_transition 0.5 $all_in_ex_clk
set_drive 0.5 $all_in_ex_clk ;  # resistant=0.05 omg

##################################################
#   set load
##################################################
set MAX_LOAD [expr [load_of onnn180cxoscu_ss_1.08v_85c/bufx1_u/A]*10]
#set MAX_LOAD 0.0055

set_max_capacitance $MAX_LOAD $all_in_ex_clk
set_load [expr $MAX_LOAD * 10] [all_outputs]

set_max_area 0

#check_timing
#check_design
##################################################
#   compile
################################################## 
#compile -scan
#compile_ultra
compile -map_effort low

#compile -map_effort high -incremental_mapping 




write -format verilog -hierarchy -output $output_dir/$TOP_NAME.netlist.v
write_sdc $output_dir/$TOP_NAME.sdc
write -hierarchy -output $output_dir/$TOP_NAME.db
file delete $output_dir/area.report
file delete $output_dir/power.report
file delete $output_dir/timing.report
file delete $output_dir/violators.report
uplevel #0 { report_area -hierarchy } >> $output_dir/area.report

uplevel #0 { report_power -analysis_effort low } >> $output_dir/power.report

file delete $output_dir/timing.report
#uplevel #0 { report_timing -path full -delay max -nworst 10 -max_paths 10 -significant_digits 2 -sort_by slack } >> $output_dir/timing.report

uplevel #0 { report_timing -path full -delay max -nworst 10 -max_paths 10 -input -net -trans -cap -nosplit -cross  -sig 5 -sort_by slack } >> $output_dir/timing.report

uplevel #0 { report_constraint -all_violators -significant_digits 2 } >> $output_dir/violators.report

write_sdf $output_dir/$TOP_NAME.sdf




############# process netlist eco
#dc_shell_is_in_incr_mode
#read_verilog -netlist $output_dir/SOCio.sv
#current_design SOCio



