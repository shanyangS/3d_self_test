
#define_design_lib WORK -path ./work
set op_level 1p2  
# or 1p8
set_host_options -max_cores 8
set proj_path "/home/zhangli_eda/Project/ONC18-2022/SPI_digital"
set cell_path "$proj_path/DC_DIR/LIBS/$op_level"
set rtl_path "$proj_path/VCODE"
set syn_path [list /opt/synopsys/syn/O-2018.06-SP1/libraries/syn /opt/synopsys/syn/O-2018.06-SP1/minpower/syn /opt/synopsys/syn/O-2018.06-SP1/dw/syn_ver /opt/synopsys/syn/O-2018.06-SP1/dw/sim_ver ]
set synthetic_library /opt/synopsys/syn/O-2018.06-SP1/libraries/syn/dw_foundation.sldb
set search_path [concat $syn_path \
 $cell_path \
 $rtl_path \
 ];
# TOP LEVEL DESIGN NAMES 
#--------------------------------------------------------------------------- 
set DESIGN_NAME                   "spi_top"  ;#  The name of the top-level design. ;#
#PRIME TIME  SEARCH PATHS AND TARGET LIBRARIES
#########get db files#############
set ff_file ""
foreach temp_dir $search_path {
  set ff_file [concat $ff_file [concat [glob -nocomplain $temp_dir/*_ff_*.db]]]
}

set ss_file ""
foreach temp_dir $search_path {
  set ss_file [concat $ss_file [concat [glob -nocomplain $temp_dir/*_ss_*.db]]]
}

set tt_file ""
foreach temp_dir $search_path {
  set tt_file [concat $ss_file [concat [glob -nocomplain $temp_dir/*_tt_*.db]]]
}

if {$op_level == "1p8"}  \
  { set TARGET_LIBRARY_FILES onnn180cxoscu_ss_1.7v_125c.db} \
else  \
  {set TARGET_LIBRARY_FILES onnn180cxoscu_ss_1.08v_85c.db }
  #  Target technology logical libraries ;#
  #onnn180cxoscu_ff_1.32v_m10c
  #onnn180cxoscu_ff_1.8v_25c
# 


# Report and Results directories 
#------------------------------------------ 

set REPORTS_DIR "reports_postPR" ;#
file mkdir $REPORTS_DIR ;#

################################################################################# 
# Library Setup 
################################################################################# 
set target_library $TARGET_LIBRARY_FILES ;#
set link_library "* $tt_file" ;

#################################### 
# Common Setup Variables 
#################################### 

set cache_read  {} ;#
set cache_write {} ;#
set allow_newer_db_files       true ;#
set write_compressed_db_files  true ;#
set sh_source_uses_search_path true ;#

#################################### 
# Common design files 
#################################### 
#VERILOG DESIGN FILE
# The name of Verilog netlist file. ---Example "cpu.v.gz" 
set NETLIST_FILE		"$proj_path/PR_DIR/run_dir/OUT/$op_level/spi_top.v" ;#
#CONSTRAINT FILE
set CONSTRAINT_FILE	 "$proj_path/PT_rundir/spi_top_pt.sdc" ;#

#PARASITICS FILE 
#There are many parasitic formats. But SPEF is the common one
#The name of the SPEF file. --- Example "cpu.spef.gz" 
set SPEF_FILE	 "$proj_path/PR_DIR/run_dir/OUT/$op_level/spi_top.spef" ;#

################################################################################# 
# Required Variables 
#Variables need to be defined first. Because some variables will trigger update_timing 
#this will help run time. 
################################################################################# 

#sh_continue_on_error tells PT to continue when there is an error.
#sh_script_stop_severity and sh_source_emits_line_numbers can be used to stop and report line number
set sh_continue_on_error false ;#

#sh_source_uses_search_path tells PT to use the search paths to find the appropriate files
set sh_source_uses_search_path true ;#

#svr_keep_unconnected_nets to preserve unconnected nets in PT
#This variable prevents errors during linking.
set svr_keep_unconnected_nets "true" ;#

#case_analysis_sequential_propagation is used to propagate the case. Only use if the constraints has case.
#set case_analysis_sequential_propagation "always" 

# Timing Report 
#timing_report_unconstrained_paths is used to report unconstrain paths.
#set timing_report_unconstrained_paths true 

#timing_remove_clock_reconvergence_pessimism will incur additional runtime. Set to true for final layout.
set timing_remove_clock_reconvergence_pessimism true ;#

# 
################################################################################# 
# Read in the Design 
# Use the -format option to specify:  vhdl as needed. 
################################################################################# 
#READING_VERILOG DESIGN FILE
read_verilog $NETLIST_FILE ;

#Moves to the TOP hierarchy 
current_design $DESIGN_NAME ;

#Link the design. The option remove_sub_designs is used to frre up memory and helps runtime.
link -remove_sub_designs ;#

read_db $ss_file;
################################################################################# 
# Required Variables 
# After current design and link 
################################################################################# 

#analysis_type can be bc_wc or on_chip_variation
#Using_OCV for max slew for data lauching and min slew for data capturing
#set_operating_conditions -library {fsh0l_ers_generic_core_ff1p21v0c fsh0l_ers_generic_core_ss0p99v125c} -min BCCOM -max WCCOM -analysis_type on_chip_variation;
#set_operating_conditions -min_library fsh0l_ers_generic_core_ff1p21v0c -max_library fsh0l_ers_generic_core_ss0p99v125c -analysis_type on_chip_variation;
if {$op_level == "1p8"} \
  {set_operating_conditions -min_library onnn180cxoscu_ff_1.8v_25c -max_library onnn180cxoscu_ss_1.7v_125c -analysis_type on_chip_variation} \
else \
  { set_operating_conditions -library onnn180cxoscu_tt_1.25v_25c.db }
  #{set_operating_conditions -min_library onnn180cxoscu_ff_1.32v_m10c -max_library onnn180cxoscu_ss_1.08v_85c -analysis_type on_chip_variation}
  
#set_operating_conditions -library fsh0l_ers_generic_core_tt1p1v25c;


################################################################################# 
# READ PARASITICS 
################################################################################# 
#reading Parasitics. 
#Increment option is used to read in multiples parasitics

#Do not use keep capacitive coupling for regualr PT 
read_parasitics -format spef $SPEF_FILE ;

# this command is ued to check net that has not annotated. 
#report_annotated_parasitics -internal_nets -boundary_nets -list_not_annotated -max_nets 5000 


################################################################################# 
# Apply Logical Design Constraints 
################################################################################# 
# 
#constraints template (part of PT-RM script) is provided as a user guideline

#Reading design constraint file 
source -echo -verbose $CONSTRAINT_FILE ;
#Reset_design if you want to read in another SDC

#If the SDC has load/cap. Need to remove load/cap info from the SDC. 
#otherwise it will use them and overide the SPEF. The following TCL to remove them.
#set all_nets [get_nets -hier *] 
#remove_capacitance          $all_nets 
#remove_resistance           $all_nets 
#remove_annotated_parasitics $all_nets 
#remove_annotated_delay -all 
#remove_annotated_check -all 

#timing_derate
#Margin can be added for OCV using timing derate
#set_timing_derate -early -clock 0.90 
#set_timing_derate -late -clock 1.10 

################################################################################# 
# UPDATE TIMING 
################################################################################# 

#update_timing the design with all the data
update_timing ;#
# 
################################################################################# 
# Checking The DESIGN and Constraint 
################################################################################# 
#check_timing is used to check the design for the the first timing analysis
check_timing -verbose ;#

#report_clock is used to report all clock and clock groups in the design for checking.
#report_clock 

#report cases analysis for a port or pins. This helps checking the constraints 
#report_case_analysis -all 

#report all the attributes of the design. This helps checking the design 
#report_design -nosplit 

################################################################################# 
# REPORT TIMING 
################################################################################# 
#Report on Timing 

#report_delay_calculation reports detailed timing information about library cells. 
#using report_delay_calculation -threshold to see rail voltage
#report_delay_calculation > $REPORTS_DIR/rpt_delay_calculation.dat 

#generate an overall report of all the timing check in the design. 
report_analysis_coverage -nosplit  -exclude_untested {constant_disabled} -status_details {untested} > $REPORTS_DIR/$op_level/rpt_analysis_coverage.dat ;#

#Display constraint related of the design per clock group. 
#report_constraints -all_violators -nosplit -sig 5 >  $REPORTS_DIR/rpt_constraints.dat 

#report_timing is used to report all violation paths.
report_timing -delay_type max  -nworst 10 -max_paths 100 -input -net -trans -cap -nosplit -cross -path full_clock_expanded -sig 5 >  $REPORTS_DIR/$op_level/rpt_max_timing.dat 
report_timing -delay_type min -nworst 10 -max_paths 100 -input -net -trans -cap -nosplit -cross -path full_clock_expanded -sig 5 >  $REPORTS_DIR/$op_level/rpt_min_timing.dat 
#-slack_lesser_than 0.5


# Report Bottleneck
report_bottleneck


# Report on CLOCK 

#report_clock related information for the design
#report_clock -skew -attributes >  $REPORTS_DIR/clock.dat 

#report_clock_timing is used to report timing attributes of the clock networks
#report_clock_timing -type summary >>   $REPORTS_DIR/clock.dat 
#report_clock_timing -setup -type skew >>   $REPORTS_DIR/clock.dat 
#report_clock_timing -hold  -type skew >>   $REPORTS_DIR/clock.dat 
#report_clock_timing -setup -type latency >>   $REPORTS_DIR/clock.dat 
#report_clock_timing -hold  -type latency >>   $REPORTS_DIR/clock.dat 

#report_min_pulse_width displays the minimum pulse width check info for a pin or port.
#report_min_pulse_width >>   $REPORTS_DIR/clock.dat 

#report_clock_gating_check is used to report clock gating for a pin.
#report_clock_gating_check -sig 5 >>   $REPORTS_DIR/clock.dat 
# 


# Save Session
#save_session -replace $DESIGN_NAME


# Print Message Info
print_message_info


#######################fix eco###########################
#fix_eco_timing -type hold -methods insert_buffer -hold_margin 2 -buffer_list {BUFCKLERMX0P4 BUFCKLERMX0P7 BUFCKLERMX1 BUFCKLERMX2 BUFCKLERMX3 BUFCKLERMX4 BUFCKLERMX8 BUFCKLERMX16}

#write_changes -format icctcl -output ../PT_OUT/PEwithMC_fix_eco.icctcl
#write_changes -format dctcl -output ../PT_OUT/PEwithMC_fix_eco.dctcl

#----------------------------------------------------------------------# 

quit; #


























