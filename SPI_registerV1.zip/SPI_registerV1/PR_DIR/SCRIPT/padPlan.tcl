setPinAssignMode -pinEditInBatch true


for { set pin_num 0}  {$pin_num < 192} {incr pin_num} {
    set coil_x [expr 5+$pin_num*0.56];
    set coil_y [expr $core_size+60-0.5];
    editPin -pinWidth 0.28 -pinDepth 0.5 -fixedPin 1 -snap MGRID -fixOverlap 0 -global_location -side Inside -layer 2 -assign [expr $coil_x] [expr $coil_y] -pin control_o[$pin_num];
}
  
for { set pin_num 0}  {$pin_num < 320} {incr pin_num} {
    set coil_x [expr 10+0.56*192+$pin_num*0.56];
    set coil_y [expr $core_size+60-0.5];
    editPin -pinWidth 0.28 -pinDepth 0.5 -fixedPin 1 -snap MGRID -fixOverlap 0 -global_location -side Inside -layer 2 -assign [expr $coil_x] [expr $coil_y] -pin status_i[$pin_num];
}
  

editPin -pinWidth 0.5 -pinDepth 0.5 -fixedPin 1 -snap MGRID -fixOverlap 0 -global_location -side Inside -layer 2 -assign [expr 0.3+0] [expr 20+1*0] -pin clk;
editPin -pinWidth 0.5 -pinDepth 0.5 -fixedPin 1 -snap MGRID -fixOverlap 0 -global_location -side Inside -layer 2 -assign [expr 0.3+0] [expr 20+1*1] -pin rst_n;
editPin -pinWidth 0.5 -pinDepth 0.5 -fixedPin 1 -snap MGRID -fixOverlap 0 -global_location -side Inside -layer 2 -assign [expr 0.3+0] [expr 20+1*2] -pin SPI_CLK;
editPin -pinWidth 0.5 -pinDepth 0.5 -fixedPin 1 -snap MGRID -fixOverlap 0 -global_location -side Inside -layer 2 -assign [expr 0.3+0] [expr 20+1*3] -pin SPI_SS;
editPin -pinWidth 0.5 -pinDepth 0.5 -fixedPin 1 -snap MGRID -fixOverlap 0 -global_location -side Inside -layer 2 -assign [expr 0.3+0] [expr 20+1*4] -pin SPI_MOSI;
editPin -pinWidth 0.5 -pinDepth 0.5 -fixedPin 1 -snap MGRID -fixOverlap 0 -global_location -side Inside -layer 2 -assign [expr 0.3+0] [expr 20+1*5] -pin SPI_MISO;

setPinAssignMode -pinEditInBatch false



