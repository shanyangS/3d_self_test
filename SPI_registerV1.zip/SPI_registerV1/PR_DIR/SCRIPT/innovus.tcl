set op_level 1p2
source ../INPUT/$op_level/Init.globals
init_design
setDesignMode -process 180
##############################
### load and commit IEEE1801
##############################
read_power_intent -1801 ../INPUT/$op_level/PowerDefine.1801
commit_power_intent
globalNetConnect VDD -type pgpin -pin VDD -inst *
globalNetConnect VSS -type pgpin -pin VSS -inst *

globalNetConnect VDD -type pgpin -pin VDDS -inst *
globalNetConnect VSS -type pgpin -pin VSSS -inst *

#globalNetConnect VDD -type pgpin -pin VCCNW -inst *
#verifyPowerDomain -isoNetPD
#verifyPowerDomain -xNetPD
setMultiCpuUsage -localCpu 16 -cpuPerRemoteHost 8 -remoteHost 0 -keepLicense true
setDistributeHost -local
setAnalysisMode -analysisType onChipVariation -cppr both

##############################################
set core_size 310

source ../SCRIPT/floorPlan.tcl;

source  ../SCRIPT/powerPlan.tcl;

source  ../SCRIPT/padPlan.tcl;

saveDesign DBS/$op_level/pre_sroute.enc -compress

#################
# #  Sroute 
#################

#route corePin(follow pin)
sroute -connect { corePin } -layerChangeRange {M1 M4} -blockPinTarget { nearestTarget } -corePinTarget { firstAfterRowEnd } -allowJogging 1 -crossoverViaLayerRange { M1 M4 } -nets { VSS VDD } -allowLayerChange 1 -targetViaLayerRange { M1 M4 }


saveDesign DBS/$op_level/sroute_floatingStripe.enc -compress



verifyConnectivity -nets {VDD   VSS} -type special -error 1000 -warning 50
verifyPowerDomain -isoNetPD
verifyPowerDomain -xNetPD
verifyPowerDomain -bind -gconn -isoNetPD RPT/init.isonets.rpt -xNetPD RPT/init.xnets.rpt

#################
# placement
#################
addWellTap -cell subwelltie_u -cellInterval 25 -prefix WELLTAP -powerDomain PDcore
verifyConnectivity -nets {VDD  VSS} -type special -error 1000 -warning 50
setDelayCalMode -reportOutBound true

setTrialRouteMode -maxRouteLayer M3
set delaycal_use_default_delay_limit 1000

setMultiCpuUsage -localCpu 16 -cpuPerRemoteHost 8 -remoteHost 0 -keepLicense true
setDistributeHost -local

setPlaceMode -congEffort auto -timingDriven 1 -modulePlan 1 -clkGateAware 1 -powerDriven 0 -ignoreScan 1 -reorderScan 1 -ignoreSpare 0 -placeIOPins 0 -moduleAwareSpare 0 -maxDensity 0.85 -preserveRouting 0 -rmAffectedRouting 0 -checkRoute 0 -swapEEQ 0
setPlaceMode -fp false

placeDesign

# add tie high/low

setTieHiLoMode -cell {tohx1_u tolx1_u} -maxfanout 100
addTieHiLo -powerDomain PDcore 


checkPlace

verifyPowerDomain -isoNetPD
verifyPowerDomain -xNetPD

saveDesign DBS/$op_level/place.enc -compress
verifyPowerDomain -bind -gconn -isoNetPD RPT/place.isonets.rpt -xNetPD RPT/place.xnets.rpt

##################################
# preCTS optimization (gigaOpt)
#################################
# report the available alwayBUFLERMX2s-on buffers per domain
#setOptMode -resizeShifterAndIsoInsts false
#reportAlwaysOnBuffer -all

setDontUse buf* false
setDontUse inv* false 
set_interactive_constraint_modes [all_constraint_modes -active]

set_dont_touch [get_lib_cells buf*] false
set_dont_touch [get_lib_cells inv*] false

setDontUse clkbuf* true
setDontUse clkinv* true
#setDontUse DLY* true

reportAlwaysOnBuffer -all
reportAlwaysOnBuffer -all -verbose

setLimitedAccessFeature ediUsePreRouteGigaOpt 1
setOptMode -holdTargetSlack 0 -setupTargetSlack 0.5
optDesign -preCTS -outDir RPT -prefix prects 

saveDesign DBS/$op_level/prects.enc -compress
verifyPowerDomain -bind -gconn -isoNetPD RPT/prects.isonets.rpt -xNetPD RPT/prects.xnets.rpt


#####################################
# iCTS
######################################
setMultiCpuUsage -localCpu 8 -cpuPerRemoteHost 8 -remoteHost 0 -keepLicense true
setDistributeHost -local
setAnalysisMode -analysisType onChipVariation -cppr both

setDontUse clkbuf* false
setDontUse clkinv* false
reportAlwaysOnBuffer -all


setLimitedAccessFeature ccopt_native_cts 1
set_ccopt_mode -integration native
set_ccopt_property buffer_cells {clkbuf*}
set_ccopt_property inverter_cells {clkinv*}

setNanoRouteMode -quiet -routeTopRoutingLayer 7

create_ccopt_clock_tree_spec -file ./OUT/$op_level/clock.spec
setDelayCalMode -engine AAE
ccopt_design -cts

saveDesign DBS/$op_level/cts.enc -compress
verifyPowerDomain -bind -gconn -isoNetPD RPT/cts.isonets.rpt -xNetPD RPT/cts.xnets.rpt

##########################################
# postCTS optimization (setup)
###########################################
setOptMode -holdTargetSlack 0.2 -setupTargetSlack 0.5
setAnalysisMode -cppr none
optDesign -postCTS -outDir RPT -prefix postcts
saveDesign DBS/$op_level/postcts.enc -compress
verifyPowerDomain -bind -gconn -isoNetPD RPT/postcts.isonets.rpt -xNetPD RPT/postcts.xnets.rpt

############################################
# postCTS optimization (hold)
############################################
setOptMode -holdTargetSlack 0.2 -setupTargetSlack 0.5
setDontUse DLY* false
optDesign -postCTS -hold -outDir RPT -prefix postcts_hold
saveDesign DBS/$op_level/postcts_hold.enc -compress
verifyPowerDomain -bind -gconn -isoNetPD RPT/postcts_hold.isonets.rpt -xNetPD RPT/postcts_hold.xnets.rpt

############################################
# route the design
############################################
# secondary power pin connection

setNanoRouteMode -routeStripeLayerRange 1:4
setNanoRouteMode -routeWithTimingDriven true
setNanoRouteMode -drouteUseMultiCutViaEffort medium
setNanoRouteMode -drouteFixAntenna true
setNanoRouteMode -routeAntennaCellName "antprot_u"
setNanoRouteMode -routeInsertAntennaDiode true
routeDesign
setExtractRCMode -engine postRoute

verifyConnectivity -nets {VDD VSS} -type special -error 1000 -warning 50
saveDesign DBS/$op_level/route.enc -compress
verifyPowerDomain -bind -gconn -isoNetPD RPT/route.isonets.rpt -xNetPD RPT/route.xnets.rpt

############################################
# post-route optimization  (operate by buttom,effect well)
#############################################
setMultiCpuUsage -localCpu 16 -cpuPerRemoteHost 16 -remoteHost 0 -keepLicense true
setDistributeHost -local

setEndCapMode -reset
setEndCapMode -boundary_tap false
setUsefulSkewMode -maxSkew false -noBoundary false -useCells {buf_* inv_* clkbuf_* clkinv_*} -maxAllowedDelay 1
setOptMode -effort high -leakagePowerEffort none -dynamicPowerEffort none -reclaimArea true -simplifyNetlist true -allEndPoints false -setupTargetSlack 0.5 -holdTargetSlack 0.2 -maxDensity 0.95 -drcMargin 0 -usefulSkew true
setTieHiLoMode -reset
setTieHiLoMode -cell {tohx1_u tolx1_u} -maxFanOut 100 -honorDontTouch false -createHierPort false
setOptMode -fixCap true -fixTran true -fixFanoutLoad false

setAnalysisMode -analysisType onChipVariation -cppr none

optDesign -postRoute
optDesign -postRoute -hold

saveDesign DBS/$op_level/postroute.enc -compress
verifyPowerDomain -bind -gconn -isoNetPD RPT/postroute.isonets.rpt -xNetPD RPT/postroute.xnets.rpt
verifyConnectivity -nets {VDD  VSS} -type special -error 1000 -warning 50

############################################
# post-route optimization
#############################################

#setAnalysisMode -analysisType onChipVariation -cppr none
#setDelayCalMode -siAware false
#optDesign -postRoute -outDir RPT -prefix postroute

#saveDesign DBS/$op_level/postroute1.enc -compress
#verifyPowerDomain -bind -gconn -isoNetPD RPT/postroute1.isonets.rpt -xNetPD RPT/postroute1.xnets.rpt
#verifyConnectivity -nets {VDD  VSS} -type special -error 1000 -warning 50




############################################
# post-route optimization		
#############################################
#setExtractRCMode -engine postRoute
#setAnalysisMode -analysisType onChipVariation -cppr none
#setOptMode -holdTargetSlack 0.3 -setupTargetSlack 0.5
#setDelayCalMode -siAware false
#optDesign -postRoute -outDir RPT -prefix postroute

#setOptMode -fixCap false -fixTran false -fixFanoutLoad false
#optDesign -postRoute -hold -incr

#saveDesign DBS/$op_level/postroute2.enc -compress
#verifyPowerDomain -bind -gconn -isoNetPD RPT/postroute2.isonets.rpt -xNetPD RPT/postroute2.xnets.rpt
#verifyConnectivity -nets {VDD  VSS} -type special -error 1000 -warning 50

#setOptMode -fixCap true -fixTran true -fixFanoutLoad false
#optDesign -postRoute -drv

#saveDesign DBS/$op_level/postroute_drv.enc -compress
#verifyPowerDomain -bind -gconn -isoNetPD RPT/postroute_drv.isonets.rpt -xNetPD RPT/#postroute_drv.xnets.rpt
#verifyConnectivity -nets {VDD  VSS} -type special -error 1000 -warning 50


############################################
# add filler
#############################################
addFiller -cell fill32_u fill16_u fill8_u fill4_u fill2_u  -prefix FILLER -powerDomain PDcore -doDRC
addFiller -cell fill1_u -prefix FILLER -powerDomain PDcore -doDRC

saveDesign DBS/$op_level/addFiller.enc -compress
verifyConnectivity -nets {VDD  VSS} -type special -error 1000 -warning 50

############################################
# eco-route -fixDRC 
#############################################
ecoRoute -fix_drc
saveDesign DBS/$op_level/fixDRC.enc -compress
verifyPowerDomain -bind -gconn -isoNetPD RPT/fixDRC.isonets.rpt -xNetPD RPT/fixDRC.xnets.rpt


#saveDesign DBS/$op_level/cut_logo_area.enc -compress
############################################
# output GDS
#############################################
streamOut ./OUT/$op_level/spi_top.gds -mapFile ../GDS/onc18_gdsout.map -libName top_io \
 -merge { ../GDS/onnn180cxoscu.gds } \
-outputMacros -dieAreaAsBoundary -units 1000 -mode ALL

############################################
# Extract RC 
#############################################
extractRC
rcOut -setload ./OUT/$op_level/spi_top.setload -rc_corner rc_worst
rcOut -setres ./OUT/$op_level/spi_top.setres -rc_corner rc_worst
rcOut -spf ./OUT/$op_level/spi_top_rc_worst.spf -rc_corner rc_worst
rcOut -spf ./OUT/$op_level/spi_top_rc_best.spf -rc_corner rc_best
rcOut -spef ./OUT/$op_level/spi_top.spef -rc_corner rc_worst

############################################
# write SDF
#############################################
all_hold_analysis_views 
all_setup_analysis_views 
write_sdf -view view_setup   ./OUT/$op_level/spi_top.sdf

############################################
# write netlist
#############################################
#update_names -net -map 
saveNetlist ./OUT/$op_level/spi_top.v


saveNetlist -includePowerGround ./OUT/$op_level/spi_topPG.v

saveNetlist -phys -excludeCellInst {subwelltie_u fill32_u fill16_u fill8_u fill4_u fill2_u fill1_u} ./OUT/$op_level/spi_topPG_phys.v
############################################
# fix eco
#############################################

 #selectInst  XX/instA
#zoomSelected 
#ecoAddRepeater -cell BUFLERMX16 -net {u_pe_top/fifo_filters_rd_data[14]}
#deselectAll














