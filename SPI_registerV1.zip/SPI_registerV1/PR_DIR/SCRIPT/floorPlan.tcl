##########################
# floorplan & powerplan
##########################

floorPlan -site core_scu -b 0.0 0.0 [expr $core_size+60] [expr $core_size+60] \
 0 0 [expr $core_size+60] [expr $core_size+60] \
30 30 [expr $core_size+30] [expr $core_size+30]




