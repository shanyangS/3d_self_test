
#################
# power planning
#################
addRing -skip_via_on_wire_shape Noshape -skip_via_on_pin Standardcell -stacked_via_top_layer m4t30 -type core_rings -jog_distance 3.0 -threshold 3.0 -nets {VDD VSS} -follow io -stacked_via_bottom_layer m1 -layer M4 -width 8 -spacing 4 -offset 0




###


