/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : O-2018.06-SP1
// Date      : Wed Aug 31 15:17:57 2022
/////////////////////////////////////////////////////////////


module spi_slave ( i_Rst_L, i_Clk, o_RX_DV, o_RX_Byte, i_TX_DV, i_TX_Byte, 
        i_SPI_Clk, o_SPI_MISO, i_SPI_MOSI, o_TX_Busy, i_SPI_CS_n );
  output [7:0] o_RX_Byte;
  input [7:0] i_TX_Byte;
  input i_Rst_L, i_Clk, i_TX_DV, i_SPI_Clk, i_SPI_MOSI, i_SPI_CS_n;
  output o_RX_DV, o_SPI_MISO, o_TX_Busy;
  wire   \r_SPI_CLK[1] , N93, n9, n10, n12, n13, n14, n15, n16, n17, n18, n19,
         n20, n21, n22, n23, n24, n25, n26, n27, n28, n29, n30, n31, n32, n33,
         n34, n35, n36, n37, n38, n39, n40, n41, n42, n43, n44, n45, n46, n48,
         n49, n50, n51, n52, n53, n54, n55, n56, n57, n58, n59, n60, n61, n62,
         n63, n64, n65, n66, n67, n68, n69, n1;
  wire   [1:0] r_SPI_CS;
  wire   [6:0] r_Temp_RX_Byte;
  wire   [2:0] r_RX_Bit_Count;
  wire   [2:0] r_TX_Bit_Count;

  dffprx05_u \r_SPI_CLK_reg[0]  ( .D(\r_SPI_CLK[1] ), .CK(i_Clk), .RN(i_Rst_L), 
        .QN(n13) );
  dffprqx05_u \r_SPI_CS_reg[1]  ( .D(i_SPI_CS_n), .CK(i_Clk), .RN(i_Rst_L), 
        .Q(r_SPI_CS[1]) );
  dffprqx05_u \r_SPI_CS_reg[0]  ( .D(r_SPI_CS[1]), .CK(i_Clk), .RN(i_Rst_L), 
        .Q(r_SPI_CS[0]) );
  dffprqx05_u \r_Temp_RX_Byte_reg[0]  ( .D(n66), .CK(i_Clk), .RN(i_Rst_L), .Q(
        r_Temp_RX_Byte[0]) );
  dffprqx05_u \r_Temp_RX_Byte_reg[1]  ( .D(n65), .CK(i_Clk), .RN(i_Rst_L), .Q(
        r_Temp_RX_Byte[1]) );
  dffprqx05_u \r_Temp_RX_Byte_reg[2]  ( .D(n64), .CK(i_Clk), .RN(i_Rst_L), .Q(
        r_Temp_RX_Byte[2]) );
  dffprqx05_u \r_Temp_RX_Byte_reg[3]  ( .D(n63), .CK(i_Clk), .RN(i_Rst_L), .Q(
        r_Temp_RX_Byte[3]) );
  dffprqx05_u \r_Temp_RX_Byte_reg[4]  ( .D(n62), .CK(i_Clk), .RN(i_Rst_L), .Q(
        r_Temp_RX_Byte[4]) );
  dffprqx05_u \r_Temp_RX_Byte_reg[5]  ( .D(n61), .CK(i_Clk), .RN(i_Rst_L), .Q(
        r_Temp_RX_Byte[5]) );
  dffprqx05_u \r_Temp_RX_Byte_reg[6]  ( .D(n60), .CK(i_Clk), .RN(i_Rst_L), .Q(
        r_Temp_RX_Byte[6]) );
  dffprqx05_u \r_RX_Bit_Count_reg[0]  ( .D(n69), .CK(i_Clk), .RN(i_Rst_L), .Q(
        r_RX_Bit_Count[0]) );
  dffprx05_u \r_RX_Bit_Count_reg[2]  ( .D(n67), .CK(i_Clk), .RN(i_Rst_L), .QN(
        n22) );
  dffphqx1_u \r_RX_Byte_reg[7]  ( .D(r_Temp_RX_Byte[6]), .E(n1), .CK(i_Clk), 
        .Q(o_RX_Byte[7]) );
  dffphqx1_u \r_RX_Byte_reg[6]  ( .D(r_Temp_RX_Byte[5]), .E(n1), .CK(i_Clk), 
        .Q(o_RX_Byte[6]) );
  dffphqx1_u \r_RX_Byte_reg[5]  ( .D(r_Temp_RX_Byte[4]), .E(n1), .CK(i_Clk), 
        .Q(o_RX_Byte[5]) );
  dffphqx1_u \r_RX_Byte_reg[4]  ( .D(r_Temp_RX_Byte[3]), .E(n1), .CK(i_Clk), 
        .Q(o_RX_Byte[4]) );
  dffphqx1_u \r_RX_Byte_reg[3]  ( .D(r_Temp_RX_Byte[2]), .E(n1), .CK(i_Clk), 
        .Q(o_RX_Byte[3]) );
  dffphqx1_u \r_RX_Byte_reg[2]  ( .D(r_Temp_RX_Byte[1]), .E(n1), .CK(i_Clk), 
        .Q(o_RX_Byte[2]) );
  dffphqx1_u \r_RX_Byte_reg[1]  ( .D(r_Temp_RX_Byte[0]), .E(n1), .CK(i_Clk), 
        .Q(o_RX_Byte[1]) );
  dffphqx1_u \r_RX_Byte_reg[0]  ( .D(i_SPI_MOSI), .E(n1), .CK(i_Clk), .Q(
        o_RX_Byte[0]) );
  dffprqx05_u r_RX_Done_reg ( .D(n59), .CK(i_Clk), .RN(i_Rst_L), .Q(o_RX_DV)
         );
  dffprqx05_u \r_RX_Bit_Count_reg[1]  ( .D(n68), .CK(i_Clk), .RN(i_Rst_L), .Q(
        r_RX_Bit_Count[1]) );
  dffprx05_u r_SPI_MISO_Bit_reg ( .D(n55), .CK(i_Clk), .RN(i_Rst_L), .QN(n28)
         );
  dffprqx05_u r_TX_Busy_reg ( .D(N93), .CK(i_Clk), .RN(i_Rst_L), .Q(o_TX_Busy)
         );
  nand2x1_u U11 ( .A(i_TX_Byte[0]), .B(n26), .Q(n41) );
  nand2x1_u U15 ( .A(n45), .B(n43), .Q(n57) );
  exnor2x1_u U16 ( .A(n26), .B(n44), .Q(n45) );
  nand2x1_u U20 ( .A(n27), .B(n31), .Q(n44) );
  nand2x1_u U30 ( .A(n48), .B(n14), .Q(n49) );
  nand2x1_u U35 ( .A(n46), .B(r_RX_Bit_Count[0]), .Q(n53) );
  nand2x1_u U39 ( .A(n14), .B(n51), .Q(n48) );
  dffpsx05_u \r_TX_Bit_Count_reg[0]  ( .D(n58), .CK(i_Clk), .SN(i_Rst_L), .Q(
        r_TX_Bit_Count[0]), .QN(n27) );
  dffpsx05_u \r_TX_Bit_Count_reg[2]  ( .D(n56), .CK(i_Clk), .SN(i_Rst_L), .Q(
        r_TX_Bit_Count[2]), .QN(n25) );
  dffpsx05_u \r_TX_Bit_Count_reg[1]  ( .D(n57), .CK(i_Clk), .SN(i_Rst_L), .Q(
        r_TX_Bit_Count[1]), .QN(n26) );
  dffprqx05_u \r_SPI_CLK_reg[1]  ( .D(i_SPI_Clk), .CK(i_Clk), .RN(i_Rst_L), 
        .Q(\r_SPI_CLK[1] ) );
  nand3x1_u U3 ( .A(n14), .B(n13), .C(\r_SPI_CLK[1] ), .Q(n51) );
  oai21x05_u U4 ( .A(n35), .B(n34), .C(n31), .Q(n43) );
  oai21x05_u U5 ( .A(\r_SPI_CLK[1] ), .B(n13), .C(n14), .Q(n31) );
  oai22x05_u U6 ( .A(n38), .B(n26), .C(r_TX_Bit_Count[1]), .D(n39), .Q(n37) );
  aoi22x05_u U7 ( .A(i_TX_Byte[5]), .B(n27), .C(i_TX_Byte[6]), .D(
        r_TX_Bit_Count[0]), .Q(n38) );
  aoi22x05_u U8 ( .A(i_TX_Byte[3]), .B(n27), .C(i_TX_Byte[4]), .D(
        r_TX_Bit_Count[0]), .Q(n39) );
  oai22x05_u U9 ( .A(n40), .B(n26), .C(n27), .D(n41), .Q(n36) );
  aoi22x05_u U10 ( .A(i_TX_Byte[1]), .B(n27), .C(i_TX_Byte[2]), .D(
        r_TX_Bit_Count[0]), .Q(n40) );
  invx1_u U12 ( .A(n34), .Q(n14) );
  nor3x1_u U13 ( .A(r_TX_Bit_Count[1]), .B(r_TX_Bit_Count[2]), .C(
        r_TX_Bit_Count[0]), .Q(n35) );
  nor2ax05_u U14 ( .AN(r_SPI_CS[0]), .B(r_SPI_CS[1]), .Q(n34) );
  nor3x1_u U17 ( .A(n23), .B(n24), .C(n22), .Q(n50) );
  invx1_u U18 ( .A(n51), .Q(n12) );
  invx1_u U19 ( .A(r_RX_Bit_Count[1]), .Q(n23) );
  oai21x05_u U21 ( .A(r_RX_Bit_Count[0]), .B(n10), .C(n48), .Q(n54) );
  nor2x1_u U22 ( .A(n51), .B(n50), .Q(n46) );
  invx1_u U23 ( .A(r_RX_Bit_Count[0]), .Q(n24) );
  invx1_u U24 ( .A(n46), .Q(n10) );
  invx1_u U25 ( .A(r_Temp_RX_Byte[5]), .Q(n16) );
  invx1_u U26 ( .A(r_Temp_RX_Byte[4]), .Q(n17) );
  invx1_u U27 ( .A(r_Temp_RX_Byte[3]), .Q(n18) );
  invx1_u U28 ( .A(r_Temp_RX_Byte[2]), .Q(n19) );
  invx1_u U29 ( .A(r_Temp_RX_Byte[1]), .Q(n20) );
  invx1_u U31 ( .A(r_Temp_RX_Byte[0]), .Q(n21) );
  nor2x1_u U32 ( .A(i_SPI_CS_n), .B(n28), .Q(o_SPI_MISO) );
  oai21x05_u U33 ( .A(n42), .B(n25), .C(n43), .Q(n56) );
  nor2x1_u U34 ( .A(r_TX_Bit_Count[1]), .B(n44), .Q(n42) );
  oai211x05_u U36 ( .A(n27), .B(n31), .C(n44), .D(n43), .Q(n58) );
  aoi31x1_u U37 ( .A(\r_SPI_CLK[1] ), .B(n13), .C(n50), .D(i_SPI_CS_n), .Q(N93) );
  oai221x1_u U38 ( .A(n29), .B(n14), .C(n28), .D(n31), .E(n32), .Q(n55) );
  invx1_u U40 ( .A(i_TX_Byte[7]), .Q(n29) );
  or4x1_u U41 ( .A(n33), .B(n13), .C(n34), .D(\r_SPI_CLK[1] ), .Q(n32) );
  aoi222x05_u U42 ( .A(i_TX_Byte[7]), .B(n35), .C(n36), .D(n25), .E(
        r_TX_Bit_Count[2]), .F(n37), .Q(n33) );
  oai22x05_u U43 ( .A(n9), .B(n23), .C(r_RX_Bit_Count[1]), .D(n53), .Q(n68) );
  invx1_u U44 ( .A(n54), .Q(n9) );
  ao22x1_u U45 ( .A(o_RX_DV), .B(n46), .C(n12), .D(n10), .Q(n59) );
  oai22x05_u U46 ( .A(n52), .B(n22), .C(n23), .D(n53), .Q(n67) );
  nor2x1_u U47 ( .A(n46), .B(n54), .Q(n52) );
  oai22x05_u U48 ( .A(n24), .B(n48), .C(r_RX_Bit_Count[0]), .D(n10), .Q(n69)
         );
  oai22x05_u U49 ( .A(n15), .B(n48), .C(n49), .D(n16), .Q(n60) );
  invx1_u U50 ( .A(r_Temp_RX_Byte[6]), .Q(n15) );
  oai22x05_u U51 ( .A(n16), .B(n48), .C(n49), .D(n17), .Q(n61) );
  oai22x05_u U52 ( .A(n48), .B(n17), .C(n49), .D(n18), .Q(n62) );
  oai22x05_u U53 ( .A(n48), .B(n18), .C(n49), .D(n19), .Q(n63) );
  oai22x05_u U54 ( .A(n48), .B(n19), .C(n49), .D(n20), .Q(n64) );
  oai22x05_u U55 ( .A(n48), .B(n20), .C(n49), .D(n21), .Q(n65) );
  oai22x05_u U56 ( .A(n48), .B(n21), .C(n49), .D(n30), .Q(n66) );
  invx1_u U57 ( .A(i_SPI_MOSI), .Q(n30) );
  and3x1_u U58 ( .A(n12), .B(i_Rst_L), .C(n50), .Q(n1) );
endmodule


module spi_reg_interface ( clk, rst_n, SPI_CLK, SPI_MOSI, SPI_SS, SPI_MISO, 
        reg_addr, wr_data, rd_data, wr_en, rd_en, rd_ready );
  output [5:0] reg_addr;
  output [7:0] wr_data;
  input [7:0] rd_data;
  input clk, rst_n, SPI_CLK, SPI_MOSI, SPI_SS, rd_ready;
  output SPI_MISO, wr_en, rd_en;
  wire   spi_rx_vaild, spi_tx_vaild, spi_tx_busy, byte_cnt, n1, n3, n4, n5, n6,
         n7, n8, n9, n11, n12, n13, n14, n15, n16, n17, n19, n20, n21, n22,
         n23, n24, n25, n26, n27, n28, n29, n30, n31, n32, n33, n2, n10, n18;
  wire   [7:0] spi_rx_byte;
  wire   [7:0] spi_tx_byte;
  wire   [3:0] state;

  spi_slave u_spi_slave ( .i_Rst_L(n18), .i_Clk(clk), .o_RX_DV(spi_rx_vaild), 
        .o_RX_Byte(spi_rx_byte), .i_TX_DV(spi_tx_vaild), .i_TX_Byte(
        spi_tx_byte), .i_SPI_Clk(SPI_CLK), .o_SPI_MISO(SPI_MISO), .i_SPI_MOSI(
        SPI_MOSI), .o_TX_Busy(spi_tx_busy), .i_SPI_CS_n(SPI_SS) );
  dffphrqx1_u \spi_tx_byte_reg[0]  ( .D(rd_data[0]), .E(n6), .CK(clk), .RN(n18), .Q(spi_tx_byte[0]) );
  dffphrqx1_u \reg_wr_data_reg[7]  ( .D(spi_rx_byte[7]), .E(n4), .CK(clk), 
        .RN(n18), .Q(wr_data[7]) );
  dffphrqx1_u \reg_wr_data_reg[6]  ( .D(spi_rx_byte[6]), .E(n4), .CK(clk), 
        .RN(n18), .Q(wr_data[6]) );
  dffphrqx1_u \reg_wr_data_reg[5]  ( .D(spi_rx_byte[5]), .E(n4), .CK(clk), 
        .RN(n18), .Q(wr_data[5]) );
  dffphrqx1_u \reg_wr_data_reg[4]  ( .D(spi_rx_byte[4]), .E(n4), .CK(clk), 
        .RN(n18), .Q(wr_data[4]) );
  dffphrqx1_u \reg_wr_data_reg[3]  ( .D(spi_rx_byte[3]), .E(n4), .CK(clk), 
        .RN(n18), .Q(wr_data[3]) );
  dffphrqx1_u \reg_wr_data_reg[2]  ( .D(spi_rx_byte[2]), .E(n4), .CK(clk), 
        .RN(n18), .Q(wr_data[2]) );
  dffphrqx1_u \reg_wr_data_reg[1]  ( .D(spi_rx_byte[1]), .E(n4), .CK(clk), 
        .RN(n18), .Q(wr_data[1]) );
  dffphrqx1_u \reg_wr_data_reg[0]  ( .D(spi_rx_byte[0]), .E(n4), .CK(clk), 
        .RN(n18), .Q(wr_data[0]) );
  dffprqx05_u reg_wr_en_reg ( .D(n33), .CK(clk), .RN(n18), .Q(wr_en) );
  dffprqx05_u \state_reg[2]  ( .D(n30), .CK(clk), .RN(n18), .Q(state[2]) );
  dffprqx05_u \state_reg[0]  ( .D(n31), .CK(clk), .RN(n18), .Q(state[0]) );
  dffprqx05_u \state_reg[1]  ( .D(n32), .CK(clk), .RN(n18), .Q(state[1]) );
  dffprqx05_u \state_reg[3]  ( .D(n29), .CK(clk), .RN(n18), .Q(state[3]) );
  dffprqx05_u spi_tx_vaild_reg ( .D(n28), .CK(clk), .RN(n18), .Q(spi_tx_vaild)
         );
  dffphrqx1_u \spi_tx_byte_reg[1]  ( .D(rd_data[1]), .E(n6), .CK(clk), .RN(n18), .Q(spi_tx_byte[1]) );
  dffphrqx1_u \spi_tx_byte_reg[2]  ( .D(rd_data[2]), .E(n6), .CK(clk), .RN(n18), .Q(spi_tx_byte[2]) );
  dffphrqx1_u \spi_tx_byte_reg[3]  ( .D(rd_data[3]), .E(n6), .CK(clk), .RN(n18), .Q(spi_tx_byte[3]) );
  dffphrqx1_u \spi_tx_byte_reg[4]  ( .D(rd_data[4]), .E(n6), .CK(clk), .RN(n18), .Q(spi_tx_byte[4]) );
  dffphrqx1_u \spi_tx_byte_reg[5]  ( .D(rd_data[5]), .E(n6), .CK(clk), .RN(n18), .Q(spi_tx_byte[5]) );
  dffphrqx1_u \spi_tx_byte_reg[6]  ( .D(rd_data[6]), .E(n6), .CK(clk), .RN(n18), .Q(spi_tx_byte[6]) );
  dffphrqx1_u \spi_tx_byte_reg[7]  ( .D(rd_data[7]), .E(n6), .CK(clk), .RN(n18), .Q(spi_tx_byte[7]) );
  dffphrqx1_u byte_cnt_reg ( .D(n13), .E(n12), .CK(clk), .RN(n18), .Q(byte_cnt) );
  dffphrqx1_u reg_rd_en_reg ( .D(n13), .E(n16), .CK(clk), .RN(n18), .Q(rd_en)
         );
  dffphrqx1_u \reg_reg_addr_reg[5]  ( .D(spi_rx_byte[5]), .E(n2), .CK(clk), 
        .RN(n18), .Q(reg_addr[5]) );
  dffphrqx1_u \reg_reg_addr_reg[4]  ( .D(spi_rx_byte[4]), .E(n2), .CK(clk), 
        .RN(n18), .Q(reg_addr[4]) );
  dffphrqx1_u \reg_reg_addr_reg[3]  ( .D(spi_rx_byte[3]), .E(n2), .CK(clk), 
        .RN(n18), .Q(reg_addr[3]) );
  dffphrqx1_u \reg_reg_addr_reg[2]  ( .D(spi_rx_byte[2]), .E(n2), .CK(clk), 
        .RN(n18), .Q(reg_addr[2]) );
  dffphrqx1_u \reg_reg_addr_reg[1]  ( .D(spi_rx_byte[1]), .E(n2), .CK(clk), 
        .RN(n18), .Q(reg_addr[1]) );
  dffphrqx1_u \reg_reg_addr_reg[0]  ( .D(spi_rx_byte[0]), .E(n2), .CK(clk), 
        .RN(n18), .Q(reg_addr[0]) );
  nand2x1_u U4 ( .A(n14), .B(n15), .Q(n16) );
  nand2x1_u U5 ( .A(n2), .B(n17), .Q(n15) );
  nand2x1_u U23 ( .A(spi_rx_vaild), .B(n27), .Q(n11) );
  invx1_u U3 ( .A(spi_rx_byte[6]), .Q(n3) );
  and4x1_u U6 ( .A(spi_rx_byte[7]), .B(spi_rx_byte[6]), .C(spi_rx_byte[5]), 
        .D(spi_rx_byte[4]), .Q(n24) );
  and4x1_u U7 ( .A(spi_rx_byte[3]), .B(spi_rx_byte[2]), .C(spi_rx_byte[1]), 
        .D(spi_rx_byte[0]), .Q(n23) );
  nor2x1_u U8 ( .A(n3), .B(spi_rx_byte[7]), .Q(n17) );
  invx1_u U9 ( .A(state[1]), .Q(n8) );
  invx1_u U10 ( .A(state[0]), .Q(n9) );
  invx1_u U11 ( .A(state[2]), .Q(n7) );
  oai321x05_u U12 ( .A(n14), .B(spi_tx_busy), .C(byte_cnt), .D(n5), .E(n10), 
        .F(n21), .Q(n19) );
  invx1_u U13 ( .A(n27), .Q(n5) );
  oai21x05_u U14 ( .A(spi_rx_byte[7]), .B(n17), .C(n2), .Q(n21) );
  nand3x1_u U15 ( .A(n19), .B(n3), .C(n13), .Q(n20) );
  nor4x1_u U16 ( .A(n7), .B(n8), .C(n9), .D(state[3]), .Q(n27) );
  nand4x1_u U17 ( .A(state[3]), .B(n9), .C(n8), .D(n7), .Q(n14) );
  aoi22x05_u U18 ( .A(n23), .B(n24), .C(n25), .D(n26), .Q(n22) );
  nor4x1_u U19 ( .A(spi_rx_byte[3]), .B(spi_rx_byte[2]), .C(spi_rx_byte[1]), 
        .D(spi_rx_byte[0]), .Q(n25) );
  nor4x1_u U20 ( .A(spi_rx_byte[7]), .B(spi_rx_byte[6]), .C(spi_rx_byte[5]), 
        .D(spi_rx_byte[4]), .Q(n26) );
  oai21x05_u U21 ( .A(spi_tx_busy), .B(n14), .C(n15), .Q(n12) );
  nor4x1_u U22 ( .A(state[0]), .B(state[1]), .C(state[2]), .D(state[3]), .Q(
        n13) );
  exor2x1_u U24 ( .A(spi_tx_vaild), .B(n6), .Q(n28) );
  ao32x05_u U25 ( .A(n17), .B(n19), .C(n13), .D(state[3]), .E(n1), .Q(n29) );
  invx1_u U26 ( .A(n19), .Q(n1) );
  oai21x05_u U27 ( .A(n8), .B(n19), .C(n20), .Q(n32) );
  oai21x05_u U28 ( .A(n9), .B(n19), .C(n20), .Q(n31) );
  oai21x05_u U29 ( .A(n7), .B(n19), .C(n20), .Q(n30) );
  oai22x05_u U30 ( .A(n27), .B(n10), .C(wr_en), .D(n11), .Q(n33) );
  invx1_u U31 ( .A(n11), .Q(n4) );
  bufx1_u U32 ( .A(rst_n), .Q(n18) );
  invx1_u U33 ( .A(n14), .Q(n6) );
  and3x1_u U34 ( .A(n13), .B(spi_rx_vaild), .C(n22), .Q(n2) );
  invx1_u U35 ( .A(wr_en), .Q(n10) );
endmodule


module inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40 ( clk, rst_n, 
        reg_addr, wr_data, rd_data, wr_en, rd_en, rd_ready, control_o, 
        status_i );
  input [5:0] reg_addr;
  input [7:0] wr_data;
  output [7:0] rd_data;
  output [191:0] control_o;
  input [319:0] status_i;
  input clk, rst_n, wr_en, rd_en;
  output rd_ready;
  wire   \reg_array[63][7] , \reg_array[63][6] , \reg_array[63][5] ,
         \reg_array[63][4] , \reg_array[63][3] , \reg_array[63][2] ,
         \reg_array[63][1] , \reg_array[63][0] , \reg_array[62][7] ,
         \reg_array[62][6] , \reg_array[62][5] , \reg_array[62][4] ,
         \reg_array[62][3] , \reg_array[62][2] , \reg_array[62][1] ,
         \reg_array[62][0] , \reg_array[61][7] , \reg_array[61][6] ,
         \reg_array[61][5] , \reg_array[61][4] , \reg_array[61][3] ,
         \reg_array[61][2] , \reg_array[61][1] , \reg_array[61][0] ,
         \reg_array[60][7] , \reg_array[60][6] , \reg_array[60][5] ,
         \reg_array[60][4] , \reg_array[60][3] , \reg_array[60][2] ,
         \reg_array[60][1] , \reg_array[60][0] , \reg_array[59][7] ,
         \reg_array[59][6] , \reg_array[59][5] , \reg_array[59][4] ,
         \reg_array[59][3] , \reg_array[59][2] , \reg_array[59][1] ,
         \reg_array[59][0] , \reg_array[58][7] , \reg_array[58][6] ,
         \reg_array[58][5] , \reg_array[58][4] , \reg_array[58][3] ,
         \reg_array[58][2] , \reg_array[58][1] , \reg_array[58][0] ,
         \reg_array[57][7] , \reg_array[57][6] , \reg_array[57][5] ,
         \reg_array[57][4] , \reg_array[57][3] , \reg_array[57][2] ,
         \reg_array[57][1] , \reg_array[57][0] , \reg_array[56][7] ,
         \reg_array[56][6] , \reg_array[56][5] , \reg_array[56][4] ,
         \reg_array[56][3] , \reg_array[56][2] , \reg_array[56][1] ,
         \reg_array[56][0] , \reg_array[55][7] , \reg_array[55][6] ,
         \reg_array[55][5] , \reg_array[55][4] , \reg_array[55][3] ,
         \reg_array[55][2] , \reg_array[55][1] , \reg_array[55][0] ,
         \reg_array[54][7] , \reg_array[54][6] , \reg_array[54][5] ,
         \reg_array[54][4] , \reg_array[54][3] , \reg_array[54][2] ,
         \reg_array[54][1] , \reg_array[54][0] , \reg_array[53][7] ,
         \reg_array[53][6] , \reg_array[53][5] , \reg_array[53][4] ,
         \reg_array[53][3] , \reg_array[53][2] , \reg_array[53][1] ,
         \reg_array[53][0] , \reg_array[52][7] , \reg_array[52][6] ,
         \reg_array[52][5] , \reg_array[52][4] , \reg_array[52][3] ,
         \reg_array[52][2] , \reg_array[52][1] , \reg_array[52][0] ,
         \reg_array[51][7] , \reg_array[51][6] , \reg_array[51][5] ,
         \reg_array[51][4] , \reg_array[51][3] , \reg_array[51][2] ,
         \reg_array[51][1] , \reg_array[51][0] , \reg_array[50][7] ,
         \reg_array[50][6] , \reg_array[50][5] , \reg_array[50][4] ,
         \reg_array[50][3] , \reg_array[50][2] , \reg_array[50][1] ,
         \reg_array[50][0] , \reg_array[49][7] , \reg_array[49][6] ,
         \reg_array[49][5] , \reg_array[49][4] , \reg_array[49][3] ,
         \reg_array[49][2] , \reg_array[49][1] , \reg_array[49][0] ,
         \reg_array[48][7] , \reg_array[48][6] , \reg_array[48][5] ,
         \reg_array[48][4] , \reg_array[48][3] , \reg_array[48][2] ,
         \reg_array[48][1] , \reg_array[48][0] , \reg_array[47][7] ,
         \reg_array[47][6] , \reg_array[47][5] , \reg_array[47][4] ,
         \reg_array[47][3] , \reg_array[47][2] , \reg_array[47][1] ,
         \reg_array[47][0] , \reg_array[46][7] , \reg_array[46][6] ,
         \reg_array[46][5] , \reg_array[46][4] , \reg_array[46][3] ,
         \reg_array[46][2] , \reg_array[46][1] , \reg_array[46][0] ,
         \reg_array[45][7] , \reg_array[45][6] , \reg_array[45][5] ,
         \reg_array[45][4] , \reg_array[45][3] , \reg_array[45][2] ,
         \reg_array[45][1] , \reg_array[45][0] , \reg_array[44][7] ,
         \reg_array[44][6] , \reg_array[44][5] , \reg_array[44][4] ,
         \reg_array[44][3] , \reg_array[44][2] , \reg_array[44][1] ,
         \reg_array[44][0] , \reg_array[43][7] , \reg_array[43][6] ,
         \reg_array[43][5] , \reg_array[43][4] , \reg_array[43][3] ,
         \reg_array[43][2] , \reg_array[43][1] , \reg_array[43][0] ,
         \reg_array[42][7] , \reg_array[42][6] , \reg_array[42][5] ,
         \reg_array[42][4] , \reg_array[42][3] , \reg_array[42][2] ,
         \reg_array[42][1] , \reg_array[42][0] , \reg_array[41][7] ,
         \reg_array[41][6] , \reg_array[41][5] , \reg_array[41][4] ,
         \reg_array[41][3] , \reg_array[41][2] , \reg_array[41][1] ,
         \reg_array[41][0] , \reg_array[40][7] , \reg_array[40][6] ,
         \reg_array[40][5] , \reg_array[40][4] , \reg_array[40][3] ,
         \reg_array[40][2] , \reg_array[40][1] , \reg_array[40][0] ,
         \reg_array[39][7] , \reg_array[39][6] , \reg_array[39][5] ,
         \reg_array[39][4] , \reg_array[39][3] , \reg_array[39][2] ,
         \reg_array[39][1] , \reg_array[39][0] , \reg_array[38][7] ,
         \reg_array[38][6] , \reg_array[38][5] , \reg_array[38][4] ,
         \reg_array[38][3] , \reg_array[38][2] , \reg_array[38][1] ,
         \reg_array[38][0] , \reg_array[37][7] , \reg_array[37][6] ,
         \reg_array[37][5] , \reg_array[37][4] , \reg_array[37][3] ,
         \reg_array[37][2] , \reg_array[37][1] , \reg_array[37][0] ,
         \reg_array[36][7] , \reg_array[36][6] , \reg_array[36][5] ,
         \reg_array[36][4] , \reg_array[36][3] , \reg_array[36][2] ,
         \reg_array[36][1] , \reg_array[36][0] , \reg_array[35][7] ,
         \reg_array[35][6] , \reg_array[35][5] , \reg_array[35][4] ,
         \reg_array[35][3] , \reg_array[35][2] , \reg_array[35][1] ,
         \reg_array[35][0] , \reg_array[34][7] , \reg_array[34][6] ,
         \reg_array[34][5] , \reg_array[34][4] , \reg_array[34][3] ,
         \reg_array[34][2] , \reg_array[34][1] , \reg_array[34][0] ,
         \reg_array[33][7] , \reg_array[33][6] , \reg_array[33][5] ,
         \reg_array[33][4] , \reg_array[33][3] , \reg_array[33][2] ,
         \reg_array[33][1] , \reg_array[33][0] , \reg_array[32][7] ,
         \reg_array[32][6] , \reg_array[32][5] , \reg_array[32][4] ,
         \reg_array[32][3] , \reg_array[32][2] , \reg_array[32][1] ,
         \reg_array[32][0] , \reg_array[31][7] , \reg_array[31][6] ,
         \reg_array[31][5] , \reg_array[31][4] , \reg_array[31][3] ,
         \reg_array[31][2] , \reg_array[31][1] , \reg_array[31][0] ,
         \reg_array[30][7] , \reg_array[30][6] , \reg_array[30][5] ,
         \reg_array[30][4] , \reg_array[30][3] , \reg_array[30][2] ,
         \reg_array[30][1] , \reg_array[30][0] , \reg_array[29][7] ,
         \reg_array[29][6] , \reg_array[29][5] , \reg_array[29][4] ,
         \reg_array[29][3] , \reg_array[29][2] , \reg_array[29][1] ,
         \reg_array[29][0] , \reg_array[28][7] , \reg_array[28][6] ,
         \reg_array[28][5] , \reg_array[28][4] , \reg_array[28][3] ,
         \reg_array[28][2] , \reg_array[28][1] , \reg_array[28][0] ,
         \reg_array[27][7] , \reg_array[27][6] , \reg_array[27][5] ,
         \reg_array[27][4] , \reg_array[27][3] , \reg_array[27][2] ,
         \reg_array[27][1] , \reg_array[27][0] , \reg_array[26][7] ,
         \reg_array[26][6] , \reg_array[26][5] , \reg_array[26][4] ,
         \reg_array[26][3] , \reg_array[26][2] , \reg_array[26][1] ,
         \reg_array[26][0] , \reg_array[25][7] , \reg_array[25][6] ,
         \reg_array[25][5] , \reg_array[25][4] , \reg_array[25][3] ,
         \reg_array[25][2] , \reg_array[25][1] , \reg_array[25][0] ,
         \reg_array[24][7] , \reg_array[24][6] , \reg_array[24][5] ,
         \reg_array[24][4] , \reg_array[24][3] , \reg_array[24][2] ,
         \reg_array[24][1] , \reg_array[24][0] , n1, n26, n27, n28, n29, n30,
         n31, n32, n33, n34, n35, n36, n37, n38, n39, n40, n41, n42, n43, n44,
         n45, n46, n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n57, n58,
         n59, n60, n61, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71, n72,
         n73, n74, n75, n76, n77, n78, n79, n80, n81, n82, n83, n84, n85, n86,
         n87, n88, n89, n90, n91, n92, n93, n94, n95, n96, n97, n98, n99, n100,
         n101, n102, n103, n104, n105, n106, n107, n108, n109, n110, n111,
         n112, n113, n114, n115, n116, n117, n118, n119, n120, n121, n122,
         n123, n124, n125, n126, n127, n128, n129, n130, n131, n132, n133,
         n134, n135, n136, n137, n138, n139, n140, n141, n142, n143, n144,
         n145, n146, n147, n148, n149, n150, n151, n152, n153, n154, n155,
         n156, n157, n158, n159, n160, n161, n162, n163, n164, n165, n166,
         n167, n168, n169, n170, n171, n172, n173, n174, n175, n176, n177,
         n178, n179, n180, n181, n182, n183, n184, n185, n186, n187, n188,
         n189, n190, n191, n192, n193, n194, n195, n196, n197, n198, n199,
         n200, n201, n202, n203, n204, n205, n206, n207, n208, n209, n210,
         n211, n212, n213, n214, n215, n216, n217, n218, n219, n220, n221,
         n222, n223, n224, n225, n226, n227, n228, n229, n230, n231, n232,
         n233, n234, n235, n236, n237, n238, n239, n240, n241, n242, n243,
         n244, n245, n246, n247, n248, n249, n250, n251, n252, n253, n254,
         n255, n256, n257, n258, n259, n260, n261, n262, n263, n264, n265,
         n266, n267, n268, n269, n270, n271, n272, n273, n274, n275, n276,
         n277, n278, n279, n280, n281, n282, n283, n284, n285, n286, n287,
         n288, n289, n290, n291, n292, n293, n294, n295, n296, n297, n298,
         n299, n300, n301, n302, n303, n304, n305, n306, n307, n308, n309,
         n310, n311, n312, n313, n314, n315, n316, n317, n318, n319, n320,
         n321, n322, n323, n324, n325, n326, n327, n328, n329, n330, n331,
         n332, n333, n334, n335, n336, n337, n338, n339, n340, n341, n342,
         n343, n344, n345, n346, n347, n348, n349, n350, n351, n352, n353,
         n354, n355, n356, n357, n358, n359, n360, n361, n362, n363, n364,
         n365, n366, n367, n368, n369, n370, n371, n372, n373, n374, n375,
         n376, n377, n378, n379, n380, n381, n382, n383, n384, n385, n386,
         n387, n388, n389, n390, n391, n392, n393, n394, n395, n396, n397,
         n398, n399, n400, n401, n402, n403, n404, n405, n406, n407, n408,
         n409, n410, n411, n412, n413, n414, n415, n416, n417, n418, n419,
         n420, n421, n422, n423, n424, n425, n426, n427, n428, n429, n430,
         n431, n432, n433, n434, n435, n436, n437, n438, n439, n440, n441,
         n442, n443, n444, n445, n446, n447, n448, n449, n450, n451, n452,
         n453, n454, n455, n456, n457, n458, n459, n460, n461, n462, n463,
         n464, n465, n466, n467, n468, n469, n470, n471, n472, n473, n474,
         n475, n476, n477, n478, n479, n480, n481, n482, n483, n484, n485,
         n486, n487, n488, n489, n491, n495, n497, n502, n507, n512, n517, n2,
         n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16, n17,
         n18, n19, n20, n21, n22, n23, n24, n25, n490, n492, n493, n494, n496,
         n498;

  dffphqx1_u \reg_array_reg[63][7]  ( .D(status_i[319]), .E(n498), .CK(clk), 
        .Q(\reg_array[63][7] ) );
  dffphqx1_u \reg_array_reg[63][6]  ( .D(status_i[318]), .E(n498), .CK(clk), 
        .Q(\reg_array[63][6] ) );
  dffphqx1_u \reg_array_reg[63][5]  ( .D(status_i[317]), .E(n498), .CK(clk), 
        .Q(\reg_array[63][5] ) );
  dffphqx1_u \reg_array_reg[63][4]  ( .D(status_i[316]), .E(n498), .CK(clk), 
        .Q(\reg_array[63][4] ) );
  dffphqx1_u \reg_array_reg[63][3]  ( .D(status_i[315]), .E(n498), .CK(clk), 
        .Q(\reg_array[63][3] ) );
  dffphqx1_u \reg_array_reg[63][2]  ( .D(status_i[314]), .E(n498), .CK(clk), 
        .Q(\reg_array[63][2] ) );
  dffphqx1_u \reg_array_reg[63][1]  ( .D(status_i[313]), .E(n498), .CK(clk), 
        .Q(\reg_array[63][1] ) );
  dffphqx1_u \reg_array_reg[63][0]  ( .D(status_i[312]), .E(n492), .CK(clk), 
        .Q(\reg_array[63][0] ) );
  dffphqx1_u \reg_array_reg[62][7]  ( .D(status_i[311]), .E(n496), .CK(clk), 
        .Q(\reg_array[62][7] ) );
  dffphqx1_u \reg_array_reg[62][6]  ( .D(status_i[310]), .E(n496), .CK(clk), 
        .Q(\reg_array[62][6] ) );
  dffphqx1_u \reg_array_reg[62][5]  ( .D(status_i[309]), .E(n490), .CK(clk), 
        .Q(\reg_array[62][5] ) );
  dffphqx1_u \reg_array_reg[62][4]  ( .D(status_i[308]), .E(n498), .CK(clk), 
        .Q(\reg_array[62][4] ) );
  dffphqx1_u \reg_array_reg[62][3]  ( .D(status_i[307]), .E(n490), .CK(clk), 
        .Q(\reg_array[62][3] ) );
  dffphqx1_u \reg_array_reg[62][2]  ( .D(status_i[306]), .E(n492), .CK(clk), 
        .Q(\reg_array[62][2] ) );
  dffphqx1_u \reg_array_reg[62][1]  ( .D(status_i[305]), .E(n493), .CK(clk), 
        .Q(\reg_array[62][1] ) );
  dffphqx1_u \reg_array_reg[62][0]  ( .D(status_i[304]), .E(n494), .CK(clk), 
        .Q(\reg_array[62][0] ) );
  dffphqx1_u \reg_array_reg[61][7]  ( .D(status_i[303]), .E(n494), .CK(clk), 
        .Q(\reg_array[61][7] ) );
  dffphqx1_u \reg_array_reg[61][6]  ( .D(status_i[302]), .E(n493), .CK(clk), 
        .Q(\reg_array[61][6] ) );
  dffphqx1_u \reg_array_reg[61][5]  ( .D(status_i[301]), .E(n498), .CK(clk), 
        .Q(\reg_array[61][5] ) );
  dffphqx1_u \reg_array_reg[61][4]  ( .D(status_i[300]), .E(n498), .CK(clk), 
        .Q(\reg_array[61][4] ) );
  dffphqx1_u \reg_array_reg[61][3]  ( .D(status_i[299]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[61][3] ) );
  dffphqx1_u \reg_array_reg[61][2]  ( .D(status_i[298]), .E(n490), .CK(clk), 
        .Q(\reg_array[61][2] ) );
  dffphqx1_u \reg_array_reg[61][1]  ( .D(status_i[297]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[61][1] ) );
  dffphqx1_u \reg_array_reg[61][0]  ( .D(status_i[296]), .E(n498), .CK(clk), 
        .Q(\reg_array[61][0] ) );
  dffphqx1_u \reg_array_reg[60][7]  ( .D(status_i[295]), .E(n493), .CK(clk), 
        .Q(\reg_array[60][7] ) );
  dffphqx1_u \reg_array_reg[60][6]  ( .D(status_i[294]), .E(n492), .CK(clk), 
        .Q(\reg_array[60][6] ) );
  dffphqx1_u \reg_array_reg[60][5]  ( .D(status_i[293]), .E(n493), .CK(clk), 
        .Q(\reg_array[60][5] ) );
  dffphqx1_u \reg_array_reg[60][4]  ( .D(status_i[292]), .E(n494), .CK(clk), 
        .Q(\reg_array[60][4] ) );
  dffphqx1_u \reg_array_reg[60][3]  ( .D(status_i[291]), .E(n496), .CK(clk), 
        .Q(\reg_array[60][3] ) );
  dffphqx1_u \reg_array_reg[60][2]  ( .D(status_i[290]), .E(n490), .CK(clk), 
        .Q(\reg_array[60][2] ) );
  dffphqx1_u \reg_array_reg[60][1]  ( .D(status_i[289]), .E(n492), .CK(clk), 
        .Q(\reg_array[60][1] ) );
  dffphqx1_u \reg_array_reg[60][0]  ( .D(status_i[288]), .E(n493), .CK(clk), 
        .Q(\reg_array[60][0] ) );
  dffphqx1_u \reg_array_reg[59][7]  ( .D(status_i[287]), .E(n492), .CK(clk), 
        .Q(\reg_array[59][7] ) );
  dffphqx1_u \reg_array_reg[59][6]  ( .D(status_i[286]), .E(n490), .CK(clk), 
        .Q(\reg_array[59][6] ) );
  dffphqx1_u \reg_array_reg[59][5]  ( .D(status_i[285]), .E(n492), .CK(clk), 
        .Q(\reg_array[59][5] ) );
  dffphqx1_u \reg_array_reg[59][4]  ( .D(status_i[284]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[59][4] ) );
  dffphqx1_u \reg_array_reg[59][3]  ( .D(status_i[283]), .E(n492), .CK(clk), 
        .Q(\reg_array[59][3] ) );
  dffphqx1_u \reg_array_reg[59][2]  ( .D(status_i[282]), .E(n493), .CK(clk), 
        .Q(\reg_array[59][2] ) );
  dffphqx1_u \reg_array_reg[59][1]  ( .D(status_i[281]), .E(n494), .CK(clk), 
        .Q(\reg_array[59][1] ) );
  dffphqx1_u \reg_array_reg[59][0]  ( .D(status_i[280]), .E(n496), .CK(clk), 
        .Q(\reg_array[59][0] ) );
  dffphqx1_u \reg_array_reg[58][7]  ( .D(status_i[279]), .E(n494), .CK(clk), 
        .Q(\reg_array[58][7] ) );
  dffphqx1_u \reg_array_reg[58][6]  ( .D(status_i[278]), .E(n494), .CK(clk), 
        .Q(\reg_array[58][6] ) );
  dffphqx1_u \reg_array_reg[58][5]  ( .D(status_i[277]), .E(n498), .CK(clk), 
        .Q(\reg_array[58][5] ) );
  dffphqx1_u \reg_array_reg[58][4]  ( .D(status_i[276]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[58][4] ) );
  dffphqx1_u \reg_array_reg[58][3]  ( .D(status_i[275]), .E(n498), .CK(clk), 
        .Q(\reg_array[58][3] ) );
  dffphqx1_u \reg_array_reg[58][2]  ( .D(status_i[274]), .E(n496), .CK(clk), 
        .Q(\reg_array[58][2] ) );
  dffphqx1_u \reg_array_reg[58][1]  ( .D(status_i[273]), .E(n490), .CK(clk), 
        .Q(\reg_array[58][1] ) );
  dffphqx1_u \reg_array_reg[58][0]  ( .D(status_i[272]), .E(n498), .CK(clk), 
        .Q(\reg_array[58][0] ) );
  dffphqx1_u \reg_array_reg[57][7]  ( .D(status_i[271]), .E(n493), .CK(clk), 
        .Q(\reg_array[57][7] ) );
  dffphqx1_u \reg_array_reg[57][6]  ( .D(status_i[270]), .E(n496), .CK(clk), 
        .Q(\reg_array[57][6] ) );
  dffphqx1_u \reg_array_reg[57][5]  ( .D(status_i[269]), .E(n498), .CK(clk), 
        .Q(\reg_array[57][5] ) );
  dffphqx1_u \reg_array_reg[57][4]  ( .D(status_i[268]), .E(n490), .CK(clk), 
        .Q(\reg_array[57][4] ) );
  dffphqx1_u \reg_array_reg[57][3]  ( .D(status_i[267]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[57][3] ) );
  dffphqx1_u \reg_array_reg[57][2]  ( .D(status_i[266]), .E(n496), .CK(clk), 
        .Q(\reg_array[57][2] ) );
  dffphqx1_u \reg_array_reg[57][1]  ( .D(status_i[265]), .E(n492), .CK(clk), 
        .Q(\reg_array[57][1] ) );
  dffphqx1_u \reg_array_reg[57][0]  ( .D(status_i[264]), .E(n490), .CK(clk), 
        .Q(\reg_array[57][0] ) );
  dffphqx1_u \reg_array_reg[56][7]  ( .D(status_i[263]), .E(n498), .CK(clk), 
        .Q(\reg_array[56][7] ) );
  dffphqx1_u \reg_array_reg[56][6]  ( .D(status_i[262]), .E(n492), .CK(clk), 
        .Q(\reg_array[56][6] ) );
  dffphqx1_u \reg_array_reg[56][5]  ( .D(status_i[261]), .E(n493), .CK(clk), 
        .Q(\reg_array[56][5] ) );
  dffphqx1_u \reg_array_reg[56][4]  ( .D(status_i[260]), .E(n494), .CK(clk), 
        .Q(\reg_array[56][4] ) );
  dffphqx1_u \reg_array_reg[56][3]  ( .D(status_i[259]), .E(n496), .CK(clk), 
        .Q(\reg_array[56][3] ) );
  dffphqx1_u \reg_array_reg[56][2]  ( .D(status_i[258]), .E(n493), .CK(clk), 
        .Q(\reg_array[56][2] ) );
  dffphqx1_u \reg_array_reg[56][1]  ( .D(status_i[257]), .E(n496), .CK(clk), 
        .Q(\reg_array[56][1] ) );
  dffphqx1_u \reg_array_reg[56][0]  ( .D(status_i[256]), .E(n496), .CK(clk), 
        .Q(\reg_array[56][0] ) );
  dffphqx1_u \reg_array_reg[55][7]  ( .D(status_i[255]), .E(n494), .CK(clk), 
        .Q(\reg_array[55][7] ) );
  dffphqx1_u \reg_array_reg[55][6]  ( .D(status_i[254]), .E(n490), .CK(clk), 
        .Q(\reg_array[55][6] ) );
  dffphqx1_u \reg_array_reg[55][5]  ( .D(status_i[253]), .E(n494), .CK(clk), 
        .Q(\reg_array[55][5] ) );
  dffphqx1_u \reg_array_reg[55][4]  ( .D(status_i[252]), .E(n490), .CK(clk), 
        .Q(\reg_array[55][4] ) );
  dffphqx1_u \reg_array_reg[55][3]  ( .D(status_i[251]), .E(n490), .CK(clk), 
        .Q(\reg_array[55][3] ) );
  dffphqx1_u \reg_array_reg[55][2]  ( .D(status_i[250]), .E(n492), .CK(clk), 
        .Q(\reg_array[55][2] ) );
  dffphqx1_u \reg_array_reg[55][1]  ( .D(status_i[249]), .E(n493), .CK(clk), 
        .Q(\reg_array[55][1] ) );
  dffphqx1_u \reg_array_reg[55][0]  ( .D(status_i[248]), .E(n494), .CK(clk), 
        .Q(\reg_array[55][0] ) );
  dffphqx1_u \reg_array_reg[54][7]  ( .D(status_i[247]), .E(n496), .CK(clk), 
        .Q(\reg_array[54][7] ) );
  dffphqx1_u \reg_array_reg[54][6]  ( .D(status_i[246]), .E(n498), .CK(clk), 
        .Q(\reg_array[54][6] ) );
  dffphqx1_u \reg_array_reg[54][5]  ( .D(status_i[245]), .E(n494), .CK(clk), 
        .Q(\reg_array[54][5] ) );
  dffphqx1_u \reg_array_reg[54][4]  ( .D(status_i[244]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[54][4] ) );
  dffphqx1_u \reg_array_reg[54][3]  ( .D(status_i[243]), .E(n492), .CK(clk), 
        .Q(\reg_array[54][3] ) );
  dffphqx1_u \reg_array_reg[54][2]  ( .D(status_i[242]), .E(n493), .CK(clk), 
        .Q(\reg_array[54][2] ) );
  dffphqx1_u \reg_array_reg[54][1]  ( .D(status_i[241]), .E(n496), .CK(clk), 
        .Q(\reg_array[54][1] ) );
  dffphqx1_u \reg_array_reg[54][0]  ( .D(status_i[240]), .E(n498), .CK(clk), 
        .Q(\reg_array[54][0] ) );
  dffphqx1_u \reg_array_reg[53][7]  ( .D(status_i[239]), .E(n493), .CK(clk), 
        .Q(\reg_array[53][7] ) );
  dffphqx1_u \reg_array_reg[53][6]  ( .D(status_i[238]), .E(n498), .CK(clk), 
        .Q(\reg_array[53][6] ) );
  dffphqx1_u \reg_array_reg[53][5]  ( .D(status_i[237]), .E(n493), .CK(clk), 
        .Q(\reg_array[53][5] ) );
  dffphqx1_u \reg_array_reg[53][4]  ( .D(status_i[236]), .E(n498), .CK(clk), 
        .Q(\reg_array[53][4] ) );
  dffphqx1_u \reg_array_reg[53][3]  ( .D(status_i[235]), .E(n490), .CK(clk), 
        .Q(\reg_array[53][3] ) );
  dffphqx1_u \reg_array_reg[53][2]  ( .D(status_i[234]), .E(n498), .CK(clk), 
        .Q(\reg_array[53][2] ) );
  dffphqx1_u \reg_array_reg[53][1]  ( .D(status_i[233]), .E(n498), .CK(clk), 
        .Q(\reg_array[53][1] ) );
  dffphqx1_u \reg_array_reg[53][0]  ( .D(status_i[232]), .E(n494), .CK(clk), 
        .Q(\reg_array[53][0] ) );
  dffphqx1_u \reg_array_reg[52][7]  ( .D(status_i[231]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[52][7] ) );
  dffphqx1_u \reg_array_reg[52][6]  ( .D(status_i[230]), .E(n494), .CK(clk), 
        .Q(\reg_array[52][6] ) );
  dffphqx1_u \reg_array_reg[52][5]  ( .D(status_i[229]), .E(n493), .CK(clk), 
        .Q(\reg_array[52][5] ) );
  dffphqx1_u \reg_array_reg[52][4]  ( .D(status_i[228]), .E(n492), .CK(clk), 
        .Q(\reg_array[52][4] ) );
  dffphqx1_u \reg_array_reg[52][3]  ( .D(status_i[227]), .E(n498), .CK(clk), 
        .Q(\reg_array[52][3] ) );
  dffphqx1_u \reg_array_reg[52][2]  ( .D(status_i[226]), .E(n492), .CK(clk), 
        .Q(\reg_array[52][2] ) );
  dffphqx1_u \reg_array_reg[52][1]  ( .D(status_i[225]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[52][1] ) );
  dffphqx1_u \reg_array_reg[52][0]  ( .D(status_i[224]), .E(n494), .CK(clk), 
        .Q(\reg_array[52][0] ) );
  dffphqx1_u \reg_array_reg[51][7]  ( .D(status_i[223]), .E(n498), .CK(clk), 
        .Q(\reg_array[51][7] ) );
  dffphqx1_u \reg_array_reg[51][6]  ( .D(status_i[222]), .E(n492), .CK(clk), 
        .Q(\reg_array[51][6] ) );
  dffphqx1_u \reg_array_reg[51][5]  ( .D(status_i[221]), .E(n493), .CK(clk), 
        .Q(\reg_array[51][5] ) );
  dffphqx1_u \reg_array_reg[51][4]  ( .D(status_i[220]), .E(n490), .CK(clk), 
        .Q(\reg_array[51][4] ) );
  dffphqx1_u \reg_array_reg[51][3]  ( .D(status_i[219]), .E(n493), .CK(clk), 
        .Q(\reg_array[51][3] ) );
  dffphqx1_u \reg_array_reg[51][2]  ( .D(status_i[218]), .E(n498), .CK(clk), 
        .Q(\reg_array[51][2] ) );
  dffphqx1_u \reg_array_reg[51][1]  ( .D(status_i[217]), .E(n492), .CK(clk), 
        .Q(\reg_array[51][1] ) );
  dffphqx1_u \reg_array_reg[51][0]  ( .D(status_i[216]), .E(n496), .CK(clk), 
        .Q(\reg_array[51][0] ) );
  dffphqx1_u \reg_array_reg[50][7]  ( .D(status_i[215]), .E(n496), .CK(clk), 
        .Q(\reg_array[50][7] ) );
  dffphqx1_u \reg_array_reg[50][6]  ( .D(status_i[214]), .E(n494), .CK(clk), 
        .Q(\reg_array[50][6] ) );
  dffphqx1_u \reg_array_reg[50][5]  ( .D(status_i[213]), .E(n493), .CK(clk), 
        .Q(\reg_array[50][5] ) );
  dffphqx1_u \reg_array_reg[50][4]  ( .D(status_i[212]), .E(n492), .CK(clk), 
        .Q(\reg_array[50][4] ) );
  dffphqx1_u \reg_array_reg[50][3]  ( .D(status_i[211]), .E(n493), .CK(clk), 
        .Q(\reg_array[50][3] ) );
  dffphqx1_u \reg_array_reg[50][2]  ( .D(status_i[210]), .E(n494), .CK(clk), 
        .Q(\reg_array[50][2] ) );
  dffphqx1_u \reg_array_reg[50][1]  ( .D(status_i[209]), .E(n496), .CK(clk), 
        .Q(\reg_array[50][1] ) );
  dffphqx1_u \reg_array_reg[50][0]  ( .D(status_i[208]), .E(n494), .CK(clk), 
        .Q(\reg_array[50][0] ) );
  dffphqx1_u \reg_array_reg[49][7]  ( .D(status_i[207]), .E(n494), .CK(clk), 
        .Q(\reg_array[49][7] ) );
  dffphqx1_u \reg_array_reg[49][6]  ( .D(status_i[206]), .E(n492), .CK(clk), 
        .Q(\reg_array[49][6] ) );
  dffphqx1_u \reg_array_reg[49][5]  ( .D(status_i[205]), .E(n492), .CK(clk), 
        .Q(\reg_array[49][5] ) );
  dffphqx1_u \reg_array_reg[49][4]  ( .D(status_i[204]), .E(n494), .CK(clk), 
        .Q(\reg_array[49][4] ) );
  dffphqx1_u \reg_array_reg[49][3]  ( .D(status_i[203]), .E(n496), .CK(clk), 
        .Q(\reg_array[49][3] ) );
  dffphqx1_u \reg_array_reg[49][2]  ( .D(status_i[202]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[49][2] ) );
  dffphqx1_u \reg_array_reg[49][1]  ( .D(status_i[201]), .E(n498), .CK(clk), 
        .Q(\reg_array[49][1] ) );
  dffphqx1_u \reg_array_reg[49][0]  ( .D(status_i[200]), .E(n492), .CK(clk), 
        .Q(\reg_array[49][0] ) );
  dffphqx1_u \reg_array_reg[48][7]  ( .D(status_i[199]), .E(n494), .CK(clk), 
        .Q(\reg_array[48][7] ) );
  dffphqx1_u \reg_array_reg[48][6]  ( .D(status_i[198]), .E(n490), .CK(clk), 
        .Q(\reg_array[48][6] ) );
  dffphqx1_u \reg_array_reg[48][5]  ( .D(status_i[197]), .E(n496), .CK(clk), 
        .Q(\reg_array[48][5] ) );
  dffphqx1_u \reg_array_reg[48][4]  ( .D(status_i[196]), .E(n496), .CK(clk), 
        .Q(\reg_array[48][4] ) );
  dffphqx1_u \reg_array_reg[48][3]  ( .D(status_i[195]), .E(n492), .CK(clk), 
        .Q(\reg_array[48][3] ) );
  dffphqx1_u \reg_array_reg[48][2]  ( .D(status_i[194]), .E(n493), .CK(clk), 
        .Q(\reg_array[48][2] ) );
  dffphqx1_u \reg_array_reg[48][1]  ( .D(status_i[193]), .E(n494), .CK(clk), 
        .Q(\reg_array[48][1] ) );
  dffphqx1_u \reg_array_reg[48][0]  ( .D(status_i[192]), .E(n496), .CK(clk), 
        .Q(\reg_array[48][0] ) );
  dffphqx1_u \reg_array_reg[47][7]  ( .D(status_i[191]), .E(n492), .CK(clk), 
        .Q(\reg_array[47][7] ) );
  dffphqx1_u \reg_array_reg[47][6]  ( .D(status_i[190]), .E(n498), .CK(clk), 
        .Q(\reg_array[47][6] ) );
  dffphqx1_u \reg_array_reg[47][5]  ( .D(status_i[189]), .E(n494), .CK(clk), 
        .Q(\reg_array[47][5] ) );
  dffphqx1_u \reg_array_reg[47][4]  ( .D(status_i[188]), .E(n492), .CK(clk), 
        .Q(\reg_array[47][4] ) );
  dffphqx1_u \reg_array_reg[47][3]  ( .D(status_i[187]), .E(n492), .CK(clk), 
        .Q(\reg_array[47][3] ) );
  dffphqx1_u \reg_array_reg[47][2]  ( .D(status_i[186]), .E(n498), .CK(clk), 
        .Q(\reg_array[47][2] ) );
  dffphqx1_u \reg_array_reg[47][1]  ( .D(status_i[185]), .E(n496), .CK(clk), 
        .Q(\reg_array[47][1] ) );
  dffphqx1_u \reg_array_reg[47][0]  ( .D(status_i[184]), .E(n490), .CK(clk), 
        .Q(\reg_array[47][0] ) );
  dffphqx1_u \reg_array_reg[46][7]  ( .D(status_i[183]), .E(n490), .CK(clk), 
        .Q(\reg_array[46][7] ) );
  dffphqx1_u \reg_array_reg[46][6]  ( .D(status_i[182]), .E(n496), .CK(clk), 
        .Q(\reg_array[46][6] ) );
  dffphqx1_u \reg_array_reg[46][5]  ( .D(status_i[181]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[46][5] ) );
  dffphqx1_u \reg_array_reg[46][4]  ( .D(status_i[180]), .E(n490), .CK(clk), 
        .Q(\reg_array[46][4] ) );
  dffphqx1_u \reg_array_reg[46][3]  ( .D(status_i[179]), .E(n498), .CK(clk), 
        .Q(\reg_array[46][3] ) );
  dffphqx1_u \reg_array_reg[46][2]  ( .D(status_i[178]), .E(n492), .CK(clk), 
        .Q(\reg_array[46][2] ) );
  dffphqx1_u \reg_array_reg[46][1]  ( .D(status_i[177]), .E(n494), .CK(clk), 
        .Q(\reg_array[46][1] ) );
  dffphqx1_u \reg_array_reg[46][0]  ( .D(status_i[176]), .E(n494), .CK(clk), 
        .Q(\reg_array[46][0] ) );
  dffphqx1_u \reg_array_reg[45][7]  ( .D(status_i[175]), .E(n490), .CK(clk), 
        .Q(\reg_array[45][7] ) );
  dffphqx1_u \reg_array_reg[45][6]  ( .D(status_i[174]), .E(n490), .CK(clk), 
        .Q(\reg_array[45][6] ) );
  dffphqx1_u \reg_array_reg[45][5]  ( .D(status_i[173]), .E(n493), .CK(clk), 
        .Q(\reg_array[45][5] ) );
  dffphqx1_u \reg_array_reg[45][4]  ( .D(status_i[172]), .E(n494), .CK(clk), 
        .Q(\reg_array[45][4] ) );
  dffphqx1_u \reg_array_reg[45][3]  ( .D(status_i[171]), .E(n492), .CK(clk), 
        .Q(\reg_array[45][3] ) );
  dffphqx1_u \reg_array_reg[45][2]  ( .D(status_i[170]), .E(n493), .CK(clk), 
        .Q(\reg_array[45][2] ) );
  dffphqx1_u \reg_array_reg[45][1]  ( .D(status_i[169]), .E(n494), .CK(clk), 
        .Q(\reg_array[45][1] ) );
  dffphqx1_u \reg_array_reg[45][0]  ( .D(status_i[168]), .E(n496), .CK(clk), 
        .Q(\reg_array[45][0] ) );
  dffphqx1_u \reg_array_reg[44][7]  ( .D(status_i[167]), .E(n496), .CK(clk), 
        .Q(\reg_array[44][7] ) );
  dffphqx1_u \reg_array_reg[44][6]  ( .D(status_i[166]), .E(n494), .CK(clk), 
        .Q(\reg_array[44][6] ) );
  dffphqx1_u \reg_array_reg[44][5]  ( .D(status_i[165]), .E(n498), .CK(clk), 
        .Q(\reg_array[44][5] ) );
  dffphqx1_u \reg_array_reg[44][4]  ( .D(status_i[164]), .E(n496), .CK(clk), 
        .Q(\reg_array[44][4] ) );
  dffphqx1_u \reg_array_reg[44][3]  ( .D(status_i[163]), .E(n490), .CK(clk), 
        .Q(\reg_array[44][3] ) );
  dffphqx1_u \reg_array_reg[44][2]  ( .D(status_i[162]), .E(n498), .CK(clk), 
        .Q(\reg_array[44][2] ) );
  dffphqx1_u \reg_array_reg[44][1]  ( .D(status_i[161]), .E(n493), .CK(clk), 
        .Q(\reg_array[44][1] ) );
  dffphqx1_u \reg_array_reg[44][0]  ( .D(status_i[160]), .E(n498), .CK(clk), 
        .Q(\reg_array[44][0] ) );
  dffphqx1_u \reg_array_reg[43][7]  ( .D(status_i[159]), .E(n498), .CK(clk), 
        .Q(\reg_array[43][7] ) );
  dffphqx1_u \reg_array_reg[43][6]  ( .D(status_i[158]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[43][6] ) );
  dffphqx1_u \reg_array_reg[43][5]  ( .D(status_i[157]), .E(n494), .CK(clk), 
        .Q(\reg_array[43][5] ) );
  dffphqx1_u \reg_array_reg[43][4]  ( .D(status_i[156]), .E(n496), .CK(clk), 
        .Q(\reg_array[43][4] ) );
  dffphqx1_u \reg_array_reg[43][3]  ( .D(status_i[155]), .E(n494), .CK(clk), 
        .Q(\reg_array[43][3] ) );
  dffphqx1_u \reg_array_reg[43][2]  ( .D(status_i[154]), .E(n490), .CK(clk), 
        .Q(\reg_array[43][2] ) );
  dffphqx1_u \reg_array_reg[43][1]  ( .D(status_i[153]), .E(n494), .CK(clk), 
        .Q(\reg_array[43][1] ) );
  dffphqx1_u \reg_array_reg[43][0]  ( .D(status_i[152]), .E(n493), .CK(clk), 
        .Q(\reg_array[43][0] ) );
  dffphqx1_u \reg_array_reg[42][7]  ( .D(status_i[151]), .E(n492), .CK(clk), 
        .Q(\reg_array[42][7] ) );
  dffphqx1_u \reg_array_reg[42][6]  ( .D(status_i[150]), .E(n493), .CK(clk), 
        .Q(\reg_array[42][6] ) );
  dffphqx1_u \reg_array_reg[42][5]  ( .D(status_i[149]), .E(n494), .CK(clk), 
        .Q(\reg_array[42][5] ) );
  dffphqx1_u \reg_array_reg[42][4]  ( .D(status_i[148]), .E(n494), .CK(clk), 
        .Q(\reg_array[42][4] ) );
  dffphqx1_u \reg_array_reg[42][3]  ( .D(status_i[147]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[42][3] ) );
  dffphqx1_u \reg_array_reg[42][2]  ( .D(status_i[146]), .E(n498), .CK(clk), 
        .Q(\reg_array[42][2] ) );
  dffphqx1_u \reg_array_reg[42][1]  ( .D(status_i[145]), .E(n490), .CK(clk), 
        .Q(\reg_array[42][1] ) );
  dffphqx1_u \reg_array_reg[42][0]  ( .D(status_i[144]), .E(n494), .CK(clk), 
        .Q(\reg_array[42][0] ) );
  dffphqx1_u \reg_array_reg[41][7]  ( .D(status_i[143]), .E(n490), .CK(clk), 
        .Q(\reg_array[41][7] ) );
  dffphqx1_u \reg_array_reg[41][6]  ( .D(status_i[142]), .E(n496), .CK(clk), 
        .Q(\reg_array[41][6] ) );
  dffphqx1_u \reg_array_reg[41][5]  ( .D(status_i[141]), .E(n490), .CK(clk), 
        .Q(\reg_array[41][5] ) );
  dffphqx1_u \reg_array_reg[41][4]  ( .D(status_i[140]), .E(n490), .CK(clk), 
        .Q(\reg_array[41][4] ) );
  dffphqx1_u \reg_array_reg[41][3]  ( .D(status_i[139]), .E(n490), .CK(clk), 
        .Q(\reg_array[41][3] ) );
  dffphqx1_u \reg_array_reg[41][2]  ( .D(status_i[138]), .E(n492), .CK(clk), 
        .Q(\reg_array[41][2] ) );
  dffphqx1_u \reg_array_reg[41][1]  ( .D(status_i[137]), .E(n493), .CK(clk), 
        .Q(\reg_array[41][1] ) );
  dffphqx1_u \reg_array_reg[41][0]  ( .D(status_i[136]), .E(n493), .CK(clk), 
        .Q(\reg_array[41][0] ) );
  dffphqx1_u \reg_array_reg[40][7]  ( .D(status_i[135]), .E(n496), .CK(clk), 
        .Q(\reg_array[40][7] ) );
  dffphqx1_u \reg_array_reg[40][6]  ( .D(status_i[134]), .E(n492), .CK(clk), 
        .Q(\reg_array[40][6] ) );
  dffphqx1_u \reg_array_reg[40][5]  ( .D(status_i[133]), .E(n498), .CK(clk), 
        .Q(\reg_array[40][5] ) );
  dffphqx1_u \reg_array_reg[40][4]  ( .D(status_i[132]), .E(n490), .CK(clk), 
        .Q(\reg_array[40][4] ) );
  dffphqx1_u \reg_array_reg[40][3]  ( .D(status_i[131]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[40][3] ) );
  dffphqx1_u \reg_array_reg[40][2]  ( .D(status_i[130]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[40][2] ) );
  dffphqx1_u \reg_array_reg[40][1]  ( .D(status_i[129]), .E(n498), .CK(clk), 
        .Q(\reg_array[40][1] ) );
  dffphqx1_u \reg_array_reg[40][0]  ( .D(status_i[128]), .E(n498), .CK(clk), 
        .Q(\reg_array[40][0] ) );
  dffphqx1_u \reg_array_reg[39][7]  ( .D(status_i[127]), .E(n490), .CK(clk), 
        .Q(\reg_array[39][7] ) );
  dffphqx1_u \reg_array_reg[39][6]  ( .D(status_i[126]), .E(n494), .CK(clk), 
        .Q(\reg_array[39][6] ) );
  dffphqx1_u \reg_array_reg[39][5]  ( .D(status_i[125]), .E(n490), .CK(clk), 
        .Q(\reg_array[39][5] ) );
  dffphqx1_u \reg_array_reg[39][4]  ( .D(status_i[124]), .E(n490), .CK(clk), 
        .Q(\reg_array[39][4] ) );
  dffphqx1_u \reg_array_reg[39][3]  ( .D(status_i[123]), .E(n492), .CK(clk), 
        .Q(\reg_array[39][3] ) );
  dffphqx1_u \reg_array_reg[39][2]  ( .D(status_i[122]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[39][2] ) );
  dffphqx1_u \reg_array_reg[39][1]  ( .D(status_i[121]), .E(n492), .CK(clk), 
        .Q(\reg_array[39][1] ) );
  dffphqx1_u \reg_array_reg[39][0]  ( .D(status_i[120]), .E(n492), .CK(clk), 
        .Q(\reg_array[39][0] ) );
  dffphqx1_u \reg_array_reg[38][7]  ( .D(status_i[119]), .E(n498), .CK(clk), 
        .Q(\reg_array[38][7] ) );
  dffphqx1_u \reg_array_reg[38][6]  ( .D(status_i[118]), .E(n496), .CK(clk), 
        .Q(\reg_array[38][6] ) );
  dffphqx1_u \reg_array_reg[38][5]  ( .D(status_i[117]), .E(n492), .CK(clk), 
        .Q(\reg_array[38][5] ) );
  dffphqx1_u \reg_array_reg[38][4]  ( .D(status_i[116]), .E(n498), .CK(clk), 
        .Q(\reg_array[38][4] ) );
  dffphqx1_u \reg_array_reg[38][3]  ( .D(status_i[115]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[38][3] ) );
  dffphqx1_u \reg_array_reg[38][2]  ( .D(status_i[114]), .E(n492), .CK(clk), 
        .Q(\reg_array[38][2] ) );
  dffphqx1_u \reg_array_reg[38][1]  ( .D(status_i[113]), .E(n498), .CK(clk), 
        .Q(\reg_array[38][1] ) );
  dffphqx1_u \reg_array_reg[38][0]  ( .D(status_i[112]), .E(n493), .CK(clk), 
        .Q(\reg_array[38][0] ) );
  dffphqx1_u \reg_array_reg[37][7]  ( .D(status_i[111]), .E(n494), .CK(clk), 
        .Q(\reg_array[37][7] ) );
  dffphqx1_u \reg_array_reg[37][6]  ( .D(status_i[110]), .E(n493), .CK(clk), 
        .Q(\reg_array[37][6] ) );
  dffphqx1_u \reg_array_reg[37][5]  ( .D(status_i[109]), .E(n493), .CK(clk), 
        .Q(\reg_array[37][5] ) );
  dffphqx1_u \reg_array_reg[37][4]  ( .D(status_i[108]), .E(n490), .CK(clk), 
        .Q(\reg_array[37][4] ) );
  dffphqx1_u \reg_array_reg[37][3]  ( .D(status_i[107]), .E(n493), .CK(clk), 
        .Q(\reg_array[37][3] ) );
  dffphqx1_u \reg_array_reg[37][2]  ( .D(status_i[106]), .E(n498), .CK(clk), 
        .Q(\reg_array[37][2] ) );
  dffphqx1_u \reg_array_reg[37][1]  ( .D(status_i[105]), .E(n493), .CK(clk), 
        .Q(\reg_array[37][1] ) );
  dffphqx1_u \reg_array_reg[37][0]  ( .D(status_i[104]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[37][0] ) );
  dffphqx1_u \reg_array_reg[36][7]  ( .D(status_i[103]), .E(n492), .CK(clk), 
        .Q(\reg_array[36][7] ) );
  dffphqx1_u \reg_array_reg[36][6]  ( .D(status_i[102]), .E(n496), .CK(clk), 
        .Q(\reg_array[36][6] ) );
  dffphqx1_u \reg_array_reg[36][5]  ( .D(status_i[101]), .E(n494), .CK(clk), 
        .Q(\reg_array[36][5] ) );
  dffphqx1_u \reg_array_reg[36][4]  ( .D(status_i[100]), .E(n494), .CK(clk), 
        .Q(\reg_array[36][4] ) );
  dffphqx1_u \reg_array_reg[36][3]  ( .D(status_i[99]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[36][3] ) );
  dffphqx1_u \reg_array_reg[36][2]  ( .D(status_i[98]), .E(n498), .CK(clk), 
        .Q(\reg_array[36][2] ) );
  dffphqx1_u \reg_array_reg[36][1]  ( .D(status_i[97]), .E(n494), .CK(clk), 
        .Q(\reg_array[36][1] ) );
  dffphqx1_u \reg_array_reg[36][0]  ( .D(status_i[96]), .E(n496), .CK(clk), 
        .Q(\reg_array[36][0] ) );
  dffphqx1_u \reg_array_reg[35][7]  ( .D(status_i[95]), .E(n493), .CK(clk), 
        .Q(\reg_array[35][7] ) );
  dffphqx1_u \reg_array_reg[35][6]  ( .D(status_i[94]), .E(n492), .CK(clk), 
        .Q(\reg_array[35][6] ) );
  dffphqx1_u \reg_array_reg[35][5]  ( .D(status_i[93]), .E(n490), .CK(clk), 
        .Q(\reg_array[35][5] ) );
  dffphqx1_u \reg_array_reg[35][4]  ( .D(status_i[92]), .E(n490), .CK(clk), 
        .Q(\reg_array[35][4] ) );
  dffphqx1_u \reg_array_reg[35][3]  ( .D(status_i[91]), .E(n492), .CK(clk), 
        .Q(\reg_array[35][3] ) );
  dffphqx1_u \reg_array_reg[35][2]  ( .D(status_i[90]), .E(n496), .CK(clk), 
        .Q(\reg_array[35][2] ) );
  dffphqx1_u \reg_array_reg[35][1]  ( .D(status_i[89]), .E(n490), .CK(clk), 
        .Q(\reg_array[35][1] ) );
  dffphqx1_u \reg_array_reg[35][0]  ( .D(status_i[88]), .E(n493), .CK(clk), 
        .Q(\reg_array[35][0] ) );
  dffphqx1_u \reg_array_reg[34][7]  ( .D(status_i[87]), .E(n492), .CK(clk), 
        .Q(\reg_array[34][7] ) );
  dffphqx1_u \reg_array_reg[34][6]  ( .D(status_i[86]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[34][6] ) );
  dffphqx1_u \reg_array_reg[34][5]  ( .D(status_i[85]), .E(n494), .CK(clk), 
        .Q(\reg_array[34][5] ) );
  dffphqx1_u \reg_array_reg[34][4]  ( .D(status_i[84]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[34][4] ) );
  dffphqx1_u \reg_array_reg[34][3]  ( .D(status_i[83]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[34][3] ) );
  dffphqx1_u \reg_array_reg[34][2]  ( .D(status_i[82]), .E(n498), .CK(clk), 
        .Q(\reg_array[34][2] ) );
  dffphqx1_u \reg_array_reg[34][1]  ( .D(status_i[81]), .E(n494), .CK(clk), 
        .Q(\reg_array[34][1] ) );
  dffphqx1_u \reg_array_reg[34][0]  ( .D(status_i[80]), .E(n493), .CK(clk), 
        .Q(\reg_array[34][0] ) );
  dffphqx1_u \reg_array_reg[33][7]  ( .D(status_i[79]), .E(n492), .CK(clk), 
        .Q(\reg_array[33][7] ) );
  dffphqx1_u \reg_array_reg[33][6]  ( .D(status_i[78]), .E(n494), .CK(clk), 
        .Q(\reg_array[33][6] ) );
  dffphqx1_u \reg_array_reg[33][5]  ( .D(status_i[77]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[33][5] ) );
  dffphqx1_u \reg_array_reg[33][4]  ( .D(status_i[76]), .E(n490), .CK(clk), 
        .Q(\reg_array[33][4] ) );
  dffphqx1_u \reg_array_reg[33][3]  ( .D(status_i[75]), .E(n492), .CK(clk), 
        .Q(\reg_array[33][3] ) );
  dffphqx1_u \reg_array_reg[33][2]  ( .D(status_i[74]), .E(n498), .CK(clk), 
        .Q(\reg_array[33][2] ) );
  dffphqx1_u \reg_array_reg[33][1]  ( .D(status_i[73]), .E(n492), .CK(clk), 
        .Q(\reg_array[33][1] ) );
  dffphqx1_u \reg_array_reg[33][0]  ( .D(status_i[72]), .E(n493), .CK(clk), 
        .Q(\reg_array[33][0] ) );
  dffphqx1_u \reg_array_reg[32][7]  ( .D(status_i[71]), .E(n496), .CK(clk), 
        .Q(\reg_array[32][7] ) );
  dffphqx1_u \reg_array_reg[32][6]  ( .D(status_i[70]), .E(n490), .CK(clk), 
        .Q(\reg_array[32][6] ) );
  dffphqx1_u \reg_array_reg[32][5]  ( .D(status_i[69]), .E(n490), .CK(clk), 
        .Q(\reg_array[32][5] ) );
  dffphqx1_u \reg_array_reg[32][4]  ( .D(status_i[68]), .E(n490), .CK(clk), 
        .Q(\reg_array[32][4] ) );
  dffphqx1_u \reg_array_reg[32][3]  ( .D(status_i[67]), .E(n496), .CK(clk), 
        .Q(\reg_array[32][3] ) );
  dffphqx1_u \reg_array_reg[32][2]  ( .D(status_i[66]), .E(n498), .CK(clk), 
        .Q(\reg_array[32][2] ) );
  dffphqx1_u \reg_array_reg[32][1]  ( .D(status_i[65]), .E(n493), .CK(clk), 
        .Q(\reg_array[32][1] ) );
  dffphqx1_u \reg_array_reg[32][0]  ( .D(status_i[64]), .E(n490), .CK(clk), 
        .Q(\reg_array[32][0] ) );
  dffphqx1_u \reg_array_reg[31][7]  ( .D(status_i[63]), .E(n493), .CK(clk), 
        .Q(\reg_array[31][7] ) );
  dffphqx1_u \reg_array_reg[31][6]  ( .D(status_i[62]), .E(n490), .CK(clk), 
        .Q(\reg_array[31][6] ) );
  dffphqx1_u \reg_array_reg[31][5]  ( .D(status_i[61]), .E(n493), .CK(clk), 
        .Q(\reg_array[31][5] ) );
  dffphqx1_u \reg_array_reg[31][4]  ( .D(status_i[60]), .E(n496), .CK(clk), 
        .Q(\reg_array[31][4] ) );
  dffphqx1_u \reg_array_reg[31][3]  ( .D(status_i[59]), .E(n496), .CK(clk), 
        .Q(\reg_array[31][3] ) );
  dffphqx1_u \reg_array_reg[31][2]  ( .D(status_i[58]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[31][2] ) );
  dffphqx1_u \reg_array_reg[31][1]  ( .D(status_i[57]), .E(n490), .CK(clk), 
        .Q(\reg_array[31][1] ) );
  dffphqx1_u \reg_array_reg[31][0]  ( .D(status_i[56]), .E(n492), .CK(clk), 
        .Q(\reg_array[31][0] ) );
  dffphqx1_u \reg_array_reg[30][7]  ( .D(status_i[55]), .E(n490), .CK(clk), 
        .Q(\reg_array[30][7] ) );
  dffphqx1_u \reg_array_reg[30][6]  ( .D(status_i[54]), .E(n492), .CK(clk), 
        .Q(\reg_array[30][6] ) );
  dffphqx1_u \reg_array_reg[30][5]  ( .D(status_i[53]), .E(n490), .CK(clk), 
        .Q(\reg_array[30][5] ) );
  dffphqx1_u \reg_array_reg[30][4]  ( .D(status_i[52]), .E(n490), .CK(clk), 
        .Q(\reg_array[30][4] ) );
  dffphqx1_u \reg_array_reg[30][3]  ( .D(status_i[51]), .E(n498), .CK(clk), 
        .Q(\reg_array[30][3] ) );
  dffphqx1_u \reg_array_reg[30][2]  ( .D(status_i[50]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[30][2] ) );
  dffphqx1_u \reg_array_reg[30][1]  ( .D(status_i[49]), .E(n498), .CK(clk), 
        .Q(\reg_array[30][1] ) );
  dffphqx1_u \reg_array_reg[30][0]  ( .D(status_i[48]), .E(n492), .CK(clk), 
        .Q(\reg_array[30][0] ) );
  dffphqx1_u \reg_array_reg[29][7]  ( .D(status_i[47]), .E(n494), .CK(clk), 
        .Q(\reg_array[29][7] ) );
  dffphqx1_u \reg_array_reg[29][6]  ( .D(status_i[46]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[29][6] ) );
  dffphqx1_u \reg_array_reg[29][5]  ( .D(status_i[45]), .E(n496), .CK(clk), 
        .Q(\reg_array[29][5] ) );
  dffphqx1_u \reg_array_reg[29][4]  ( .D(status_i[44]), .E(n498), .CK(clk), 
        .Q(\reg_array[29][4] ) );
  dffphqx1_u \reg_array_reg[29][3]  ( .D(status_i[43]), .E(n493), .CK(clk), 
        .Q(\reg_array[29][3] ) );
  dffphqx1_u \reg_array_reg[29][2]  ( .D(status_i[42]), .E(n494), .CK(clk), 
        .Q(\reg_array[29][2] ) );
  dffphqx1_u \reg_array_reg[29][1]  ( .D(status_i[41]), .E(n490), .CK(clk), 
        .Q(\reg_array[29][1] ) );
  dffphqx1_u \reg_array_reg[29][0]  ( .D(status_i[40]), .E(n498), .CK(clk), 
        .Q(\reg_array[29][0] ) );
  dffphqx1_u \reg_array_reg[28][7]  ( .D(status_i[39]), .E(n494), .CK(clk), 
        .Q(\reg_array[28][7] ) );
  dffphqx1_u \reg_array_reg[28][6]  ( .D(status_i[38]), .E(n490), .CK(clk), 
        .Q(\reg_array[28][6] ) );
  dffphqx1_u \reg_array_reg[28][5]  ( .D(status_i[37]), .E(n498), .CK(clk), 
        .Q(\reg_array[28][5] ) );
  dffphqx1_u \reg_array_reg[28][4]  ( .D(status_i[36]), .E(n494), .CK(clk), 
        .Q(\reg_array[28][4] ) );
  dffphqx1_u \reg_array_reg[28][3]  ( .D(status_i[35]), .E(n496), .CK(clk), 
        .Q(\reg_array[28][3] ) );
  dffphqx1_u \reg_array_reg[28][2]  ( .D(status_i[34]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[28][2] ) );
  dffphqx1_u \reg_array_reg[28][1]  ( .D(status_i[33]), .E(n498), .CK(clk), 
        .Q(\reg_array[28][1] ) );
  dffphqx1_u \reg_array_reg[28][0]  ( .D(status_i[32]), .E(n498), .CK(clk), 
        .Q(\reg_array[28][0] ) );
  dffphqx1_u \reg_array_reg[27][7]  ( .D(status_i[31]), .E(n498), .CK(clk), 
        .Q(\reg_array[27][7] ) );
  dffphqx1_u \reg_array_reg[27][6]  ( .D(status_i[30]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[27][6] ) );
  dffphqx1_u \reg_array_reg[27][5]  ( .D(status_i[29]), .E(n496), .CK(clk), 
        .Q(\reg_array[27][5] ) );
  dffphqx1_u \reg_array_reg[27][4]  ( .D(status_i[28]), .E(n490), .CK(clk), 
        .Q(\reg_array[27][4] ) );
  dffphqx1_u \reg_array_reg[27][3]  ( .D(status_i[27]), .E(n493), .CK(clk), 
        .Q(\reg_array[27][3] ) );
  dffphqx1_u \reg_array_reg[27][2]  ( .D(status_i[26]), .E(n496), .CK(clk), 
        .Q(\reg_array[27][2] ) );
  dffphqx1_u \reg_array_reg[27][1]  ( .D(status_i[25]), .E(n493), .CK(clk), 
        .Q(\reg_array[27][1] ) );
  dffphqx1_u \reg_array_reg[27][0]  ( .D(status_i[24]), .E(n493), .CK(clk), 
        .Q(\reg_array[27][0] ) );
  dffphqx1_u \reg_array_reg[26][7]  ( .D(status_i[23]), .E(n496), .CK(clk), 
        .Q(\reg_array[26][7] ) );
  dffphqx1_u \reg_array_reg[26][6]  ( .D(status_i[22]), .E(n493), .CK(clk), 
        .Q(\reg_array[26][6] ) );
  dffphqx1_u \reg_array_reg[26][5]  ( .D(status_i[21]), .E(n490), .CK(clk), 
        .Q(\reg_array[26][5] ) );
  dffphqx1_u \reg_array_reg[26][4]  ( .D(status_i[20]), .E(n496), .CK(clk), 
        .Q(\reg_array[26][4] ) );
  dffphqx1_u \reg_array_reg[26][3]  ( .D(status_i[19]), .E(n493), .CK(clk), 
        .Q(\reg_array[26][3] ) );
  dffphqx1_u \reg_array_reg[26][2]  ( .D(status_i[18]), .E(n492), .CK(clk), 
        .Q(\reg_array[26][2] ) );
  dffphqx1_u \reg_array_reg[26][1]  ( .D(status_i[17]), .E(n490), .CK(clk), 
        .Q(\reg_array[26][1] ) );
  dffphqx1_u \reg_array_reg[26][0]  ( .D(status_i[16]), .E(n490), .CK(clk), 
        .Q(\reg_array[26][0] ) );
  dffphqx1_u \reg_array_reg[25][7]  ( .D(status_i[15]), .E(n496), .CK(clk), 
        .Q(\reg_array[25][7] ) );
  dffphqx1_u \reg_array_reg[25][6]  ( .D(status_i[14]), .E(n494), .CK(clk), 
        .Q(\reg_array[25][6] ) );
  dffphqx1_u \reg_array_reg[25][5]  ( .D(status_i[13]), .E(n490), .CK(clk), 
        .Q(\reg_array[25][5] ) );
  dffphqx1_u \reg_array_reg[25][4]  ( .D(status_i[12]), .E(n493), .CK(clk), 
        .Q(\reg_array[25][4] ) );
  dffphqx1_u \reg_array_reg[25][3]  ( .D(status_i[11]), .E(n493), .CK(clk), 
        .Q(\reg_array[25][3] ) );
  dffphqx1_u \reg_array_reg[25][2]  ( .D(status_i[10]), .E(n496), .CK(clk), 
        .Q(\reg_array[25][2] ) );
  dffphqx1_u \reg_array_reg[25][1]  ( .D(status_i[9]), .E(n490), .CK(clk), .Q(
        \reg_array[25][1] ) );
  dffphqx1_u \reg_array_reg[25][0]  ( .D(status_i[8]), .E(n492), .CK(clk), .Q(
        \reg_array[25][0] ) );
  dffphqx1_u \reg_array_reg[24][7]  ( .D(status_i[7]), .E(n496), .CK(clk), .Q(
        \reg_array[24][7] ) );
  dffphqx1_u \reg_array_reg[24][6]  ( .D(status_i[6]), .E(n498), .CK(clk), .Q(
        \reg_array[24][6] ) );
  dffphqx1_u \reg_array_reg[24][5]  ( .D(status_i[5]), .E(n492), .CK(clk), .Q(
        \reg_array[24][5] ) );
  dffphqx1_u \reg_array_reg[24][4]  ( .D(status_i[4]), .E(n492), .CK(clk), .Q(
        \reg_array[24][4] ) );
  dffphqx1_u \reg_array_reg[24][3]  ( .D(status_i[3]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[24][3] ) );
  dffphqx1_u \reg_array_reg[24][2]  ( .D(status_i[2]), .E(n496), .CK(clk), .Q(
        \reg_array[24][2] ) );
  dffphqx1_u \reg_array_reg[24][1]  ( .D(status_i[1]), .E(n490), .CK(clk), .Q(
        \reg_array[24][1] ) );
  dffphqx1_u \reg_array_reg[24][0]  ( .D(status_i[0]), .E(rst_n), .CK(clk), 
        .Q(\reg_array[24][0] ) );
  dffphrqx1_u \reg_array_reg[23][7]  ( .D(wr_data[7]), .E(n24), .CK(clk), .RN(
        rst_n), .Q(control_o[191]) );
  dffphrqx1_u \reg_array_reg[23][6]  ( .D(wr_data[6]), .E(n24), .CK(clk), .RN(
        n490), .Q(control_o[190]) );
  dffphrqx1_u \reg_array_reg[23][5]  ( .D(wr_data[5]), .E(n24), .CK(clk), .RN(
        n490), .Q(control_o[189]) );
  dffphrqx1_u \reg_array_reg[23][4]  ( .D(wr_data[4]), .E(n24), .CK(clk), .RN(
        n496), .Q(control_o[188]) );
  dffphrqx1_u \reg_array_reg[23][3]  ( .D(wr_data[3]), .E(n24), .CK(clk), .RN(
        rst_n), .Q(control_o[187]) );
  dffphrqx1_u \reg_array_reg[23][2]  ( .D(wr_data[2]), .E(n24), .CK(clk), .RN(
        n498), .Q(control_o[186]) );
  dffphrqx1_u \reg_array_reg[23][1]  ( .D(wr_data[1]), .E(n24), .CK(clk), .RN(
        n494), .Q(control_o[185]) );
  dffphrqx1_u \reg_array_reg[23][0]  ( .D(wr_data[0]), .E(n24), .CK(clk), .RN(
        n496), .Q(control_o[184]) );
  dffphrqx1_u \reg_array_reg[22][7]  ( .D(wr_data[7]), .E(n23), .CK(clk), .RN(
        n496), .Q(control_o[183]) );
  dffphrqx1_u \reg_array_reg[22][6]  ( .D(wr_data[6]), .E(n23), .CK(clk), .RN(
        n498), .Q(control_o[182]) );
  dffphrqx1_u \reg_array_reg[22][5]  ( .D(wr_data[5]), .E(n23), .CK(clk), .RN(
        n490), .Q(control_o[181]) );
  dffphrqx1_u \reg_array_reg[22][4]  ( .D(wr_data[4]), .E(n23), .CK(clk), .RN(
        n493), .Q(control_o[180]) );
  dffphrqx1_u \reg_array_reg[22][3]  ( .D(wr_data[3]), .E(n23), .CK(clk), .RN(
        n492), .Q(control_o[179]) );
  dffphrqx1_u \reg_array_reg[22][2]  ( .D(wr_data[2]), .E(n23), .CK(clk), .RN(
        n490), .Q(control_o[178]) );
  dffphrqx1_u \reg_array_reg[22][1]  ( .D(wr_data[1]), .E(n23), .CK(clk), .RN(
        n493), .Q(control_o[177]) );
  dffphrqx1_u \reg_array_reg[22][0]  ( .D(wr_data[0]), .E(n23), .CK(clk), .RN(
        n498), .Q(control_o[176]) );
  dffphrqx1_u \reg_array_reg[21][7]  ( .D(wr_data[7]), .E(n22), .CK(clk), .RN(
        n493), .Q(control_o[175]) );
  dffphrqx1_u \reg_array_reg[21][6]  ( .D(wr_data[6]), .E(n22), .CK(clk), .RN(
        n493), .Q(control_o[174]) );
  dffphrqx1_u \reg_array_reg[21][5]  ( .D(wr_data[5]), .E(n22), .CK(clk), .RN(
        n492), .Q(control_o[173]) );
  dffphrqx1_u \reg_array_reg[21][4]  ( .D(wr_data[4]), .E(n22), .CK(clk), .RN(
        n494), .Q(control_o[172]) );
  dffphrqx1_u \reg_array_reg[21][3]  ( .D(wr_data[3]), .E(n22), .CK(clk), .RN(
        n496), .Q(control_o[171]) );
  dffphrqx1_u \reg_array_reg[21][2]  ( .D(wr_data[2]), .E(n22), .CK(clk), .RN(
        n496), .Q(control_o[170]) );
  dffphrqx1_u \reg_array_reg[21][1]  ( .D(wr_data[1]), .E(n22), .CK(clk), .RN(
        n496), .Q(control_o[169]) );
  dffphrqx1_u \reg_array_reg[21][0]  ( .D(wr_data[0]), .E(n22), .CK(clk), .RN(
        n496), .Q(control_o[168]) );
  dffphrqx1_u \reg_array_reg[20][7]  ( .D(wr_data[7]), .E(n21), .CK(clk), .RN(
        n496), .Q(control_o[167]) );
  dffphrqx1_u \reg_array_reg[20][6]  ( .D(wr_data[6]), .E(n21), .CK(clk), .RN(
        n496), .Q(control_o[166]) );
  dffphrqx1_u \reg_array_reg[20][5]  ( .D(wr_data[5]), .E(n21), .CK(clk), .RN(
        n496), .Q(control_o[165]) );
  dffphrqx1_u \reg_array_reg[20][4]  ( .D(wr_data[4]), .E(n21), .CK(clk), .RN(
        n496), .Q(control_o[164]) );
  dffphrqx1_u \reg_array_reg[20][3]  ( .D(wr_data[3]), .E(n21), .CK(clk), .RN(
        n496), .Q(control_o[163]) );
  dffphrqx1_u \reg_array_reg[20][2]  ( .D(wr_data[2]), .E(n21), .CK(clk), .RN(
        n496), .Q(control_o[162]) );
  dffphrqx1_u \reg_array_reg[20][1]  ( .D(wr_data[1]), .E(n21), .CK(clk), .RN(
        n496), .Q(control_o[161]) );
  dffphrqx1_u \reg_array_reg[20][0]  ( .D(wr_data[0]), .E(n21), .CK(clk), .RN(
        n496), .Q(control_o[160]) );
  dffphrqx1_u \reg_array_reg[19][7]  ( .D(wr_data[7]), .E(n20), .CK(clk), .RN(
        n498), .Q(control_o[159]) );
  dffphrqx1_u \reg_array_reg[19][6]  ( .D(wr_data[6]), .E(n20), .CK(clk), .RN(
        n490), .Q(control_o[158]) );
  dffphrqx1_u \reg_array_reg[19][5]  ( .D(wr_data[5]), .E(n20), .CK(clk), .RN(
        n496), .Q(control_o[157]) );
  dffphrqx1_u \reg_array_reg[19][4]  ( .D(wr_data[4]), .E(n20), .CK(clk), .RN(
        n493), .Q(control_o[156]) );
  dffphrqx1_u \reg_array_reg[19][3]  ( .D(wr_data[3]), .E(n20), .CK(clk), .RN(
        n492), .Q(control_o[155]) );
  dffphrqx1_u \reg_array_reg[19][2]  ( .D(wr_data[2]), .E(n20), .CK(clk), .RN(
        n493), .Q(control_o[154]) );
  dffphrqx1_u \reg_array_reg[19][1]  ( .D(wr_data[1]), .E(n20), .CK(clk), .RN(
        n494), .Q(control_o[153]) );
  dffphrqx1_u \reg_array_reg[19][0]  ( .D(wr_data[0]), .E(n20), .CK(clk), .RN(
        n498), .Q(control_o[152]) );
  dffphrqx1_u \reg_array_reg[18][7]  ( .D(wr_data[7]), .E(n19), .CK(clk), .RN(
        n493), .Q(control_o[151]) );
  dffphrqx1_u \reg_array_reg[18][6]  ( .D(wr_data[6]), .E(n19), .CK(clk), .RN(
        n493), .Q(control_o[150]) );
  dffphrqx1_u \reg_array_reg[18][5]  ( .D(wr_data[5]), .E(n19), .CK(clk), .RN(
        n492), .Q(control_o[149]) );
  dffphrqx1_u \reg_array_reg[18][4]  ( .D(wr_data[4]), .E(n19), .CK(clk), .RN(
        n490), .Q(control_o[148]) );
  dffphrqx1_u \reg_array_reg[18][3]  ( .D(wr_data[3]), .E(n19), .CK(clk), .RN(
        n494), .Q(control_o[147]) );
  dffphrqx1_u \reg_array_reg[18][2]  ( .D(wr_data[2]), .E(n19), .CK(clk), .RN(
        n494), .Q(control_o[146]) );
  dffphrqx1_u \reg_array_reg[18][1]  ( .D(wr_data[1]), .E(n19), .CK(clk), .RN(
        n494), .Q(control_o[145]) );
  dffphrqx1_u \reg_array_reg[18][0]  ( .D(wr_data[0]), .E(n19), .CK(clk), .RN(
        n494), .Q(control_o[144]) );
  dffphrqx1_u \reg_array_reg[17][7]  ( .D(wr_data[7]), .E(n18), .CK(clk), .RN(
        n494), .Q(control_o[143]) );
  dffphrqx1_u \reg_array_reg[17][6]  ( .D(wr_data[6]), .E(n18), .CK(clk), .RN(
        n494), .Q(control_o[142]) );
  dffphrqx1_u \reg_array_reg[17][5]  ( .D(wr_data[5]), .E(n18), .CK(clk), .RN(
        n494), .Q(control_o[141]) );
  dffphrqx1_u \reg_array_reg[17][4]  ( .D(wr_data[4]), .E(n18), .CK(clk), .RN(
        n494), .Q(control_o[140]) );
  dffphrqx1_u \reg_array_reg[17][3]  ( .D(wr_data[3]), .E(n18), .CK(clk), .RN(
        n494), .Q(control_o[139]) );
  dffphrqx1_u \reg_array_reg[17][2]  ( .D(wr_data[2]), .E(n18), .CK(clk), .RN(
        n494), .Q(control_o[138]) );
  dffphrqx1_u \reg_array_reg[17][1]  ( .D(wr_data[1]), .E(n18), .CK(clk), .RN(
        n494), .Q(control_o[137]) );
  dffphrqx1_u \reg_array_reg[17][0]  ( .D(wr_data[0]), .E(n18), .CK(clk), .RN(
        n494), .Q(control_o[136]) );
  dffphrqx1_u \reg_array_reg[16][7]  ( .D(wr_data[7]), .E(n17), .CK(clk), .RN(
        n492), .Q(control_o[135]) );
  dffphrqx1_u \reg_array_reg[16][6]  ( .D(wr_data[6]), .E(n17), .CK(clk), .RN(
        n494), .Q(control_o[134]) );
  dffphrqx1_u \reg_array_reg[16][5]  ( .D(wr_data[5]), .E(n17), .CK(clk), .RN(
        n498), .Q(control_o[133]) );
  dffphrqx1_u \reg_array_reg[16][4]  ( .D(wr_data[4]), .E(n17), .CK(clk), .RN(
        n492), .Q(control_o[132]) );
  dffphrqx1_u \reg_array_reg[16][3]  ( .D(wr_data[3]), .E(n17), .CK(clk), .RN(
        n494), .Q(control_o[131]) );
  dffphrqx1_u \reg_array_reg[16][2]  ( .D(wr_data[2]), .E(n17), .CK(clk), .RN(
        n490), .Q(control_o[130]) );
  dffphrqx1_u \reg_array_reg[16][1]  ( .D(wr_data[1]), .E(n17), .CK(clk), .RN(
        n498), .Q(control_o[129]) );
  dffphrqx1_u \reg_array_reg[16][0]  ( .D(wr_data[0]), .E(n17), .CK(clk), .RN(
        n496), .Q(control_o[128]) );
  dffphrqx1_u \reg_array_reg[15][7]  ( .D(wr_data[7]), .E(n16), .CK(clk), .RN(
        n493), .Q(control_o[127]) );
  dffphrqx1_u \reg_array_reg[15][6]  ( .D(wr_data[6]), .E(n16), .CK(clk), .RN(
        n490), .Q(control_o[126]) );
  dffphrqx1_u \reg_array_reg[15][5]  ( .D(wr_data[5]), .E(n16), .CK(clk), .RN(
        n496), .Q(control_o[125]) );
  dffphrqx1_u \reg_array_reg[15][4]  ( .D(wr_data[4]), .E(n16), .CK(clk), .RN(
        n493), .Q(control_o[124]) );
  dffphrqx1_u \reg_array_reg[15][3]  ( .D(wr_data[3]), .E(n16), .CK(clk), .RN(
        n493), .Q(control_o[123]) );
  dffphrqx1_u \reg_array_reg[15][2]  ( .D(wr_data[2]), .E(n16), .CK(clk), .RN(
        n493), .Q(control_o[122]) );
  dffphrqx1_u \reg_array_reg[15][1]  ( .D(wr_data[1]), .E(n16), .CK(clk), .RN(
        n493), .Q(control_o[121]) );
  dffphrqx1_u \reg_array_reg[15][0]  ( .D(wr_data[0]), .E(n16), .CK(clk), .RN(
        n493), .Q(control_o[120]) );
  dffphrqx1_u \reg_array_reg[14][7]  ( .D(wr_data[7]), .E(n15), .CK(clk), .RN(
        n493), .Q(control_o[119]) );
  dffphrqx1_u \reg_array_reg[14][6]  ( .D(wr_data[6]), .E(n15), .CK(clk), .RN(
        n493), .Q(control_o[118]) );
  dffphrqx1_u \reg_array_reg[14][5]  ( .D(wr_data[5]), .E(n15), .CK(clk), .RN(
        n493), .Q(control_o[117]) );
  dffphrqx1_u \reg_array_reg[14][4]  ( .D(wr_data[4]), .E(n15), .CK(clk), .RN(
        n493), .Q(control_o[116]) );
  dffphrqx1_u \reg_array_reg[14][3]  ( .D(wr_data[3]), .E(n15), .CK(clk), .RN(
        n493), .Q(control_o[115]) );
  dffphrqx1_u \reg_array_reg[14][2]  ( .D(wr_data[2]), .E(n15), .CK(clk), .RN(
        n493), .Q(control_o[114]) );
  dffphrqx1_u \reg_array_reg[14][1]  ( .D(wr_data[1]), .E(n15), .CK(clk), .RN(
        n493), .Q(control_o[113]) );
  dffphrqx1_u \reg_array_reg[14][0]  ( .D(wr_data[0]), .E(n15), .CK(clk), .RN(
        n493), .Q(control_o[112]) );
  dffphrqx1_u \reg_array_reg[13][7]  ( .D(wr_data[7]), .E(n14), .CK(clk), .RN(
        n492), .Q(control_o[111]) );
  dffphrqx1_u \reg_array_reg[13][6]  ( .D(wr_data[6]), .E(n14), .CK(clk), .RN(
        n492), .Q(control_o[110]) );
  dffphrqx1_u \reg_array_reg[13][5]  ( .D(wr_data[5]), .E(n14), .CK(clk), .RN(
        n492), .Q(control_o[109]) );
  dffphrqx1_u \reg_array_reg[13][4]  ( .D(wr_data[4]), .E(n14), .CK(clk), .RN(
        n492), .Q(control_o[108]) );
  dffphrqx1_u \reg_array_reg[13][3]  ( .D(wr_data[3]), .E(n14), .CK(clk), .RN(
        n492), .Q(control_o[107]) );
  dffphrqx1_u \reg_array_reg[13][2]  ( .D(wr_data[2]), .E(n14), .CK(clk), .RN(
        n492), .Q(control_o[106]) );
  dffphrqx1_u \reg_array_reg[13][1]  ( .D(wr_data[1]), .E(n14), .CK(clk), .RN(
        n492), .Q(control_o[105]) );
  dffphrqx1_u \reg_array_reg[13][0]  ( .D(wr_data[0]), .E(n14), .CK(clk), .RN(
        n492), .Q(control_o[104]) );
  dffphrqx1_u \reg_array_reg[12][7]  ( .D(wr_data[7]), .E(n13), .CK(clk), .RN(
        n492), .Q(control_o[103]) );
  dffphrqx1_u \reg_array_reg[12][6]  ( .D(wr_data[6]), .E(n13), .CK(clk), .RN(
        n492), .Q(control_o[102]) );
  dffphrqx1_u \reg_array_reg[12][5]  ( .D(wr_data[5]), .E(n13), .CK(clk), .RN(
        n492), .Q(control_o[101]) );
  dffphrqx1_u \reg_array_reg[12][4]  ( .D(wr_data[4]), .E(n13), .CK(clk), .RN(
        n492), .Q(control_o[100]) );
  dffphrqx1_u \reg_array_reg[12][3]  ( .D(wr_data[3]), .E(n13), .CK(clk), .RN(
        n493), .Q(control_o[99]) );
  dffphrqx1_u \reg_array_reg[12][2]  ( .D(wr_data[2]), .E(n13), .CK(clk), .RN(
        n490), .Q(control_o[98]) );
  dffphrqx1_u \reg_array_reg[12][1]  ( .D(wr_data[1]), .E(n13), .CK(clk), .RN(
        n498), .Q(control_o[97]) );
  dffphrqx1_u \reg_array_reg[12][0]  ( .D(wr_data[0]), .E(n13), .CK(clk), .RN(
        n494), .Q(control_o[96]) );
  dffphrqx1_u \reg_array_reg[11][7]  ( .D(wr_data[7]), .E(n12), .CK(clk), .RN(
        n496), .Q(control_o[95]) );
  dffphrqx1_u \reg_array_reg[11][6]  ( .D(wr_data[6]), .E(n12), .CK(clk), .RN(
        rst_n), .Q(control_o[94]) );
  dffphrqx1_u \reg_array_reg[11][5]  ( .D(wr_data[5]), .E(n12), .CK(clk), .RN(
        n490), .Q(control_o[93]) );
  dffphrqx1_u \reg_array_reg[11][4]  ( .D(wr_data[4]), .E(n12), .CK(clk), .RN(
        n494), .Q(control_o[92]) );
  dffphrqx1_u \reg_array_reg[11][3]  ( .D(wr_data[3]), .E(n12), .CK(clk), .RN(
        n498), .Q(control_o[91]) );
  dffphrqx1_u \reg_array_reg[11][2]  ( .D(wr_data[2]), .E(n12), .CK(clk), .RN(
        rst_n), .Q(control_o[90]) );
  dffphrqx1_u \reg_array_reg[11][1]  ( .D(wr_data[1]), .E(n12), .CK(clk), .RN(
        n493), .Q(control_o[89]) );
  dffphrqx1_u \reg_array_reg[11][0]  ( .D(wr_data[0]), .E(n12), .CK(clk), .RN(
        n494), .Q(control_o[88]) );
  dffphrqx1_u \reg_array_reg[10][7]  ( .D(wr_data[7]), .E(n11), .CK(clk), .RN(
        n498), .Q(control_o[87]) );
  dffphrqx1_u \reg_array_reg[10][6]  ( .D(wr_data[6]), .E(n11), .CK(clk), .RN(
        n494), .Q(control_o[86]) );
  dffphrqx1_u \reg_array_reg[10][5]  ( .D(wr_data[5]), .E(n11), .CK(clk), .RN(
        rst_n), .Q(control_o[85]) );
  dffphrqx1_u \reg_array_reg[10][4]  ( .D(wr_data[4]), .E(n11), .CK(clk), .RN(
        rst_n), .Q(control_o[84]) );
  dffphrqx1_u \reg_array_reg[10][3]  ( .D(wr_data[3]), .E(n11), .CK(clk), .RN(
        rst_n), .Q(control_o[83]) );
  dffphrqx1_u \reg_array_reg[10][2]  ( .D(wr_data[2]), .E(n11), .CK(clk), .RN(
        n490), .Q(control_o[82]) );
  dffphrqx1_u \reg_array_reg[10][1]  ( .D(wr_data[1]), .E(n11), .CK(clk), .RN(
        n492), .Q(control_o[81]) );
  dffphrqx1_u \reg_array_reg[10][0]  ( .D(wr_data[0]), .E(n11), .CK(clk), .RN(
        n492), .Q(control_o[80]) );
  dffphrqx1_u \reg_array_reg[9][7]  ( .D(wr_data[7]), .E(n10), .CK(clk), .RN(
        n498), .Q(control_o[79]) );
  dffphrqx1_u \reg_array_reg[9][6]  ( .D(wr_data[6]), .E(n10), .CK(clk), .RN(
        n494), .Q(control_o[78]) );
  dffphrqx1_u \reg_array_reg[9][5]  ( .D(wr_data[5]), .E(n10), .CK(clk), .RN(
        n490), .Q(control_o[77]) );
  dffphrqx1_u \reg_array_reg[9][4]  ( .D(wr_data[4]), .E(n10), .CK(clk), .RN(
        n490), .Q(control_o[76]) );
  dffphrqx1_u \reg_array_reg[9][3]  ( .D(wr_data[3]), .E(n10), .CK(clk), .RN(
        n494), .Q(control_o[75]) );
  dffphrqx1_u \reg_array_reg[9][2]  ( .D(wr_data[2]), .E(n10), .CK(clk), .RN(
        n492), .Q(control_o[74]) );
  dffphrqx1_u \reg_array_reg[9][1]  ( .D(wr_data[1]), .E(n10), .CK(clk), .RN(
        n490), .Q(control_o[73]) );
  dffphrqx1_u \reg_array_reg[9][0]  ( .D(wr_data[0]), .E(n10), .CK(clk), .RN(
        n498), .Q(control_o[72]) );
  dffphrqx1_u \reg_array_reg[8][7]  ( .D(wr_data[7]), .E(n9), .CK(clk), .RN(
        n493), .Q(control_o[71]) );
  dffphrqx1_u \reg_array_reg[8][6]  ( .D(wr_data[6]), .E(n9), .CK(clk), .RN(
        n490), .Q(control_o[70]) );
  dffphrqx1_u \reg_array_reg[8][5]  ( .D(wr_data[5]), .E(n9), .CK(clk), .RN(
        n496), .Q(control_o[69]) );
  dffphrqx1_u \reg_array_reg[8][4]  ( .D(wr_data[4]), .E(n9), .CK(clk), .RN(
        n498), .Q(control_o[68]) );
  dffphrqx1_u \reg_array_reg[8][3]  ( .D(wr_data[3]), .E(n9), .CK(clk), .RN(
        n496), .Q(control_o[67]) );
  dffphrqx1_u \reg_array_reg[8][2]  ( .D(wr_data[2]), .E(n9), .CK(clk), .RN(
        n493), .Q(control_o[66]) );
  dffphrqx1_u \reg_array_reg[8][1]  ( .D(wr_data[1]), .E(n9), .CK(clk), .RN(
        n498), .Q(control_o[65]) );
  dffphrqx1_u \reg_array_reg[8][0]  ( .D(wr_data[0]), .E(n9), .CK(clk), .RN(
        n494), .Q(control_o[64]) );
  dffphrqx1_u \reg_array_reg[7][7]  ( .D(wr_data[7]), .E(n8), .CK(clk), .RN(
        rst_n), .Q(control_o[63]) );
  dffphrqx1_u \reg_array_reg[7][6]  ( .D(wr_data[6]), .E(n8), .CK(clk), .RN(
        n498), .Q(control_o[62]) );
  dffphrqx1_u \reg_array_reg[7][5]  ( .D(wr_data[5]), .E(n8), .CK(clk), .RN(
        n498), .Q(control_o[61]) );
  dffphrqx1_u \reg_array_reg[7][4]  ( .D(wr_data[4]), .E(n8), .CK(clk), .RN(
        n493), .Q(control_o[60]) );
  dffphrqx1_u \reg_array_reg[7][3]  ( .D(wr_data[3]), .E(n8), .CK(clk), .RN(
        n494), .Q(control_o[59]) );
  dffphrqx1_u \reg_array_reg[7][2]  ( .D(wr_data[2]), .E(n8), .CK(clk), .RN(
        n496), .Q(control_o[58]) );
  dffphrqx1_u \reg_array_reg[7][1]  ( .D(wr_data[1]), .E(n8), .CK(clk), .RN(
        rst_n), .Q(control_o[57]) );
  dffphrqx1_u \reg_array_reg[7][0]  ( .D(wr_data[0]), .E(n8), .CK(clk), .RN(
        n496), .Q(control_o[56]) );
  dffphrqx1_u \reg_array_reg[6][7]  ( .D(wr_data[7]), .E(n7), .CK(clk), .RN(
        n490), .Q(control_o[55]) );
  dffphrqx1_u \reg_array_reg[6][6]  ( .D(wr_data[6]), .E(n7), .CK(clk), .RN(
        n498), .Q(control_o[54]) );
  dffphrqx1_u \reg_array_reg[6][5]  ( .D(wr_data[5]), .E(n7), .CK(clk), .RN(
        n492), .Q(control_o[53]) );
  dffphrqx1_u \reg_array_reg[6][4]  ( .D(wr_data[4]), .E(n7), .CK(clk), .RN(
        n494), .Q(control_o[52]) );
  dffphrqx1_u \reg_array_reg[6][3]  ( .D(wr_data[3]), .E(n7), .CK(clk), .RN(
        n494), .Q(control_o[51]) );
  dffphrqx1_u \reg_array_reg[6][2]  ( .D(wr_data[2]), .E(n7), .CK(clk), .RN(
        n492), .Q(control_o[50]) );
  dffphrqx1_u \reg_array_reg[6][1]  ( .D(wr_data[1]), .E(n7), .CK(clk), .RN(
        n492), .Q(control_o[49]) );
  dffphrqx1_u \reg_array_reg[6][0]  ( .D(wr_data[0]), .E(n7), .CK(clk), .RN(
        n498), .Q(control_o[48]) );
  dffphrqx1_u \reg_array_reg[5][7]  ( .D(wr_data[7]), .E(n6), .CK(clk), .RN(
        n490), .Q(control_o[47]) );
  dffphrqx1_u \reg_array_reg[5][6]  ( .D(wr_data[6]), .E(n6), .CK(clk), .RN(
        n492), .Q(control_o[46]) );
  dffphrqx1_u \reg_array_reg[5][5]  ( .D(wr_data[5]), .E(n6), .CK(clk), .RN(
        n492), .Q(control_o[45]) );
  dffphrqx1_u \reg_array_reg[5][4]  ( .D(wr_data[4]), .E(n6), .CK(clk), .RN(
        n493), .Q(control_o[44]) );
  dffphrqx1_u \reg_array_reg[5][3]  ( .D(wr_data[3]), .E(n6), .CK(clk), .RN(
        n496), .Q(control_o[43]) );
  dffphrqx1_u \reg_array_reg[5][2]  ( .D(wr_data[2]), .E(n6), .CK(clk), .RN(
        n492), .Q(control_o[42]) );
  dffphrqx1_u \reg_array_reg[5][1]  ( .D(wr_data[1]), .E(n6), .CK(clk), .RN(
        n496), .Q(control_o[41]) );
  dffphrqx1_u \reg_array_reg[5][0]  ( .D(wr_data[0]), .E(n6), .CK(clk), .RN(
        rst_n), .Q(control_o[40]) );
  dffphrqx1_u \reg_array_reg[4][7]  ( .D(wr_data[7]), .E(n5), .CK(clk), .RN(
        n493), .Q(control_o[39]) );
  dffphrqx1_u \reg_array_reg[4][6]  ( .D(wr_data[6]), .E(n5), .CK(clk), .RN(
        n490), .Q(control_o[38]) );
  dffphrqx1_u \reg_array_reg[4][5]  ( .D(wr_data[5]), .E(n5), .CK(clk), .RN(
        n496), .Q(control_o[37]) );
  dffphrqx1_u \reg_array_reg[4][4]  ( .D(wr_data[4]), .E(n5), .CK(clk), .RN(
        n493), .Q(control_o[36]) );
  dffphrqx1_u \reg_array_reg[4][3]  ( .D(wr_data[3]), .E(n5), .CK(clk), .RN(
        n498), .Q(control_o[35]) );
  dffphrqx1_u \reg_array_reg[4][2]  ( .D(wr_data[2]), .E(n5), .CK(clk), .RN(
        n490), .Q(control_o[34]) );
  dffphrqx1_u \reg_array_reg[4][1]  ( .D(wr_data[1]), .E(n5), .CK(clk), .RN(
        n494), .Q(control_o[33]) );
  dffphrqx1_u \reg_array_reg[4][0]  ( .D(wr_data[0]), .E(n5), .CK(clk), .RN(
        n496), .Q(control_o[32]) );
  dffphrqx1_u \reg_array_reg[3][7]  ( .D(wr_data[7]), .E(n4), .CK(clk), .RN(
        n498), .Q(control_o[31]) );
  dffphrqx1_u \reg_array_reg[3][6]  ( .D(wr_data[6]), .E(n4), .CK(clk), .RN(
        n494), .Q(control_o[30]) );
  dffphrqx1_u \reg_array_reg[3][5]  ( .D(wr_data[5]), .E(n4), .CK(clk), .RN(
        n492), .Q(control_o[29]) );
  dffphrqx1_u \reg_array_reg[3][4]  ( .D(wr_data[4]), .E(n4), .CK(clk), .RN(
        n492), .Q(control_o[28]) );
  dffphrqx1_u \reg_array_reg[3][3]  ( .D(wr_data[3]), .E(n4), .CK(clk), .RN(
        n498), .Q(control_o[27]) );
  dffphrqx1_u \reg_array_reg[3][2]  ( .D(wr_data[2]), .E(n4), .CK(clk), .RN(
        n493), .Q(control_o[26]) );
  dffphrqx1_u \reg_array_reg[3][1]  ( .D(wr_data[1]), .E(n4), .CK(clk), .RN(
        n490), .Q(control_o[25]) );
  dffphrqx1_u \reg_array_reg[3][0]  ( .D(wr_data[0]), .E(n4), .CK(clk), .RN(
        n490), .Q(control_o[24]) );
  dffphrqx1_u \reg_array_reg[2][7]  ( .D(wr_data[7]), .E(n3), .CK(clk), .RN(
        n498), .Q(control_o[23]) );
  dffphrqx1_u \reg_array_reg[2][6]  ( .D(wr_data[6]), .E(n3), .CK(clk), .RN(
        n496), .Q(control_o[22]) );
  dffphrqx1_u \reg_array_reg[2][5]  ( .D(wr_data[5]), .E(n3), .CK(clk), .RN(
        n498), .Q(control_o[21]) );
  dffphrqx1_u \reg_array_reg[2][4]  ( .D(wr_data[4]), .E(n3), .CK(clk), .RN(
        n492), .Q(control_o[20]) );
  dffphrqx1_u \reg_array_reg[2][3]  ( .D(wr_data[3]), .E(n3), .CK(clk), .RN(
        n496), .Q(control_o[19]) );
  dffphrqx1_u \reg_array_reg[2][2]  ( .D(wr_data[2]), .E(n3), .CK(clk), .RN(
        n498), .Q(control_o[18]) );
  dffphrqx1_u \reg_array_reg[2][1]  ( .D(wr_data[1]), .E(n3), .CK(clk), .RN(
        n496), .Q(control_o[17]) );
  dffphrqx1_u \reg_array_reg[2][0]  ( .D(wr_data[0]), .E(n3), .CK(clk), .RN(
        n496), .Q(control_o[16]) );
  dffphrqx1_u \reg_array_reg[1][7]  ( .D(wr_data[7]), .E(n2), .CK(clk), .RN(
        n498), .Q(control_o[15]) );
  dffphrqx1_u \reg_array_reg[1][6]  ( .D(wr_data[6]), .E(n2), .CK(clk), .RN(
        n490), .Q(control_o[14]) );
  dffphrqx1_u \reg_array_reg[1][5]  ( .D(wr_data[5]), .E(n2), .CK(clk), .RN(
        n492), .Q(control_o[13]) );
  dffphrqx1_u \reg_array_reg[1][4]  ( .D(wr_data[4]), .E(n2), .CK(clk), .RN(
        n494), .Q(control_o[12]) );
  dffphrqx1_u \reg_array_reg[1][3]  ( .D(wr_data[3]), .E(n2), .CK(clk), .RN(
        n494), .Q(control_o[11]) );
  dffphrqx1_u \reg_array_reg[1][2]  ( .D(wr_data[2]), .E(n2), .CK(clk), .RN(
        n490), .Q(control_o[10]) );
  dffphrqx1_u \reg_array_reg[1][1]  ( .D(wr_data[1]), .E(n2), .CK(clk), .RN(
        n498), .Q(control_o[9]) );
  dffphrqx1_u \reg_array_reg[1][0]  ( .D(wr_data[0]), .E(n2), .CK(clk), .RN(
        n494), .Q(control_o[8]) );
  dffphrqx1_u \reg_array_reg[0][7]  ( .D(wr_data[7]), .E(n25), .CK(clk), .RN(
        n490), .Q(control_o[7]) );
  dffphrqx1_u \reg_array_reg[0][6]  ( .D(wr_data[6]), .E(n25), .CK(clk), .RN(
        n496), .Q(control_o[6]) );
  dffphrqx1_u \reg_array_reg[0][5]  ( .D(wr_data[5]), .E(n25), .CK(clk), .RN(
        n493), .Q(control_o[5]) );
  dffphrqx1_u \reg_array_reg[0][4]  ( .D(wr_data[4]), .E(n25), .CK(clk), .RN(
        n496), .Q(control_o[4]) );
  dffphrqx1_u \reg_array_reg[0][3]  ( .D(wr_data[3]), .E(n25), .CK(clk), .RN(
        n492), .Q(control_o[3]) );
  dffphrqx1_u \reg_array_reg[0][2]  ( .D(wr_data[2]), .E(n25), .CK(clk), .RN(
        n494), .Q(control_o[2]) );
  dffphrqx1_u \reg_array_reg[0][1]  ( .D(wr_data[1]), .E(n25), .CK(clk), .RN(
        n492), .Q(control_o[1]) );
  dffphrqx1_u \reg_array_reg[0][0]  ( .D(wr_data[0]), .E(n25), .CK(clk), .RN(
        n498), .Q(control_o[0]) );
  dffphrqx1_u \r_rd_data_reg[7]  ( .D(n418), .E(rd_en), .CK(clk), .RN(n493), 
        .Q(rd_data[7]) );
  dffphrqx1_u \r_rd_data_reg[6]  ( .D(n373), .E(rd_en), .CK(clk), .RN(n492), 
        .Q(rd_data[6]) );
  dffphrqx1_u \r_rd_data_reg[5]  ( .D(n328), .E(rd_en), .CK(clk), .RN(n496), 
        .Q(rd_data[5]) );
  dffphrqx1_u \r_rd_data_reg[4]  ( .D(n283), .E(rd_en), .CK(clk), .RN(n496), 
        .Q(rd_data[4]) );
  dffphrqx1_u \r_rd_data_reg[3]  ( .D(n238), .E(rd_en), .CK(clk), .RN(n490), 
        .Q(rd_data[3]) );
  dffphrqx1_u \r_rd_data_reg[2]  ( .D(n193), .E(rd_en), .CK(clk), .RN(n493), 
        .Q(rd_data[2]) );
  dffphrqx1_u \r_rd_data_reg[1]  ( .D(n148), .E(rd_en), .CK(clk), .RN(n494), 
        .Q(rd_data[1]) );
  dffphrqx1_u \r_rd_data_reg[0]  ( .D(n31), .E(rd_en), .CK(clk), .RN(rst_n), 
        .Q(rd_data[0]) );
  and2x1_u U361 ( .A(n472), .B(n473), .Q(n467) );
  and2x1_u U413 ( .A(n477), .B(n487), .Q(n483) );
  and2x1_u U416 ( .A(n481), .B(n487), .Q(n486) );
  and2x1_u U430 ( .A(n476), .B(n487), .Q(n489) );
  and2x1_u U439 ( .A(n495), .B(n477), .Q(n491) );
  and2x1_u U448 ( .A(n495), .B(n481), .Q(n497) );
  and2x1_u U457 ( .A(n495), .B(n473), .Q(n502) );
  and2x1_u U467 ( .A(n495), .B(n476), .Q(n507) );
  and2x1_u U478 ( .A(n472), .B(n477), .Q(n512) );
  and2x1_u U492 ( .A(n472), .B(n481), .Q(n517) );
  nor4ax05_u U4 ( .AN(n463), .B(n98), .C(n96), .D(n94), .Q(n95) );
  nor4x1_u U5 ( .A(n101), .B(n99), .C(n100), .D(n97), .Q(n463) );
  aoi22x05_u U6 ( .A(control_o[8]), .B(n94), .C(control_o[0]), .D(n95), .Q(n93) );
  aoi22x05_u U7 ( .A(control_o[24]), .B(n96), .C(control_o[48]), .D(n97), .Q(
        n92) );
  aoi22x05_u U8 ( .A(control_o[9]), .B(n94), .C(control_o[1]), .D(n95), .Q(
        n192) );
  aoi22x05_u U9 ( .A(control_o[25]), .B(n96), .C(control_o[49]), .D(n97), .Q(
        n191) );
  aoi22x05_u U10 ( .A(control_o[10]), .B(n94), .C(control_o[2]), .D(n95), .Q(
        n237) );
  aoi22x05_u U11 ( .A(control_o[26]), .B(n96), .C(control_o[50]), .D(n97), .Q(
        n236) );
  aoi22x05_u U12 ( .A(control_o[11]), .B(n94), .C(control_o[3]), .D(n95), .Q(
        n282) );
  aoi22x05_u U13 ( .A(control_o[27]), .B(n96), .C(control_o[51]), .D(n97), .Q(
        n281) );
  aoi22x05_u U14 ( .A(control_o[12]), .B(n94), .C(control_o[4]), .D(n95), .Q(
        n327) );
  aoi22x05_u U15 ( .A(control_o[28]), .B(n96), .C(control_o[52]), .D(n97), .Q(
        n326) );
  aoi22x05_u U16 ( .A(control_o[13]), .B(n94), .C(control_o[5]), .D(n95), .Q(
        n372) );
  aoi22x05_u U17 ( .A(control_o[29]), .B(n96), .C(control_o[53]), .D(n97), .Q(
        n371) );
  aoi22x05_u U18 ( .A(control_o[14]), .B(n94), .C(control_o[6]), .D(n95), .Q(
        n417) );
  aoi22x05_u U19 ( .A(control_o[30]), .B(n96), .C(control_o[54]), .D(n97), .Q(
        n416) );
  aoi22x05_u U20 ( .A(control_o[15]), .B(n94), .C(control_o[7]), .D(n95), .Q(
        n462) );
  aoi22x05_u U21 ( .A(control_o[31]), .B(n96), .C(control_o[55]), .D(n97), .Q(
        n461) );
  nor4ax05_u U22 ( .AN(n464), .B(n104), .C(n102), .D(n87), .Q(n88) );
  nor4x1_u U23 ( .A(n107), .B(n105), .C(n106), .D(n103), .Q(n464) );
  aoi22x05_u U24 ( .A(control_o[64]), .B(n87), .C(n88), .D(n89), .Q(n86) );
  nand4x1_u U25 ( .A(n90), .B(n91), .C(n92), .D(n93), .Q(n89) );
  aoi22x05_u U26 ( .A(control_o[32]), .B(n100), .C(control_o[56]), .D(n101), 
        .Q(n90) );
  aoi22x05_u U27 ( .A(control_o[16]), .B(n98), .C(control_o[40]), .D(n99), .Q(
        n91) );
  aoi22x05_u U28 ( .A(control_o[80]), .B(n102), .C(control_o[104]), .D(n103), 
        .Q(n85) );
  aoi22x05_u U29 ( .A(control_o[65]), .B(n87), .C(n88), .D(n188), .Q(n187) );
  nand4x1_u U30 ( .A(n189), .B(n190), .C(n191), .D(n192), .Q(n188) );
  aoi22x05_u U31 ( .A(control_o[33]), .B(n100), .C(control_o[57]), .D(n101), 
        .Q(n189) );
  aoi22x05_u U32 ( .A(control_o[17]), .B(n98), .C(control_o[41]), .D(n99), .Q(
        n190) );
  aoi22x05_u U33 ( .A(control_o[81]), .B(n102), .C(control_o[105]), .D(n103), 
        .Q(n186) );
  aoi22x05_u U34 ( .A(control_o[66]), .B(n87), .C(n88), .D(n233), .Q(n232) );
  nand4x1_u U35 ( .A(n234), .B(n235), .C(n236), .D(n237), .Q(n233) );
  aoi22x05_u U36 ( .A(control_o[34]), .B(n100), .C(control_o[58]), .D(n101), 
        .Q(n234) );
  aoi22x05_u U37 ( .A(control_o[18]), .B(n98), .C(control_o[42]), .D(n99), .Q(
        n235) );
  aoi22x05_u U38 ( .A(control_o[82]), .B(n102), .C(control_o[106]), .D(n103), 
        .Q(n231) );
  aoi22x05_u U39 ( .A(control_o[67]), .B(n87), .C(n88), .D(n278), .Q(n277) );
  nand4x1_u U40 ( .A(n279), .B(n280), .C(n281), .D(n282), .Q(n278) );
  aoi22x05_u U41 ( .A(control_o[35]), .B(n100), .C(control_o[59]), .D(n101), 
        .Q(n279) );
  aoi22x05_u U42 ( .A(control_o[19]), .B(n98), .C(control_o[43]), .D(n99), .Q(
        n280) );
  aoi22x05_u U43 ( .A(control_o[83]), .B(n102), .C(control_o[107]), .D(n103), 
        .Q(n276) );
  aoi22x05_u U44 ( .A(control_o[68]), .B(n87), .C(n88), .D(n323), .Q(n322) );
  nand4x1_u U45 ( .A(n324), .B(n325), .C(n326), .D(n327), .Q(n323) );
  aoi22x05_u U46 ( .A(control_o[36]), .B(n100), .C(control_o[60]), .D(n101), 
        .Q(n324) );
  aoi22x05_u U47 ( .A(control_o[20]), .B(n98), .C(control_o[44]), .D(n99), .Q(
        n325) );
  aoi22x05_u U48 ( .A(control_o[84]), .B(n102), .C(control_o[108]), .D(n103), 
        .Q(n321) );
  aoi22x05_u U49 ( .A(control_o[69]), .B(n87), .C(n88), .D(n368), .Q(n367) );
  nand4x1_u U50 ( .A(n369), .B(n370), .C(n371), .D(n372), .Q(n368) );
  aoi22x05_u U51 ( .A(control_o[37]), .B(n100), .C(control_o[61]), .D(n101), 
        .Q(n369) );
  aoi22x05_u U52 ( .A(control_o[21]), .B(n98), .C(control_o[45]), .D(n99), .Q(
        n370) );
  aoi22x05_u U53 ( .A(control_o[85]), .B(n102), .C(control_o[109]), .D(n103), 
        .Q(n366) );
  aoi22x05_u U54 ( .A(control_o[70]), .B(n87), .C(n88), .D(n413), .Q(n412) );
  nand4x1_u U55 ( .A(n414), .B(n415), .C(n416), .D(n417), .Q(n413) );
  aoi22x05_u U56 ( .A(control_o[38]), .B(n100), .C(control_o[62]), .D(n101), 
        .Q(n414) );
  aoi22x05_u U57 ( .A(control_o[22]), .B(n98), .C(control_o[46]), .D(n99), .Q(
        n415) );
  aoi22x05_u U58 ( .A(control_o[86]), .B(n102), .C(control_o[110]), .D(n103), 
        .Q(n411) );
  aoi22x05_u U59 ( .A(control_o[71]), .B(n87), .C(n88), .D(n458), .Q(n457) );
  nand4x1_u U60 ( .A(n459), .B(n460), .C(n461), .D(n462), .Q(n458) );
  aoi22x05_u U61 ( .A(control_o[39]), .B(n100), .C(control_o[63]), .D(n101), 
        .Q(n459) );
  aoi22x05_u U62 ( .A(control_o[23]), .B(n98), .C(control_o[47]), .D(n99), .Q(
        n460) );
  aoi22x05_u U63 ( .A(control_o[87]), .B(n102), .C(control_o[111]), .D(n103), 
        .Q(n456) );
  nor4ax05_u U64 ( .AN(n465), .B(n110), .C(n108), .D(n80), .Q(n81) );
  nor4x1_u U65 ( .A(n113), .B(n111), .C(n112), .D(n109), .Q(n465) );
  aoi22x05_u U66 ( .A(control_o[120]), .B(n80), .C(n81), .D(n82), .Q(n79) );
  nand4x1_u U67 ( .A(n83), .B(n84), .C(n85), .D(n86), .Q(n82) );
  aoi22x05_u U68 ( .A(control_o[72]), .B(n104), .C(control_o[96]), .D(n105), 
        .Q(n84) );
  aoi22x05_u U69 ( .A(control_o[88]), .B(n106), .C(control_o[112]), .D(n107), 
        .Q(n83) );
  aoi22x05_u U70 ( .A(control_o[128]), .B(n110), .C(control_o[152]), .D(n111), 
        .Q(n77) );
  aoi22x05_u U71 ( .A(control_o[121]), .B(n80), .C(n81), .D(n183), .Q(n182) );
  nand4x1_u U72 ( .A(n184), .B(n185), .C(n186), .D(n187), .Q(n183) );
  aoi22x05_u U73 ( .A(control_o[73]), .B(n104), .C(control_o[97]), .D(n105), 
        .Q(n185) );
  aoi22x05_u U74 ( .A(control_o[89]), .B(n106), .C(control_o[113]), .D(n107), 
        .Q(n184) );
  aoi22x05_u U75 ( .A(control_o[129]), .B(n110), .C(control_o[153]), .D(n111), 
        .Q(n180) );
  aoi22x05_u U76 ( .A(control_o[122]), .B(n80), .C(n81), .D(n228), .Q(n227) );
  nand4x1_u U77 ( .A(n229), .B(n230), .C(n231), .D(n232), .Q(n228) );
  aoi22x05_u U78 ( .A(control_o[74]), .B(n104), .C(control_o[98]), .D(n105), 
        .Q(n230) );
  aoi22x05_u U79 ( .A(control_o[90]), .B(n106), .C(control_o[114]), .D(n107), 
        .Q(n229) );
  aoi22x05_u U80 ( .A(control_o[130]), .B(n110), .C(control_o[154]), .D(n111), 
        .Q(n225) );
  aoi22x05_u U81 ( .A(control_o[123]), .B(n80), .C(n81), .D(n273), .Q(n272) );
  nand4x1_u U82 ( .A(n274), .B(n275), .C(n276), .D(n277), .Q(n273) );
  aoi22x05_u U83 ( .A(control_o[75]), .B(n104), .C(control_o[99]), .D(n105), 
        .Q(n275) );
  aoi22x05_u U84 ( .A(control_o[91]), .B(n106), .C(control_o[115]), .D(n107), 
        .Q(n274) );
  aoi22x05_u U85 ( .A(control_o[131]), .B(n110), .C(control_o[155]), .D(n111), 
        .Q(n270) );
  aoi22x05_u U86 ( .A(control_o[124]), .B(n80), .C(n81), .D(n318), .Q(n317) );
  nand4x1_u U87 ( .A(n319), .B(n320), .C(n321), .D(n322), .Q(n318) );
  aoi22x05_u U88 ( .A(control_o[76]), .B(n104), .C(control_o[100]), .D(n105), 
        .Q(n320) );
  aoi22x05_u U89 ( .A(control_o[92]), .B(n106), .C(control_o[116]), .D(n107), 
        .Q(n319) );
  aoi22x05_u U90 ( .A(control_o[132]), .B(n110), .C(control_o[156]), .D(n111), 
        .Q(n315) );
  aoi22x05_u U91 ( .A(control_o[125]), .B(n80), .C(n81), .D(n363), .Q(n362) );
  nand4x1_u U92 ( .A(n364), .B(n365), .C(n366), .D(n367), .Q(n363) );
  aoi22x05_u U93 ( .A(control_o[77]), .B(n104), .C(control_o[101]), .D(n105), 
        .Q(n365) );
  aoi22x05_u U94 ( .A(control_o[93]), .B(n106), .C(control_o[117]), .D(n107), 
        .Q(n364) );
  aoi22x05_u U95 ( .A(control_o[133]), .B(n110), .C(control_o[157]), .D(n111), 
        .Q(n360) );
  aoi22x05_u U96 ( .A(control_o[126]), .B(n80), .C(n81), .D(n408), .Q(n407) );
  nand4x1_u U97 ( .A(n409), .B(n410), .C(n411), .D(n412), .Q(n408) );
  aoi22x05_u U98 ( .A(control_o[78]), .B(n104), .C(control_o[102]), .D(n105), 
        .Q(n410) );
  aoi22x05_u U99 ( .A(control_o[94]), .B(n106), .C(control_o[118]), .D(n107), 
        .Q(n409) );
  aoi22x05_u U100 ( .A(control_o[134]), .B(n110), .C(control_o[158]), .D(n111), 
        .Q(n405) );
  aoi22x05_u U101 ( .A(control_o[127]), .B(n80), .C(n81), .D(n453), .Q(n452)
         );
  nand4x1_u U102 ( .A(n454), .B(n455), .C(n456), .D(n457), .Q(n453) );
  aoi22x05_u U103 ( .A(control_o[79]), .B(n104), .C(control_o[103]), .D(n105), 
        .Q(n455) );
  aoi22x05_u U104 ( .A(control_o[95]), .B(n106), .C(control_o[119]), .D(n107), 
        .Q(n454) );
  aoi22x05_u U105 ( .A(control_o[135]), .B(n110), .C(control_o[159]), .D(n111), 
        .Q(n450) );
  nor4ax05_u U106 ( .AN(n466), .B(n72), .C(n114), .D(n73), .Q(n74) );
  nor4x1_u U107 ( .A(n117), .B(n116), .C(n71), .D(n115), .Q(n466) );
  and2x1_u U108 ( .A(n467), .B(n469), .Q(n71) );
  and2x1_u U109 ( .A(n467), .B(n468), .Q(n72) );
  aoi22x05_u U110 ( .A(control_o[176]), .B(n73), .C(n74), .D(n75), .Q(n69) );
  nand4x1_u U111 ( .A(n76), .B(n77), .C(n78), .D(n79), .Q(n75) );
  aoi22x05_u U112 ( .A(control_o[136]), .B(n108), .C(control_o[160]), .D(n109), 
        .Q(n78) );
  aoi22x05_u U113 ( .A(control_o[144]), .B(n112), .C(control_o[168]), .D(n113), 
        .Q(n76) );
  aoi22x05_u U114 ( .A(\reg_array[24][0] ), .B(n71), .C(\reg_array[27][0] ), 
        .D(n72), .Q(n70) );
  aoi22x05_u U115 ( .A(control_o[177]), .B(n73), .C(n74), .D(n178), .Q(n176)
         );
  nand4x1_u U116 ( .A(n179), .B(n180), .C(n181), .D(n182), .Q(n178) );
  aoi22x05_u U117 ( .A(control_o[137]), .B(n108), .C(control_o[161]), .D(n109), 
        .Q(n181) );
  aoi22x05_u U118 ( .A(control_o[145]), .B(n112), .C(control_o[169]), .D(n113), 
        .Q(n179) );
  aoi22x05_u U119 ( .A(\reg_array[24][1] ), .B(n71), .C(\reg_array[27][1] ), 
        .D(n72), .Q(n177) );
  aoi22x05_u U120 ( .A(control_o[178]), .B(n73), .C(n74), .D(n223), .Q(n221)
         );
  nand4x1_u U121 ( .A(n224), .B(n225), .C(n226), .D(n227), .Q(n223) );
  aoi22x05_u U122 ( .A(control_o[138]), .B(n108), .C(control_o[162]), .D(n109), 
        .Q(n226) );
  aoi22x05_u U123 ( .A(control_o[146]), .B(n112), .C(control_o[170]), .D(n113), 
        .Q(n224) );
  aoi22x05_u U124 ( .A(\reg_array[24][2] ), .B(n71), .C(\reg_array[27][2] ), 
        .D(n72), .Q(n222) );
  aoi22x05_u U125 ( .A(control_o[179]), .B(n73), .C(n74), .D(n268), .Q(n266)
         );
  nand4x1_u U126 ( .A(n269), .B(n270), .C(n271), .D(n272), .Q(n268) );
  aoi22x05_u U127 ( .A(control_o[139]), .B(n108), .C(control_o[163]), .D(n109), 
        .Q(n271) );
  aoi22x05_u U128 ( .A(control_o[147]), .B(n112), .C(control_o[171]), .D(n113), 
        .Q(n269) );
  aoi22x05_u U129 ( .A(\reg_array[24][3] ), .B(n71), .C(\reg_array[27][3] ), 
        .D(n72), .Q(n267) );
  aoi22x05_u U130 ( .A(control_o[180]), .B(n73), .C(n74), .D(n313), .Q(n311)
         );
  nand4x1_u U131 ( .A(n314), .B(n315), .C(n316), .D(n317), .Q(n313) );
  aoi22x05_u U132 ( .A(control_o[140]), .B(n108), .C(control_o[164]), .D(n109), 
        .Q(n316) );
  aoi22x05_u U133 ( .A(control_o[148]), .B(n112), .C(control_o[172]), .D(n113), 
        .Q(n314) );
  aoi22x05_u U134 ( .A(\reg_array[24][4] ), .B(n71), .C(\reg_array[27][4] ), 
        .D(n72), .Q(n312) );
  aoi22x05_u U135 ( .A(control_o[181]), .B(n73), .C(n74), .D(n358), .Q(n356)
         );
  nand4x1_u U136 ( .A(n359), .B(n360), .C(n361), .D(n362), .Q(n358) );
  aoi22x05_u U137 ( .A(control_o[141]), .B(n108), .C(control_o[165]), .D(n109), 
        .Q(n361) );
  aoi22x05_u U138 ( .A(control_o[149]), .B(n112), .C(control_o[173]), .D(n113), 
        .Q(n359) );
  aoi22x05_u U139 ( .A(\reg_array[24][5] ), .B(n71), .C(\reg_array[27][5] ), 
        .D(n72), .Q(n357) );
  aoi22x05_u U140 ( .A(control_o[182]), .B(n73), .C(n74), .D(n403), .Q(n401)
         );
  nand4x1_u U141 ( .A(n404), .B(n405), .C(n406), .D(n407), .Q(n403) );
  aoi22x05_u U142 ( .A(control_o[142]), .B(n108), .C(control_o[166]), .D(n109), 
        .Q(n406) );
  aoi22x05_u U143 ( .A(control_o[150]), .B(n112), .C(control_o[174]), .D(n113), 
        .Q(n404) );
  aoi22x05_u U144 ( .A(\reg_array[24][6] ), .B(n71), .C(\reg_array[27][6] ), 
        .D(n72), .Q(n402) );
  nor2ax05_u U145 ( .AN(n477), .B(n1), .Q(n475) );
  and2x1_u U146 ( .A(n467), .B(n470), .Q(n115) );
  and2x1_u U147 ( .A(n467), .B(n471), .Q(n114) );
  aoi22x05_u U148 ( .A(control_o[183]), .B(n73), .C(n74), .D(n448), .Q(n446)
         );
  nand4x1_u U149 ( .A(n449), .B(n450), .C(n451), .D(n452), .Q(n448) );
  aoi22x05_u U150 ( .A(control_o[143]), .B(n108), .C(control_o[167]), .D(n109), 
        .Q(n451) );
  aoi22x05_u U151 ( .A(control_o[151]), .B(n112), .C(control_o[175]), .D(n113), 
        .Q(n449) );
  aoi22x05_u U152 ( .A(\reg_array[24][7] ), .B(n71), .C(\reg_array[27][7] ), 
        .D(n72), .Q(n447) );
  and2x1_u U153 ( .A(n117), .B(n470), .Q(n64) );
  and2x1_u U154 ( .A(n472), .B(n476), .Q(n117) );
  nor4ax05_u U155 ( .AN(n474), .B(n118), .C(n120), .D(n64), .Q(n65) );
  nor4x1_u U156 ( .A(n123), .B(n122), .C(n121), .D(n119), .Q(n474) );
  and2x1_u U157 ( .A(n475), .B(n471), .Q(n119) );
  and2x1_u U158 ( .A(n117), .B(n468), .Q(n118) );
  aoi22x05_u U159 ( .A(\reg_array[29][0] ), .B(n64), .C(n65), .D(n66), .Q(n63)
         );
  nand4x1_u U160 ( .A(n67), .B(n68), .C(n69), .D(n70), .Q(n66) );
  aoi22x05_u U161 ( .A(control_o[184]), .B(n116), .C(\reg_array[28][0] ), .D(
        n117), .Q(n67) );
  aoi22x05_u U162 ( .A(\reg_array[26][0] ), .B(n114), .C(\reg_array[25][0] ), 
        .D(n115), .Q(n68) );
  aoi22x05_u U163 ( .A(\reg_array[31][0] ), .B(n118), .C(\reg_array[34][0] ), 
        .D(n119), .Q(n62) );
  aoi22x05_u U164 ( .A(\reg_array[29][1] ), .B(n64), .C(n65), .D(n173), .Q(
        n172) );
  nand4x1_u U165 ( .A(n174), .B(n175), .C(n176), .D(n177), .Q(n173) );
  aoi22x05_u U166 ( .A(control_o[185]), .B(n116), .C(\reg_array[28][1] ), .D(
        n117), .Q(n174) );
  aoi22x05_u U167 ( .A(\reg_array[26][1] ), .B(n114), .C(\reg_array[25][1] ), 
        .D(n115), .Q(n175) );
  aoi22x05_u U168 ( .A(\reg_array[31][1] ), .B(n118), .C(\reg_array[34][1] ), 
        .D(n119), .Q(n171) );
  aoi22x05_u U169 ( .A(\reg_array[29][2] ), .B(n64), .C(n65), .D(n218), .Q(
        n217) );
  nand4x1_u U170 ( .A(n219), .B(n220), .C(n221), .D(n222), .Q(n218) );
  aoi22x05_u U171 ( .A(control_o[186]), .B(n116), .C(\reg_array[28][2] ), .D(
        n117), .Q(n219) );
  aoi22x05_u U172 ( .A(\reg_array[26][2] ), .B(n114), .C(\reg_array[25][2] ), 
        .D(n115), .Q(n220) );
  aoi22x05_u U173 ( .A(\reg_array[31][2] ), .B(n118), .C(\reg_array[34][2] ), 
        .D(n119), .Q(n216) );
  aoi22x05_u U174 ( .A(\reg_array[29][3] ), .B(n64), .C(n65), .D(n263), .Q(
        n262) );
  nand4x1_u U175 ( .A(n264), .B(n265), .C(n266), .D(n267), .Q(n263) );
  aoi22x05_u U176 ( .A(control_o[187]), .B(n116), .C(\reg_array[28][3] ), .D(
        n117), .Q(n264) );
  aoi22x05_u U177 ( .A(\reg_array[26][3] ), .B(n114), .C(\reg_array[25][3] ), 
        .D(n115), .Q(n265) );
  aoi22x05_u U178 ( .A(\reg_array[31][3] ), .B(n118), .C(\reg_array[34][3] ), 
        .D(n119), .Q(n261) );
  aoi22x05_u U179 ( .A(\reg_array[29][4] ), .B(n64), .C(n65), .D(n308), .Q(
        n307) );
  nand4x1_u U180 ( .A(n309), .B(n310), .C(n311), .D(n312), .Q(n308) );
  aoi22x05_u U181 ( .A(control_o[188]), .B(n116), .C(\reg_array[28][4] ), .D(
        n117), .Q(n309) );
  aoi22x05_u U182 ( .A(\reg_array[26][4] ), .B(n114), .C(\reg_array[25][4] ), 
        .D(n115), .Q(n310) );
  aoi22x05_u U183 ( .A(\reg_array[31][4] ), .B(n118), .C(\reg_array[34][4] ), 
        .D(n119), .Q(n306) );
  aoi22x05_u U184 ( .A(\reg_array[29][5] ), .B(n64), .C(n65), .D(n353), .Q(
        n352) );
  nand4x1_u U185 ( .A(n354), .B(n355), .C(n356), .D(n357), .Q(n353) );
  aoi22x05_u U186 ( .A(control_o[189]), .B(n116), .C(\reg_array[28][5] ), .D(
        n117), .Q(n354) );
  aoi22x05_u U187 ( .A(\reg_array[26][5] ), .B(n114), .C(\reg_array[25][5] ), 
        .D(n115), .Q(n355) );
  aoi22x05_u U188 ( .A(\reg_array[31][5] ), .B(n118), .C(\reg_array[34][5] ), 
        .D(n119), .Q(n351) );
  aoi22x05_u U189 ( .A(\reg_array[29][6] ), .B(n64), .C(n65), .D(n398), .Q(
        n397) );
  nand4x1_u U190 ( .A(n399), .B(n400), .C(n401), .D(n402), .Q(n398) );
  aoi22x05_u U191 ( .A(control_o[190]), .B(n116), .C(\reg_array[28][6] ), .D(
        n117), .Q(n399) );
  aoi22x05_u U192 ( .A(\reg_array[26][6] ), .B(n114), .C(\reg_array[25][6] ), 
        .D(n115), .Q(n400) );
  aoi22x05_u U193 ( .A(\reg_array[31][6] ), .B(n118), .C(\reg_array[34][6] ), 
        .D(n119), .Q(n396) );
  nor2ax05_u U194 ( .AN(n481), .B(n1), .Q(n479) );
  and2x1_u U195 ( .A(n475), .B(n470), .Q(n121) );
  and2x1_u U196 ( .A(n117), .B(n471), .Q(n120) );
  and2x1_u U197 ( .A(n475), .B(n468), .Q(n123) );
  and2x1_u U198 ( .A(n475), .B(n469), .Q(n122) );
  aoi22x05_u U199 ( .A(\reg_array[29][7] ), .B(n64), .C(n65), .D(n443), .Q(
        n442) );
  nand4x1_u U200 ( .A(n444), .B(n445), .C(n446), .D(n447), .Q(n443) );
  aoi22x05_u U201 ( .A(control_o[191]), .B(n116), .C(\reg_array[28][7] ), .D(
        n117), .Q(n444) );
  aoi22x05_u U202 ( .A(\reg_array[26][7] ), .B(n114), .C(\reg_array[25][7] ), 
        .D(n115), .Q(n445) );
  aoi22x05_u U203 ( .A(\reg_array[31][7] ), .B(n118), .C(\reg_array[34][7] ), 
        .D(n119), .Q(n441) );
  and2x1_u U204 ( .A(n479), .B(n469), .Q(n57) );
  nor4ax05_u U205 ( .AN(n478), .B(n124), .C(n126), .D(n57), .Q(n58) );
  nor4x1_u U206 ( .A(n129), .B(n128), .C(n127), .D(n125), .Q(n478) );
  and2x1_u U207 ( .A(n480), .B(n470), .Q(n125) );
  and2x1_u U208 ( .A(n479), .B(n471), .Q(n124) );
  nor2ax05_u U209 ( .AN(n473), .B(n1), .Q(n480) );
  aoi22x05_u U210 ( .A(\reg_array[36][0] ), .B(n57), .C(n58), .D(n59), .Q(n56)
         );
  nand4x1_u U211 ( .A(n60), .B(n61), .C(n62), .D(n63), .Q(n59) );
  aoi22x05_u U212 ( .A(\reg_array[32][0] ), .B(n122), .C(\reg_array[35][0] ), 
        .D(n123), .Q(n60) );
  aoi22x05_u U213 ( .A(\reg_array[30][0] ), .B(n120), .C(\reg_array[33][0] ), 
        .D(n121), .Q(n61) );
  aoi22x05_u U214 ( .A(\reg_array[38][0] ), .B(n124), .C(\reg_array[41][0] ), 
        .D(n125), .Q(n55) );
  aoi22x05_u U215 ( .A(\reg_array[36][1] ), .B(n57), .C(n58), .D(n168), .Q(
        n167) );
  nand4x1_u U216 ( .A(n169), .B(n170), .C(n171), .D(n172), .Q(n168) );
  aoi22x05_u U217 ( .A(\reg_array[32][1] ), .B(n122), .C(\reg_array[35][1] ), 
        .D(n123), .Q(n169) );
  aoi22x05_u U218 ( .A(\reg_array[30][1] ), .B(n120), .C(\reg_array[33][1] ), 
        .D(n121), .Q(n170) );
  aoi22x05_u U219 ( .A(\reg_array[38][1] ), .B(n124), .C(\reg_array[41][1] ), 
        .D(n125), .Q(n166) );
  aoi22x05_u U220 ( .A(\reg_array[36][2] ), .B(n57), .C(n58), .D(n213), .Q(
        n212) );
  nand4x1_u U221 ( .A(n214), .B(n215), .C(n216), .D(n217), .Q(n213) );
  aoi22x05_u U222 ( .A(\reg_array[32][2] ), .B(n122), .C(\reg_array[35][2] ), 
        .D(n123), .Q(n214) );
  aoi22x05_u U223 ( .A(\reg_array[30][2] ), .B(n120), .C(\reg_array[33][2] ), 
        .D(n121), .Q(n215) );
  aoi22x05_u U224 ( .A(\reg_array[38][2] ), .B(n124), .C(\reg_array[41][2] ), 
        .D(n125), .Q(n211) );
  aoi22x05_u U225 ( .A(\reg_array[36][3] ), .B(n57), .C(n58), .D(n258), .Q(
        n257) );
  nand4x1_u U226 ( .A(n259), .B(n260), .C(n261), .D(n262), .Q(n258) );
  aoi22x05_u U227 ( .A(\reg_array[32][3] ), .B(n122), .C(\reg_array[35][3] ), 
        .D(n123), .Q(n259) );
  aoi22x05_u U228 ( .A(\reg_array[30][3] ), .B(n120), .C(\reg_array[33][3] ), 
        .D(n121), .Q(n260) );
  aoi22x05_u U229 ( .A(\reg_array[38][3] ), .B(n124), .C(\reg_array[41][3] ), 
        .D(n125), .Q(n256) );
  aoi22x05_u U230 ( .A(\reg_array[36][4] ), .B(n57), .C(n58), .D(n303), .Q(
        n302) );
  nand4x1_u U231 ( .A(n304), .B(n305), .C(n306), .D(n307), .Q(n303) );
  aoi22x05_u U232 ( .A(\reg_array[32][4] ), .B(n122), .C(\reg_array[35][4] ), 
        .D(n123), .Q(n304) );
  aoi22x05_u U233 ( .A(\reg_array[30][4] ), .B(n120), .C(\reg_array[33][4] ), 
        .D(n121), .Q(n305) );
  aoi22x05_u U234 ( .A(\reg_array[38][4] ), .B(n124), .C(\reg_array[41][4] ), 
        .D(n125), .Q(n301) );
  aoi22x05_u U235 ( .A(\reg_array[36][5] ), .B(n57), .C(n58), .D(n348), .Q(
        n347) );
  nand4x1_u U236 ( .A(n349), .B(n350), .C(n351), .D(n352), .Q(n348) );
  aoi22x05_u U237 ( .A(\reg_array[32][5] ), .B(n122), .C(\reg_array[35][5] ), 
        .D(n123), .Q(n349) );
  aoi22x05_u U238 ( .A(\reg_array[30][5] ), .B(n120), .C(\reg_array[33][5] ), 
        .D(n121), .Q(n350) );
  aoi22x05_u U239 ( .A(\reg_array[38][5] ), .B(n124), .C(\reg_array[41][5] ), 
        .D(n125), .Q(n346) );
  aoi22x05_u U240 ( .A(\reg_array[36][6] ), .B(n57), .C(n58), .D(n393), .Q(
        n392) );
  nand4x1_u U241 ( .A(n394), .B(n395), .C(n396), .D(n397), .Q(n393) );
  aoi22x05_u U242 ( .A(\reg_array[32][6] ), .B(n122), .C(\reg_array[35][6] ), 
        .D(n123), .Q(n394) );
  aoi22x05_u U243 ( .A(\reg_array[30][6] ), .B(n120), .C(\reg_array[33][6] ), 
        .D(n121), .Q(n395) );
  aoi22x05_u U244 ( .A(\reg_array[38][6] ), .B(n124), .C(\reg_array[41][6] ), 
        .D(n125), .Q(n391) );
  nor2ax05_u U245 ( .AN(n476), .B(n1), .Q(n484) );
  and2x1_u U246 ( .A(n479), .B(n468), .Q(n128) );
  and2x1_u U247 ( .A(n480), .B(n471), .Q(n129) );
  and2x1_u U248 ( .A(n480), .B(n469), .Q(n127) );
  and2x1_u U249 ( .A(n479), .B(n470), .Q(n126) );
  aoi22x05_u U250 ( .A(\reg_array[36][7] ), .B(n57), .C(n58), .D(n438), .Q(
        n437) );
  nand4x1_u U251 ( .A(n439), .B(n440), .C(n441), .D(n442), .Q(n438) );
  aoi22x05_u U252 ( .A(\reg_array[32][7] ), .B(n122), .C(\reg_array[35][7] ), 
        .D(n123), .Q(n439) );
  aoi22x05_u U253 ( .A(\reg_array[30][7] ), .B(n120), .C(\reg_array[33][7] ), 
        .D(n121), .Q(n440) );
  aoi22x05_u U254 ( .A(\reg_array[38][7] ), .B(n124), .C(\reg_array[41][7] ), 
        .D(n125), .Q(n436) );
  and2x1_u U255 ( .A(n480), .B(n468), .Q(n50) );
  nor4ax05_u U256 ( .AN(n482), .B(n130), .C(n132), .D(n50), .Q(n51) );
  nor4x1_u U257 ( .A(n135), .B(n134), .C(n133), .D(n131), .Q(n482) );
  and2x1_u U258 ( .A(n483), .B(n469), .Q(n131) );
  and2x1_u U259 ( .A(n484), .B(n470), .Q(n130) );
  invx1_u U260 ( .A(reg_addr[5]), .Q(n1) );
  invx1_u U261 ( .A(reg_addr[3]), .Q(n27) );
  invx1_u U262 ( .A(reg_addr[2]), .Q(n28) );
  invx1_u U263 ( .A(reg_addr[4]), .Q(n26) );
  aoi22x05_u U264 ( .A(\reg_array[43][0] ), .B(n50), .C(n51), .D(n52), .Q(n49)
         );
  nand4x1_u U265 ( .A(n53), .B(n54), .C(n55), .D(n56), .Q(n52) );
  aoi22x05_u U266 ( .A(\reg_array[37][0] ), .B(n126), .C(\reg_array[40][0] ), 
        .D(n127), .Q(n54) );
  aoi22x05_u U267 ( .A(\reg_array[39][0] ), .B(n128), .C(\reg_array[42][0] ), 
        .D(n129), .Q(n53) );
  aoi22x05_u U268 ( .A(\reg_array[45][0] ), .B(n130), .C(\reg_array[48][0] ), 
        .D(n131), .Q(n48) );
  aoi22x05_u U269 ( .A(\reg_array[43][1] ), .B(n50), .C(n51), .D(n163), .Q(
        n162) );
  nand4x1_u U270 ( .A(n164), .B(n165), .C(n166), .D(n167), .Q(n163) );
  aoi22x05_u U271 ( .A(\reg_array[37][1] ), .B(n126), .C(\reg_array[40][1] ), 
        .D(n127), .Q(n165) );
  aoi22x05_u U272 ( .A(\reg_array[39][1] ), .B(n128), .C(\reg_array[42][1] ), 
        .D(n129), .Q(n164) );
  aoi22x05_u U273 ( .A(\reg_array[45][1] ), .B(n130), .C(\reg_array[48][1] ), 
        .D(n131), .Q(n161) );
  aoi22x05_u U274 ( .A(\reg_array[43][2] ), .B(n50), .C(n51), .D(n208), .Q(
        n207) );
  nand4x1_u U275 ( .A(n209), .B(n210), .C(n211), .D(n212), .Q(n208) );
  aoi22x05_u U276 ( .A(\reg_array[37][2] ), .B(n126), .C(\reg_array[40][2] ), 
        .D(n127), .Q(n210) );
  aoi22x05_u U277 ( .A(\reg_array[39][2] ), .B(n128), .C(\reg_array[42][2] ), 
        .D(n129), .Q(n209) );
  aoi22x05_u U278 ( .A(\reg_array[45][2] ), .B(n130), .C(\reg_array[48][2] ), 
        .D(n131), .Q(n206) );
  aoi22x05_u U279 ( .A(\reg_array[43][3] ), .B(n50), .C(n51), .D(n253), .Q(
        n252) );
  nand4x1_u U280 ( .A(n254), .B(n255), .C(n256), .D(n257), .Q(n253) );
  aoi22x05_u U281 ( .A(\reg_array[37][3] ), .B(n126), .C(\reg_array[40][3] ), 
        .D(n127), .Q(n255) );
  aoi22x05_u U282 ( .A(\reg_array[39][3] ), .B(n128), .C(\reg_array[42][3] ), 
        .D(n129), .Q(n254) );
  aoi22x05_u U283 ( .A(\reg_array[45][3] ), .B(n130), .C(\reg_array[48][3] ), 
        .D(n131), .Q(n251) );
  aoi22x05_u U284 ( .A(\reg_array[43][4] ), .B(n50), .C(n51), .D(n298), .Q(
        n297) );
  nand4x1_u U285 ( .A(n299), .B(n300), .C(n301), .D(n302), .Q(n298) );
  aoi22x05_u U286 ( .A(\reg_array[37][4] ), .B(n126), .C(\reg_array[40][4] ), 
        .D(n127), .Q(n300) );
  aoi22x05_u U287 ( .A(\reg_array[39][4] ), .B(n128), .C(\reg_array[42][4] ), 
        .D(n129), .Q(n299) );
  aoi22x05_u U288 ( .A(\reg_array[45][4] ), .B(n130), .C(\reg_array[48][4] ), 
        .D(n131), .Q(n296) );
  aoi22x05_u U289 ( .A(\reg_array[43][5] ), .B(n50), .C(n51), .D(n343), .Q(
        n342) );
  nand4x1_u U290 ( .A(n344), .B(n345), .C(n346), .D(n347), .Q(n343) );
  aoi22x05_u U291 ( .A(\reg_array[37][5] ), .B(n126), .C(\reg_array[40][5] ), 
        .D(n127), .Q(n345) );
  aoi22x05_u U292 ( .A(\reg_array[39][5] ), .B(n128), .C(\reg_array[42][5] ), 
        .D(n129), .Q(n344) );
  aoi22x05_u U293 ( .A(\reg_array[45][5] ), .B(n130), .C(\reg_array[48][5] ), 
        .D(n131), .Q(n341) );
  aoi22x05_u U294 ( .A(\reg_array[43][6] ), .B(n50), .C(n51), .D(n388), .Q(
        n387) );
  nand4x1_u U295 ( .A(n389), .B(n390), .C(n391), .D(n392), .Q(n388) );
  aoi22x05_u U296 ( .A(\reg_array[37][6] ), .B(n126), .C(\reg_array[40][6] ), 
        .D(n127), .Q(n390) );
  aoi22x05_u U297 ( .A(\reg_array[39][6] ), .B(n128), .C(\reg_array[42][6] ), 
        .D(n129), .Q(n389) );
  aoi22x05_u U298 ( .A(\reg_array[45][6] ), .B(n130), .C(\reg_array[48][6] ), 
        .D(n131), .Q(n386) );
  and2x1_u U299 ( .A(n484), .B(n468), .Q(n133) );
  and2x1_u U300 ( .A(n484), .B(n469), .Q(n132) );
  and2x1_u U301 ( .A(n484), .B(n471), .Q(n134) );
  and2x1_u U302 ( .A(n483), .B(n470), .Q(n135) );
  aoi22x05_u U303 ( .A(\reg_array[43][7] ), .B(n50), .C(n51), .D(n433), .Q(
        n432) );
  nand4x1_u U304 ( .A(n434), .B(n435), .C(n436), .D(n437), .Q(n433) );
  aoi22x05_u U305 ( .A(\reg_array[37][7] ), .B(n126), .C(\reg_array[40][7] ), 
        .D(n127), .Q(n435) );
  aoi22x05_u U306 ( .A(\reg_array[39][7] ), .B(n128), .C(\reg_array[42][7] ), 
        .D(n129), .Q(n434) );
  aoi22x05_u U307 ( .A(\reg_array[45][7] ), .B(n130), .C(\reg_array[48][7] ), 
        .D(n131), .Q(n431) );
  and2x1_u U308 ( .A(n483), .B(n471), .Q(n43) );
  nor4ax05_u U309 ( .AN(n485), .B(n136), .C(n138), .D(n43), .Q(n44) );
  nor4x1_u U310 ( .A(n141), .B(n140), .C(n139), .D(n137), .Q(n485) );
  and2x1_u U311 ( .A(n486), .B(n468), .Q(n137) );
  and2x1_u U312 ( .A(n486), .B(n469), .Q(n136) );
  nor2x1_u U313 ( .A(n1), .B(n26), .Q(n487) );
  nor2x1_u U314 ( .A(n27), .B(reg_addr[2]), .Q(n473) );
  nor2x1_u U315 ( .A(n28), .B(n27), .Q(n476) );
  invx1_u U316 ( .A(reg_addr[0]), .Q(n30) );
  invx1_u U317 ( .A(reg_addr[1]), .Q(n29) );
  nor2x1_u U318 ( .A(n28), .B(reg_addr[3]), .Q(n481) );
  nor2x1_u U319 ( .A(n26), .B(reg_addr[5]), .Q(n472) );
  aoi22x05_u U320 ( .A(\reg_array[50][0] ), .B(n43), .C(n44), .D(n45), .Q(n42)
         );
  nand4x1_u U321 ( .A(n46), .B(n47), .C(n48), .D(n49), .Q(n45) );
  aoi22x05_u U322 ( .A(\reg_array[46][0] ), .B(n134), .C(\reg_array[49][0] ), 
        .D(n135), .Q(n46) );
  aoi22x05_u U323 ( .A(\reg_array[44][0] ), .B(n132), .C(\reg_array[47][0] ), 
        .D(n133), .Q(n47) );
  aoi22x05_u U324 ( .A(\reg_array[52][0] ), .B(n136), .C(\reg_array[55][0] ), 
        .D(n137), .Q(n41) );
  aoi22x05_u U325 ( .A(\reg_array[50][1] ), .B(n43), .C(n44), .D(n158), .Q(
        n157) );
  nand4x1_u U326 ( .A(n159), .B(n160), .C(n161), .D(n162), .Q(n158) );
  aoi22x05_u U327 ( .A(\reg_array[46][1] ), .B(n134), .C(\reg_array[49][1] ), 
        .D(n135), .Q(n159) );
  aoi22x05_u U328 ( .A(\reg_array[44][1] ), .B(n132), .C(\reg_array[47][1] ), 
        .D(n133), .Q(n160) );
  aoi22x05_u U329 ( .A(\reg_array[52][1] ), .B(n136), .C(\reg_array[55][1] ), 
        .D(n137), .Q(n156) );
  aoi22x05_u U330 ( .A(\reg_array[50][2] ), .B(n43), .C(n44), .D(n203), .Q(
        n202) );
  nand4x1_u U331 ( .A(n204), .B(n205), .C(n206), .D(n207), .Q(n203) );
  aoi22x05_u U332 ( .A(\reg_array[46][2] ), .B(n134), .C(\reg_array[49][2] ), 
        .D(n135), .Q(n204) );
  aoi22x05_u U333 ( .A(\reg_array[44][2] ), .B(n132), .C(\reg_array[47][2] ), 
        .D(n133), .Q(n205) );
  aoi22x05_u U334 ( .A(\reg_array[52][2] ), .B(n136), .C(\reg_array[55][2] ), 
        .D(n137), .Q(n201) );
  aoi22x05_u U335 ( .A(\reg_array[50][3] ), .B(n43), .C(n44), .D(n248), .Q(
        n247) );
  nand4x1_u U336 ( .A(n249), .B(n250), .C(n251), .D(n252), .Q(n248) );
  aoi22x05_u U337 ( .A(\reg_array[46][3] ), .B(n134), .C(\reg_array[49][3] ), 
        .D(n135), .Q(n249) );
  aoi22x05_u U338 ( .A(\reg_array[44][3] ), .B(n132), .C(\reg_array[47][3] ), 
        .D(n133), .Q(n250) );
  aoi22x05_u U339 ( .A(\reg_array[52][3] ), .B(n136), .C(\reg_array[55][3] ), 
        .D(n137), .Q(n246) );
  aoi22x05_u U340 ( .A(\reg_array[50][4] ), .B(n43), .C(n44), .D(n293), .Q(
        n292) );
  nand4x1_u U341 ( .A(n294), .B(n295), .C(n296), .D(n297), .Q(n293) );
  aoi22x05_u U342 ( .A(\reg_array[46][4] ), .B(n134), .C(\reg_array[49][4] ), 
        .D(n135), .Q(n294) );
  aoi22x05_u U343 ( .A(\reg_array[44][4] ), .B(n132), .C(\reg_array[47][4] ), 
        .D(n133), .Q(n295) );
  aoi22x05_u U344 ( .A(\reg_array[52][4] ), .B(n136), .C(\reg_array[55][4] ), 
        .D(n137), .Q(n291) );
  aoi22x05_u U345 ( .A(\reg_array[50][5] ), .B(n43), .C(n44), .D(n338), .Q(
        n337) );
  nand4x1_u U346 ( .A(n339), .B(n340), .C(n341), .D(n342), .Q(n338) );
  aoi22x05_u U347 ( .A(\reg_array[46][5] ), .B(n134), .C(\reg_array[49][5] ), 
        .D(n135), .Q(n339) );
  aoi22x05_u U348 ( .A(\reg_array[44][5] ), .B(n132), .C(\reg_array[47][5] ), 
        .D(n133), .Q(n340) );
  aoi22x05_u U349 ( .A(\reg_array[52][5] ), .B(n136), .C(\reg_array[55][5] ), 
        .D(n137), .Q(n336) );
  aoi22x05_u U350 ( .A(\reg_array[50][6] ), .B(n43), .C(n44), .D(n383), .Q(
        n382) );
  nand4x1_u U351 ( .A(n384), .B(n385), .C(n386), .D(n387), .Q(n383) );
  aoi22x05_u U352 ( .A(\reg_array[46][6] ), .B(n134), .C(\reg_array[49][6] ), 
        .D(n135), .Q(n384) );
  aoi22x05_u U353 ( .A(\reg_array[44][6] ), .B(n132), .C(\reg_array[47][6] ), 
        .D(n133), .Q(n385) );
  aoi22x05_u U354 ( .A(\reg_array[52][6] ), .B(n136), .C(\reg_array[55][6] ), 
        .D(n137), .Q(n381) );
  and2x1_u U355 ( .A(n486), .B(n471), .Q(n139) );
  and2x1_u U356 ( .A(n483), .B(n468), .Q(n138) );
  and2x1_u U357 ( .A(n486), .B(n470), .Q(n140) );
  aoi22x05_u U358 ( .A(\reg_array[50][7] ), .B(n43), .C(n44), .D(n428), .Q(
        n427) );
  nand4x1_u U359 ( .A(n429), .B(n430), .C(n431), .D(n432), .Q(n428) );
  aoi22x05_u U360 ( .A(\reg_array[46][7] ), .B(n134), .C(\reg_array[49][7] ), 
        .D(n135), .Q(n429) );
  aoi22x05_u U362 ( .A(\reg_array[44][7] ), .B(n132), .C(\reg_array[47][7] ), 
        .D(n133), .Q(n430) );
  aoi22x05_u U363 ( .A(\reg_array[52][7] ), .B(n136), .C(\reg_array[55][7] ), 
        .D(n137), .Q(n426) );
  and2x1_u U364 ( .A(n470), .B(n141), .Q(n36) );
  and2x1_u U365 ( .A(n473), .B(n487), .Q(n141) );
  nor4ax05_u U366 ( .AN(n488), .B(n142), .C(n144), .D(n36), .Q(n37) );
  nor4x1_u U367 ( .A(n147), .B(n146), .C(n145), .D(n143), .Q(n488) );
  nor2x1_u U368 ( .A(reg_addr[3]), .B(reg_addr[2]), .Q(n477) );
  nor2x1_u U369 ( .A(reg_addr[5]), .B(reg_addr[4]), .Q(n495) );
  nor2x1_u U370 ( .A(n30), .B(reg_addr[1]), .Q(n470) );
  nor2x1_u U371 ( .A(n29), .B(reg_addr[0]), .Q(n471) );
  nor2x1_u U372 ( .A(n29), .B(n30), .Q(n468) );
  aoi22x05_u U373 ( .A(\reg_array[57][0] ), .B(n36), .C(n37), .D(n38), .Q(n35)
         );
  nand4x1_u U374 ( .A(n39), .B(n40), .C(n41), .D(n42), .Q(n38) );
  aoi22x05_u U375 ( .A(\reg_array[53][0] ), .B(n140), .C(\reg_array[56][0] ), 
        .D(n141), .Q(n39) );
  aoi22x05_u U376 ( .A(\reg_array[51][0] ), .B(n138), .C(\reg_array[54][0] ), 
        .D(n139), .Q(n40) );
  aoi22x05_u U377 ( .A(\reg_array[57][1] ), .B(n36), .C(n37), .D(n153), .Q(
        n152) );
  nand4x1_u U378 ( .A(n154), .B(n155), .C(n156), .D(n157), .Q(n153) );
  aoi22x05_u U379 ( .A(\reg_array[53][1] ), .B(n140), .C(\reg_array[56][1] ), 
        .D(n141), .Q(n154) );
  aoi22x05_u U380 ( .A(\reg_array[51][1] ), .B(n138), .C(\reg_array[54][1] ), 
        .D(n139), .Q(n155) );
  aoi22x05_u U381 ( .A(\reg_array[57][2] ), .B(n36), .C(n37), .D(n198), .Q(
        n197) );
  nand4x1_u U382 ( .A(n199), .B(n200), .C(n201), .D(n202), .Q(n198) );
  aoi22x05_u U383 ( .A(\reg_array[53][2] ), .B(n140), .C(\reg_array[56][2] ), 
        .D(n141), .Q(n199) );
  aoi22x05_u U384 ( .A(\reg_array[51][2] ), .B(n138), .C(\reg_array[54][2] ), 
        .D(n139), .Q(n200) );
  aoi22x05_u U385 ( .A(\reg_array[57][3] ), .B(n36), .C(n37), .D(n243), .Q(
        n242) );
  nand4x1_u U386 ( .A(n244), .B(n245), .C(n246), .D(n247), .Q(n243) );
  aoi22x05_u U387 ( .A(\reg_array[53][3] ), .B(n140), .C(\reg_array[56][3] ), 
        .D(n141), .Q(n244) );
  aoi22x05_u U388 ( .A(\reg_array[51][3] ), .B(n138), .C(\reg_array[54][3] ), 
        .D(n139), .Q(n245) );
  aoi22x05_u U389 ( .A(\reg_array[57][4] ), .B(n36), .C(n37), .D(n288), .Q(
        n287) );
  nand4x1_u U390 ( .A(n289), .B(n290), .C(n291), .D(n292), .Q(n288) );
  aoi22x05_u U391 ( .A(\reg_array[53][4] ), .B(n140), .C(\reg_array[56][4] ), 
        .D(n141), .Q(n289) );
  aoi22x05_u U392 ( .A(\reg_array[51][4] ), .B(n138), .C(\reg_array[54][4] ), 
        .D(n139), .Q(n290) );
  aoi22x05_u U393 ( .A(\reg_array[57][5] ), .B(n36), .C(n37), .D(n333), .Q(
        n332) );
  nand4x1_u U394 ( .A(n334), .B(n335), .C(n336), .D(n337), .Q(n333) );
  aoi22x05_u U395 ( .A(\reg_array[53][5] ), .B(n140), .C(\reg_array[56][5] ), 
        .D(n141), .Q(n334) );
  aoi22x05_u U396 ( .A(\reg_array[51][5] ), .B(n138), .C(\reg_array[54][5] ), 
        .D(n139), .Q(n335) );
  aoi22x05_u U397 ( .A(\reg_array[57][6] ), .B(n36), .C(n37), .D(n378), .Q(
        n377) );
  nand4x1_u U398 ( .A(n379), .B(n380), .C(n381), .D(n382), .Q(n378) );
  aoi22x05_u U399 ( .A(\reg_array[53][6] ), .B(n140), .C(\reg_array[56][6] ), 
        .D(n141), .Q(n379) );
  aoi22x05_u U400 ( .A(\reg_array[51][6] ), .B(n138), .C(\reg_array[54][6] ), 
        .D(n139), .Q(n380) );
  and2x1_u U401 ( .A(n471), .B(n489), .Q(n143) );
  and2x1_u U402 ( .A(n468), .B(n141), .Q(n142) );
  and2x1_u U403 ( .A(n489), .B(n470), .Q(n145) );
  and2x1_u U404 ( .A(n471), .B(n141), .Q(n144) );
  and2x1_u U405 ( .A(n469), .B(n489), .Q(n146) );
  and2x1_u U406 ( .A(n468), .B(n489), .Q(n147) );
  aoi22x05_u U407 ( .A(\reg_array[57][7] ), .B(n36), .C(n37), .D(n423), .Q(
        n422) );
  nand4x1_u U408 ( .A(n424), .B(n425), .C(n426), .D(n427), .Q(n423) );
  aoi22x05_u U409 ( .A(\reg_array[53][7] ), .B(n140), .C(\reg_array[56][7] ), 
        .D(n141), .Q(n424) );
  aoi22x05_u U410 ( .A(\reg_array[51][7] ), .B(n138), .C(\reg_array[54][7] ), 
        .D(n139), .Q(n425) );
  nor2x1_u U411 ( .A(reg_addr[1]), .B(reg_addr[0]), .Q(n469) );
  and2x1_u U412 ( .A(n491), .B(n470), .Q(n94) );
  and2x1_u U414 ( .A(n491), .B(n471), .Q(n98) );
  and2x1_u U415 ( .A(n491), .B(n468), .Q(n96) );
  and2x1_u U417 ( .A(n497), .B(n469), .Q(n100) );
  and2x1_u U418 ( .A(n497), .B(n470), .Q(n99) );
  and2x1_u U419 ( .A(n497), .B(n471), .Q(n97) );
  and2x1_u U420 ( .A(n497), .B(n468), .Q(n101) );
  and2x1_u U421 ( .A(n502), .B(n469), .Q(n87) );
  and2x1_u U422 ( .A(n502), .B(n470), .Q(n104) );
  and2x1_u U423 ( .A(n502), .B(n471), .Q(n102) );
  and2x1_u U424 ( .A(n502), .B(n468), .Q(n106) );
  and2x1_u U425 ( .A(n507), .B(n469), .Q(n105) );
  and2x1_u U426 ( .A(n507), .B(n470), .Q(n103) );
  and2x1_u U427 ( .A(n507), .B(n471), .Q(n107) );
  and2x1_u U428 ( .A(n507), .B(n468), .Q(n80) );
  and2x1_u U429 ( .A(n512), .B(n469), .Q(n110) );
  and2x1_u U431 ( .A(n512), .B(n470), .Q(n108) );
  and2x1_u U432 ( .A(n512), .B(n471), .Q(n112) );
  and2x1_u U433 ( .A(n512), .B(n468), .Q(n111) );
  and2x1_u U434 ( .A(n517), .B(n469), .Q(n109) );
  and2x1_u U435 ( .A(n517), .B(n470), .Q(n113) );
  and2x1_u U436 ( .A(n517), .B(n471), .Q(n73) );
  and2x1_u U437 ( .A(n517), .B(n468), .Q(n116) );
  nand4x1_u U438 ( .A(n32), .B(n33), .C(n34), .D(n35), .Q(n31) );
  aoi22x05_u U440 ( .A(\reg_array[60][0] ), .B(n146), .C(\reg_array[63][0] ), 
        .D(n147), .Q(n32) );
  aoi22x05_u U441 ( .A(\reg_array[58][0] ), .B(n144), .C(\reg_array[61][0] ), 
        .D(n145), .Q(n33) );
  aoi22x05_u U442 ( .A(\reg_array[59][0] ), .B(n142), .C(\reg_array[62][0] ), 
        .D(n143), .Q(n34) );
  nand4x1_u U443 ( .A(n149), .B(n150), .C(n151), .D(n152), .Q(n148) );
  aoi22x05_u U444 ( .A(\reg_array[60][1] ), .B(n146), .C(\reg_array[63][1] ), 
        .D(n147), .Q(n149) );
  aoi22x05_u U445 ( .A(\reg_array[58][1] ), .B(n144), .C(\reg_array[61][1] ), 
        .D(n145), .Q(n150) );
  aoi22x05_u U446 ( .A(\reg_array[59][1] ), .B(n142), .C(\reg_array[62][1] ), 
        .D(n143), .Q(n151) );
  nand4x1_u U447 ( .A(n194), .B(n195), .C(n196), .D(n197), .Q(n193) );
  aoi22x05_u U449 ( .A(\reg_array[60][2] ), .B(n146), .C(\reg_array[63][2] ), 
        .D(n147), .Q(n194) );
  aoi22x05_u U450 ( .A(\reg_array[58][2] ), .B(n144), .C(\reg_array[61][2] ), 
        .D(n145), .Q(n195) );
  aoi22x05_u U451 ( .A(\reg_array[59][2] ), .B(n142), .C(\reg_array[62][2] ), 
        .D(n143), .Q(n196) );
  nand4x1_u U452 ( .A(n239), .B(n240), .C(n241), .D(n242), .Q(n238) );
  aoi22x05_u U453 ( .A(\reg_array[60][3] ), .B(n146), .C(\reg_array[63][3] ), 
        .D(n147), .Q(n239) );
  aoi22x05_u U454 ( .A(\reg_array[58][3] ), .B(n144), .C(\reg_array[61][3] ), 
        .D(n145), .Q(n240) );
  aoi22x05_u U455 ( .A(\reg_array[59][3] ), .B(n142), .C(\reg_array[62][3] ), 
        .D(n143), .Q(n241) );
  nand4x1_u U456 ( .A(n284), .B(n285), .C(n286), .D(n287), .Q(n283) );
  aoi22x05_u U458 ( .A(\reg_array[60][4] ), .B(n146), .C(\reg_array[63][4] ), 
        .D(n147), .Q(n284) );
  aoi22x05_u U459 ( .A(\reg_array[58][4] ), .B(n144), .C(\reg_array[61][4] ), 
        .D(n145), .Q(n285) );
  aoi22x05_u U460 ( .A(\reg_array[59][4] ), .B(n142), .C(\reg_array[62][4] ), 
        .D(n143), .Q(n286) );
  nand4x1_u U461 ( .A(n329), .B(n330), .C(n331), .D(n332), .Q(n328) );
  aoi22x05_u U462 ( .A(\reg_array[60][5] ), .B(n146), .C(\reg_array[63][5] ), 
        .D(n147), .Q(n329) );
  aoi22x05_u U463 ( .A(\reg_array[58][5] ), .B(n144), .C(\reg_array[61][5] ), 
        .D(n145), .Q(n330) );
  aoi22x05_u U464 ( .A(\reg_array[59][5] ), .B(n142), .C(\reg_array[62][5] ), 
        .D(n143), .Q(n331) );
  nand4x1_u U465 ( .A(n374), .B(n375), .C(n376), .D(n377), .Q(n373) );
  aoi22x05_u U466 ( .A(\reg_array[60][6] ), .B(n146), .C(\reg_array[63][6] ), 
        .D(n147), .Q(n374) );
  aoi22x05_u U468 ( .A(\reg_array[58][6] ), .B(n144), .C(\reg_array[61][6] ), 
        .D(n145), .Q(n375) );
  aoi22x05_u U469 ( .A(\reg_array[59][6] ), .B(n142), .C(\reg_array[62][6] ), 
        .D(n143), .Q(n376) );
  nand4x1_u U470 ( .A(n419), .B(n420), .C(n421), .D(n422), .Q(n418) );
  aoi22x05_u U471 ( .A(\reg_array[60][7] ), .B(n146), .C(\reg_array[63][7] ), 
        .D(n147), .Q(n419) );
  aoi22x05_u U472 ( .A(\reg_array[58][7] ), .B(n144), .C(\reg_array[61][7] ), 
        .D(n145), .Q(n420) );
  aoi22x05_u U473 ( .A(\reg_array[59][7] ), .B(n142), .C(\reg_array[62][7] ), 
        .D(n143), .Q(n421) );
  bufx1_u U474 ( .A(n490), .Q(n492) );
  bufx1_u U475 ( .A(n490), .Q(n493) );
  bufx1_u U476 ( .A(n490), .Q(n494) );
  bufx1_u U477 ( .A(n490), .Q(n496) );
  bufx1_u U479 ( .A(rst_n), .Q(n498) );
  and2x1_u U480 ( .A(wr_en), .B(n94), .Q(n2) );
  and2x1_u U481 ( .A(wr_en), .B(n98), .Q(n3) );
  and2x1_u U482 ( .A(wr_en), .B(n96), .Q(n4) );
  and2x1_u U483 ( .A(wr_en), .B(n100), .Q(n5) );
  and2x1_u U484 ( .A(wr_en), .B(n99), .Q(n6) );
  and2x1_u U485 ( .A(wr_en), .B(n97), .Q(n7) );
  and2x1_u U486 ( .A(wr_en), .B(n101), .Q(n8) );
  and2x1_u U487 ( .A(wr_en), .B(n87), .Q(n9) );
  and2x1_u U488 ( .A(wr_en), .B(n104), .Q(n10) );
  and2x1_u U489 ( .A(wr_en), .B(n102), .Q(n11) );
  and2x1_u U490 ( .A(wr_en), .B(n106), .Q(n12) );
  and2x1_u U491 ( .A(wr_en), .B(n105), .Q(n13) );
  and2x1_u U493 ( .A(wr_en), .B(n103), .Q(n14) );
  and2x1_u U494 ( .A(wr_en), .B(n107), .Q(n15) );
  and2x1_u U495 ( .A(wr_en), .B(n80), .Q(n16) );
  and2x1_u U496 ( .A(wr_en), .B(n110), .Q(n17) );
  and2x1_u U497 ( .A(wr_en), .B(n108), .Q(n18) );
  and2x1_u U498 ( .A(wr_en), .B(n112), .Q(n19) );
  and2x1_u U499 ( .A(wr_en), .B(n111), .Q(n20) );
  and2x1_u U500 ( .A(wr_en), .B(n109), .Q(n21) );
  and2x1_u U501 ( .A(wr_en), .B(n113), .Q(n22) );
  and2x1_u U502 ( .A(wr_en), .B(n73), .Q(n23) );
  and2x1_u U503 ( .A(wr_en), .B(n116), .Q(n24) );
  and3x1_u U504 ( .A(n491), .B(n469), .C(wr_en), .Q(n25) );
  bufx1_u U505 ( .A(rst_n), .Q(n490) );
  tohlx1_u U506 ( .TL(rd_ready) );
endmodule


module spi_top ( clk, rst_n, SPI_CLK, SPI_MOSI, SPI_SS, SPI_MISO, control_o, 
        status_i );
  output [191:0] control_o;
  input [319:0] status_i;
  input clk, rst_n, SPI_CLK, SPI_MOSI, SPI_SS;
  output SPI_MISO;
  wire   reg_wr_en, reg_rd_en, reg_rd_ready, n1, n2, n3, n4, n5, n6, n7, n8,
         n9, n10, n11, n12, n13, n14, n15, n16, n17, n18, n19, n20, n21, n22,
         n23, n24, n25, n26, n27, n28, n29, n30, n31, n32, n33, n34, n35, n36,
         n37, n38, n39, n40, n41, n42, n43, n44, n45, n46, n47, n48, n49, n50,
         n51, n52, n53, n54, n55, n56, n57, n58, n59, n60, n61, n62, n63, n64,
         n65, n66, n67, n68, n69, n70, n71, n72, n73, n74, n75, n76, n77, n78,
         n79, n80, n81, n82, n83, n84, n85, n86, n87, n88, n89, n90, n91, n92,
         n93, n94, n95, n96, n97, n98, n99, n100, n101, n102, n103, n104, n105,
         n106, n107, n108, n109, n110, n111, n112, n113, n114, n115, n116,
         n117, n118, n119, n120, n121, n122, n123, n124, n125, n126, n127,
         n128, n129, n130, n131, n132, n133, n134, n135, n136, n137, n138,
         n139, n140, n141, n142, n143, n144, n145, n146, n147, n148, n149,
         n150, n151, n152, n153, n154, n155, n156, n157, n158, n159, n160,
         n161, n162, n163, n164, n165, n166, n167, n168, n169, n170, n171,
         n172, n173, n174, n175, n176, n177, n178, n179, n180, n181, n182,
         n183, n184, n185, n186, n187, n188, n189, n190, n191, n192, n193,
         n194, n195, n196, n197, n198, n199, n200, n201, n202, n203, n204,
         n205, n206, n207, n208, n209, n210, n211, n212, n213, n214, n215,
         n216, n217, n218, n219, n220, n221, n222, n223, n224, n225, n226,
         n227, n228, n229, n230, n231, n232, n233, n234, n235, n236, n237,
         n238, n239, n240, n241, n242, n243, n244, n245, n246, n247, n248,
         n249, n250, n251, n252, n253, n254, n255, n256, n257, n258, n259,
         n260, n261, n262, n263, n264, n265, n266, n267, n268, n269, n270,
         n271, n272, n273, n274, n275, n276, n277, n278, n279, n280, n281,
         n282, n283, n284, n285, n286, n287, n288, n289, n290, n291, n292,
         n293, n294, n295, n296, n297, n298, n299, n300, n301, n302, n303,
         n304, n305, n306, n307, n308, n309, n310, n311, n312, n313, n314,
         n315, n316, n317, n318, n319, n320, n321, n322, n323, n324, n325;
  wire   [5:0] reg_addr;
  wire   [7:0] reg_wr_data;
  wire   [7:0] reg_rd_data;

  spi_reg_interface u_spi_reg_interface ( .clk(clk), .rst_n(n325), .SPI_CLK(n1), .SPI_MOSI(n322), .SPI_SS(n323), .SPI_MISO(SPI_MISO), .reg_addr(reg_addr), 
        .wr_data(reg_wr_data), .rd_data(reg_rd_data), .wr_en(reg_wr_en), 
        .rd_en(reg_rd_en), .rd_ready(n324) );
  inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40 u_inst_reg ( .clk(clk), 
        .rst_n(n325), .reg_addr(reg_addr), .wr_data(reg_wr_data), .rd_data(
        reg_rd_data), .wr_en(reg_wr_en), .rd_en(reg_rd_en), .rd_ready(
        reg_rd_ready), .control_o(control_o), .status_i({n321, n320, n319, 
        n318, n317, n316, n315, n314, n313, n312, n311, n310, n309, n308, n307, 
        n306, n305, n304, n303, n302, n301, n300, n299, n298, n297, n296, n295, 
        n294, n293, n292, n291, n290, n289, n288, n287, n286, n285, n284, n283, 
        n282, n281, n280, n279, n278, n277, n276, n275, n274, n273, n272, n271, 
        n270, n269, n268, n267, n266, n265, n264, n263, n262, n261, n260, n259, 
        n258, n257, n256, n255, n254, n253, n252, n251, n250, n249, n248, n247, 
        n246, n245, n244, n243, n242, n241, n240, n239, n238, n237, n236, n235, 
        n234, n233, n232, n231, n230, n229, n228, n227, n226, n225, n224, n223, 
        n222, n221, n220, n219, n218, n217, n216, n215, n214, n213, n212, n211, 
        n210, n209, n208, n207, n206, n205, n204, n203, n202, n201, n200, n199, 
        n198, n197, n196, n195, n194, n193, n192, n191, n190, n189, n188, n187, 
        n186, n185, n184, n183, n182, n181, n180, n179, n178, n177, n176, n175, 
        n174, n173, n172, n171, n170, n169, n168, n167, n166, n165, n164, n163, 
        n162, n161, n160, n159, n158, n157, n156, n155, n154, n153, n152, n151, 
        n150, n149, n148, n147, n146, n145, n144, n143, n142, n141, n140, n139, 
        n138, n137, n136, n135, n134, n133, n132, n131, n130, n129, n128, n127, 
        n126, n125, n124, n123, n122, n121, n120, n119, n118, n117, n116, n115, 
        n114, n113, n112, n111, n110, n109, n108, n107, n106, n105, n104, n103, 
        n102, n101, n100, n99, n98, n97, n96, n95, n94, n93, n92, n91, n90, 
        n89, n88, n87, n86, n85, n84, n83, n82, n81, n80, n79, n78, n77, n76, 
        n75, n74, n73, n72, n71, n70, n69, n68, n67, n66, n65, n64, n63, n62, 
        n61, n60, n59, n58, n57, n56, n55, n54, n53, n52, n51, n50, n49, n48, 
        n47, n46, n45, n44, n43, n42, n41, n40, n39, n38, n37, n36, n35, n34, 
        n33, n32, n31, n30, n29, n28, n27, n26, n25, n24, n23, n22, n21, n20, 
        n19, n18, n17, n16, n15, n14, n13, n12, n11, n10, n9, n8, n7, n6, n5, 
        n4, n3, n2}) );
  bufx05_u U1 ( .A(SPI_CLK), .Q(n1) );
  bufx05_u U2 ( .A(status_i[0]), .Q(n2) );
  bufx05_u U3 ( .A(status_i[1]), .Q(n3) );
  bufx05_u U4 ( .A(status_i[2]), .Q(n4) );
  bufx05_u U5 ( .A(status_i[3]), .Q(n5) );
  bufx05_u U6 ( .A(status_i[4]), .Q(n6) );
  bufx05_u U7 ( .A(status_i[5]), .Q(n7) );
  bufx05_u U8 ( .A(status_i[6]), .Q(n8) );
  bufx05_u U9 ( .A(status_i[7]), .Q(n9) );
  bufx05_u U10 ( .A(status_i[8]), .Q(n10) );
  bufx05_u U11 ( .A(status_i[9]), .Q(n11) );
  bufx05_u U12 ( .A(status_i[10]), .Q(n12) );
  bufx05_u U13 ( .A(status_i[11]), .Q(n13) );
  bufx05_u U14 ( .A(status_i[12]), .Q(n14) );
  bufx05_u U15 ( .A(status_i[13]), .Q(n15) );
  bufx05_u U16 ( .A(status_i[14]), .Q(n16) );
  bufx05_u U17 ( .A(status_i[15]), .Q(n17) );
  bufx05_u U18 ( .A(status_i[16]), .Q(n18) );
  bufx05_u U19 ( .A(status_i[17]), .Q(n19) );
  bufx05_u U20 ( .A(status_i[18]), .Q(n20) );
  bufx05_u U21 ( .A(status_i[19]), .Q(n21) );
  bufx05_u U22 ( .A(status_i[20]), .Q(n22) );
  bufx05_u U23 ( .A(status_i[21]), .Q(n23) );
  bufx05_u U24 ( .A(status_i[22]), .Q(n24) );
  bufx05_u U25 ( .A(status_i[23]), .Q(n25) );
  bufx05_u U26 ( .A(status_i[24]), .Q(n26) );
  bufx05_u U27 ( .A(status_i[25]), .Q(n27) );
  bufx05_u U28 ( .A(status_i[26]), .Q(n28) );
  bufx05_u U29 ( .A(status_i[27]), .Q(n29) );
  bufx05_u U30 ( .A(status_i[28]), .Q(n30) );
  bufx05_u U31 ( .A(status_i[29]), .Q(n31) );
  bufx05_u U32 ( .A(status_i[30]), .Q(n32) );
  bufx05_u U33 ( .A(status_i[31]), .Q(n33) );
  bufx05_u U34 ( .A(status_i[32]), .Q(n34) );
  bufx05_u U35 ( .A(status_i[33]), .Q(n35) );
  bufx05_u U36 ( .A(status_i[34]), .Q(n36) );
  bufx05_u U37 ( .A(status_i[35]), .Q(n37) );
  bufx05_u U38 ( .A(status_i[36]), .Q(n38) );
  bufx05_u U39 ( .A(status_i[37]), .Q(n39) );
  bufx05_u U40 ( .A(status_i[38]), .Q(n40) );
  bufx05_u U41 ( .A(status_i[39]), .Q(n41) );
  bufx05_u U42 ( .A(status_i[40]), .Q(n42) );
  bufx05_u U43 ( .A(status_i[41]), .Q(n43) );
  bufx05_u U44 ( .A(status_i[42]), .Q(n44) );
  bufx05_u U45 ( .A(status_i[43]), .Q(n45) );
  bufx05_u U46 ( .A(status_i[44]), .Q(n46) );
  bufx05_u U47 ( .A(status_i[45]), .Q(n47) );
  bufx05_u U48 ( .A(status_i[46]), .Q(n48) );
  bufx05_u U49 ( .A(status_i[47]), .Q(n49) );
  bufx05_u U50 ( .A(status_i[48]), .Q(n50) );
  bufx05_u U51 ( .A(status_i[49]), .Q(n51) );
  bufx05_u U52 ( .A(status_i[50]), .Q(n52) );
  bufx05_u U53 ( .A(status_i[51]), .Q(n53) );
  bufx05_u U54 ( .A(status_i[52]), .Q(n54) );
  bufx05_u U55 ( .A(status_i[53]), .Q(n55) );
  bufx05_u U56 ( .A(status_i[54]), .Q(n56) );
  bufx05_u U57 ( .A(status_i[55]), .Q(n57) );
  bufx05_u U58 ( .A(status_i[56]), .Q(n58) );
  bufx05_u U59 ( .A(status_i[57]), .Q(n59) );
  bufx05_u U60 ( .A(status_i[58]), .Q(n60) );
  bufx05_u U61 ( .A(status_i[59]), .Q(n61) );
  bufx05_u U62 ( .A(status_i[60]), .Q(n62) );
  bufx05_u U63 ( .A(status_i[61]), .Q(n63) );
  bufx05_u U64 ( .A(status_i[62]), .Q(n64) );
  bufx05_u U65 ( .A(status_i[63]), .Q(n65) );
  bufx05_u U66 ( .A(status_i[64]), .Q(n66) );
  bufx05_u U67 ( .A(status_i[65]), .Q(n67) );
  bufx05_u U68 ( .A(status_i[66]), .Q(n68) );
  bufx05_u U69 ( .A(status_i[67]), .Q(n69) );
  bufx05_u U70 ( .A(status_i[68]), .Q(n70) );
  bufx05_u U71 ( .A(status_i[69]), .Q(n71) );
  bufx05_u U72 ( .A(status_i[70]), .Q(n72) );
  bufx05_u U73 ( .A(status_i[71]), .Q(n73) );
  bufx05_u U74 ( .A(status_i[72]), .Q(n74) );
  bufx05_u U75 ( .A(status_i[73]), .Q(n75) );
  bufx05_u U76 ( .A(status_i[74]), .Q(n76) );
  bufx05_u U77 ( .A(status_i[75]), .Q(n77) );
  bufx05_u U78 ( .A(status_i[76]), .Q(n78) );
  bufx05_u U79 ( .A(status_i[77]), .Q(n79) );
  bufx05_u U80 ( .A(status_i[78]), .Q(n80) );
  bufx05_u U81 ( .A(status_i[79]), .Q(n81) );
  bufx05_u U82 ( .A(status_i[80]), .Q(n82) );
  bufx05_u U83 ( .A(status_i[81]), .Q(n83) );
  bufx05_u U84 ( .A(status_i[82]), .Q(n84) );
  bufx05_u U85 ( .A(status_i[83]), .Q(n85) );
  bufx05_u U86 ( .A(status_i[84]), .Q(n86) );
  bufx05_u U87 ( .A(status_i[85]), .Q(n87) );
  bufx05_u U88 ( .A(status_i[86]), .Q(n88) );
  bufx05_u U89 ( .A(status_i[87]), .Q(n89) );
  bufx05_u U90 ( .A(status_i[88]), .Q(n90) );
  bufx05_u U91 ( .A(status_i[89]), .Q(n91) );
  bufx05_u U92 ( .A(status_i[90]), .Q(n92) );
  bufx05_u U93 ( .A(status_i[91]), .Q(n93) );
  bufx05_u U94 ( .A(status_i[92]), .Q(n94) );
  bufx05_u U95 ( .A(status_i[93]), .Q(n95) );
  bufx05_u U96 ( .A(status_i[94]), .Q(n96) );
  bufx05_u U97 ( .A(status_i[95]), .Q(n97) );
  bufx05_u U98 ( .A(status_i[96]), .Q(n98) );
  bufx05_u U99 ( .A(status_i[97]), .Q(n99) );
  bufx05_u U100 ( .A(status_i[98]), .Q(n100) );
  bufx05_u U101 ( .A(status_i[99]), .Q(n101) );
  bufx05_u U102 ( .A(status_i[100]), .Q(n102) );
  bufx05_u U103 ( .A(status_i[101]), .Q(n103) );
  bufx05_u U104 ( .A(status_i[102]), .Q(n104) );
  bufx05_u U105 ( .A(status_i[103]), .Q(n105) );
  bufx05_u U106 ( .A(status_i[104]), .Q(n106) );
  bufx05_u U107 ( .A(status_i[105]), .Q(n107) );
  bufx05_u U108 ( .A(status_i[106]), .Q(n108) );
  bufx05_u U109 ( .A(status_i[107]), .Q(n109) );
  bufx05_u U110 ( .A(status_i[108]), .Q(n110) );
  bufx05_u U111 ( .A(status_i[109]), .Q(n111) );
  bufx05_u U112 ( .A(status_i[110]), .Q(n112) );
  bufx05_u U113 ( .A(status_i[111]), .Q(n113) );
  bufx05_u U114 ( .A(status_i[112]), .Q(n114) );
  bufx05_u U115 ( .A(status_i[113]), .Q(n115) );
  bufx05_u U116 ( .A(status_i[114]), .Q(n116) );
  bufx05_u U117 ( .A(status_i[115]), .Q(n117) );
  bufx05_u U118 ( .A(status_i[116]), .Q(n118) );
  bufx05_u U119 ( .A(status_i[117]), .Q(n119) );
  bufx05_u U120 ( .A(status_i[118]), .Q(n120) );
  bufx05_u U121 ( .A(status_i[119]), .Q(n121) );
  bufx05_u U122 ( .A(status_i[120]), .Q(n122) );
  bufx05_u U123 ( .A(status_i[121]), .Q(n123) );
  bufx05_u U124 ( .A(status_i[122]), .Q(n124) );
  bufx05_u U125 ( .A(status_i[123]), .Q(n125) );
  bufx05_u U126 ( .A(status_i[124]), .Q(n126) );
  bufx05_u U127 ( .A(status_i[125]), .Q(n127) );
  bufx05_u U128 ( .A(status_i[126]), .Q(n128) );
  bufx05_u U129 ( .A(status_i[127]), .Q(n129) );
  bufx05_u U130 ( .A(status_i[128]), .Q(n130) );
  bufx05_u U131 ( .A(status_i[129]), .Q(n131) );
  bufx05_u U132 ( .A(status_i[130]), .Q(n132) );
  bufx05_u U133 ( .A(status_i[131]), .Q(n133) );
  bufx05_u U134 ( .A(status_i[132]), .Q(n134) );
  bufx05_u U135 ( .A(status_i[133]), .Q(n135) );
  bufx05_u U136 ( .A(status_i[134]), .Q(n136) );
  bufx05_u U137 ( .A(status_i[135]), .Q(n137) );
  bufx05_u U138 ( .A(status_i[136]), .Q(n138) );
  bufx05_u U139 ( .A(status_i[137]), .Q(n139) );
  bufx05_u U140 ( .A(status_i[138]), .Q(n140) );
  bufx05_u U141 ( .A(status_i[139]), .Q(n141) );
  bufx05_u U142 ( .A(status_i[140]), .Q(n142) );
  bufx05_u U143 ( .A(status_i[141]), .Q(n143) );
  bufx05_u U144 ( .A(status_i[142]), .Q(n144) );
  bufx05_u U145 ( .A(status_i[143]), .Q(n145) );
  bufx05_u U146 ( .A(status_i[144]), .Q(n146) );
  bufx05_u U147 ( .A(status_i[145]), .Q(n147) );
  bufx05_u U148 ( .A(status_i[146]), .Q(n148) );
  bufx05_u U149 ( .A(status_i[147]), .Q(n149) );
  bufx05_u U150 ( .A(status_i[148]), .Q(n150) );
  bufx05_u U151 ( .A(status_i[149]), .Q(n151) );
  bufx05_u U152 ( .A(status_i[150]), .Q(n152) );
  bufx05_u U153 ( .A(status_i[151]), .Q(n153) );
  bufx05_u U154 ( .A(status_i[152]), .Q(n154) );
  bufx05_u U155 ( .A(status_i[153]), .Q(n155) );
  bufx05_u U156 ( .A(status_i[154]), .Q(n156) );
  bufx05_u U157 ( .A(status_i[155]), .Q(n157) );
  bufx05_u U158 ( .A(status_i[156]), .Q(n158) );
  bufx05_u U159 ( .A(status_i[157]), .Q(n159) );
  bufx05_u U160 ( .A(status_i[158]), .Q(n160) );
  bufx05_u U161 ( .A(status_i[159]), .Q(n161) );
  bufx05_u U162 ( .A(status_i[160]), .Q(n162) );
  bufx05_u U163 ( .A(status_i[161]), .Q(n163) );
  bufx05_u U164 ( .A(status_i[162]), .Q(n164) );
  bufx05_u U165 ( .A(status_i[163]), .Q(n165) );
  bufx05_u U166 ( .A(status_i[164]), .Q(n166) );
  bufx05_u U167 ( .A(status_i[165]), .Q(n167) );
  bufx05_u U168 ( .A(status_i[166]), .Q(n168) );
  bufx05_u U169 ( .A(status_i[167]), .Q(n169) );
  bufx05_u U170 ( .A(status_i[168]), .Q(n170) );
  bufx05_u U171 ( .A(status_i[169]), .Q(n171) );
  bufx05_u U172 ( .A(status_i[170]), .Q(n172) );
  bufx05_u U173 ( .A(status_i[171]), .Q(n173) );
  bufx05_u U174 ( .A(status_i[172]), .Q(n174) );
  bufx05_u U175 ( .A(status_i[173]), .Q(n175) );
  bufx05_u U176 ( .A(status_i[174]), .Q(n176) );
  bufx05_u U177 ( .A(status_i[175]), .Q(n177) );
  bufx05_u U178 ( .A(status_i[176]), .Q(n178) );
  bufx05_u U179 ( .A(status_i[177]), .Q(n179) );
  bufx05_u U180 ( .A(status_i[178]), .Q(n180) );
  bufx05_u U181 ( .A(status_i[179]), .Q(n181) );
  bufx05_u U182 ( .A(status_i[180]), .Q(n182) );
  bufx05_u U183 ( .A(status_i[181]), .Q(n183) );
  bufx05_u U184 ( .A(status_i[182]), .Q(n184) );
  bufx05_u U185 ( .A(status_i[183]), .Q(n185) );
  bufx05_u U186 ( .A(status_i[184]), .Q(n186) );
  bufx05_u U187 ( .A(status_i[185]), .Q(n187) );
  bufx05_u U188 ( .A(status_i[186]), .Q(n188) );
  bufx05_u U189 ( .A(status_i[187]), .Q(n189) );
  bufx05_u U190 ( .A(status_i[188]), .Q(n190) );
  bufx05_u U191 ( .A(status_i[189]), .Q(n191) );
  bufx05_u U192 ( .A(status_i[190]), .Q(n192) );
  bufx05_u U193 ( .A(status_i[191]), .Q(n193) );
  bufx05_u U194 ( .A(status_i[192]), .Q(n194) );
  bufx05_u U195 ( .A(status_i[193]), .Q(n195) );
  bufx05_u U196 ( .A(status_i[194]), .Q(n196) );
  bufx05_u U197 ( .A(status_i[195]), .Q(n197) );
  bufx05_u U198 ( .A(status_i[196]), .Q(n198) );
  bufx05_u U199 ( .A(status_i[197]), .Q(n199) );
  bufx05_u U200 ( .A(status_i[198]), .Q(n200) );
  bufx05_u U201 ( .A(status_i[199]), .Q(n201) );
  bufx05_u U202 ( .A(status_i[200]), .Q(n202) );
  bufx05_u U203 ( .A(status_i[201]), .Q(n203) );
  bufx05_u U204 ( .A(status_i[202]), .Q(n204) );
  bufx05_u U205 ( .A(status_i[203]), .Q(n205) );
  bufx05_u U206 ( .A(status_i[204]), .Q(n206) );
  bufx05_u U207 ( .A(status_i[205]), .Q(n207) );
  bufx05_u U208 ( .A(status_i[206]), .Q(n208) );
  bufx05_u U209 ( .A(status_i[207]), .Q(n209) );
  bufx05_u U210 ( .A(status_i[208]), .Q(n210) );
  bufx05_u U211 ( .A(status_i[209]), .Q(n211) );
  bufx05_u U212 ( .A(status_i[210]), .Q(n212) );
  bufx05_u U213 ( .A(status_i[211]), .Q(n213) );
  bufx05_u U214 ( .A(status_i[212]), .Q(n214) );
  bufx05_u U215 ( .A(status_i[213]), .Q(n215) );
  bufx05_u U216 ( .A(status_i[214]), .Q(n216) );
  bufx05_u U217 ( .A(status_i[215]), .Q(n217) );
  bufx05_u U218 ( .A(status_i[216]), .Q(n218) );
  bufx05_u U219 ( .A(status_i[217]), .Q(n219) );
  bufx05_u U220 ( .A(status_i[218]), .Q(n220) );
  bufx05_u U221 ( .A(status_i[219]), .Q(n221) );
  bufx05_u U222 ( .A(status_i[220]), .Q(n222) );
  bufx05_u U223 ( .A(status_i[221]), .Q(n223) );
  bufx05_u U224 ( .A(status_i[222]), .Q(n224) );
  bufx05_u U225 ( .A(status_i[223]), .Q(n225) );
  bufx05_u U226 ( .A(status_i[224]), .Q(n226) );
  bufx05_u U227 ( .A(status_i[225]), .Q(n227) );
  bufx05_u U228 ( .A(status_i[226]), .Q(n228) );
  bufx05_u U229 ( .A(status_i[227]), .Q(n229) );
  bufx05_u U230 ( .A(status_i[228]), .Q(n230) );
  bufx05_u U231 ( .A(status_i[229]), .Q(n231) );
  bufx05_u U232 ( .A(status_i[230]), .Q(n232) );
  bufx05_u U233 ( .A(status_i[231]), .Q(n233) );
  bufx05_u U234 ( .A(status_i[232]), .Q(n234) );
  bufx05_u U235 ( .A(status_i[233]), .Q(n235) );
  bufx05_u U236 ( .A(status_i[234]), .Q(n236) );
  bufx05_u U237 ( .A(status_i[235]), .Q(n237) );
  bufx05_u U238 ( .A(status_i[236]), .Q(n238) );
  bufx05_u U239 ( .A(status_i[237]), .Q(n239) );
  bufx05_u U240 ( .A(status_i[238]), .Q(n240) );
  bufx05_u U241 ( .A(status_i[239]), .Q(n241) );
  bufx05_u U242 ( .A(status_i[240]), .Q(n242) );
  bufx05_u U243 ( .A(status_i[241]), .Q(n243) );
  bufx05_u U244 ( .A(status_i[242]), .Q(n244) );
  bufx05_u U245 ( .A(status_i[243]), .Q(n245) );
  bufx05_u U246 ( .A(status_i[244]), .Q(n246) );
  bufx05_u U247 ( .A(status_i[245]), .Q(n247) );
  bufx05_u U248 ( .A(status_i[246]), .Q(n248) );
  bufx05_u U249 ( .A(status_i[247]), .Q(n249) );
  bufx05_u U250 ( .A(status_i[248]), .Q(n250) );
  bufx05_u U251 ( .A(status_i[249]), .Q(n251) );
  bufx05_u U252 ( .A(status_i[250]), .Q(n252) );
  bufx05_u U253 ( .A(status_i[251]), .Q(n253) );
  bufx05_u U254 ( .A(status_i[252]), .Q(n254) );
  bufx05_u U255 ( .A(status_i[253]), .Q(n255) );
  bufx05_u U256 ( .A(status_i[254]), .Q(n256) );
  bufx05_u U257 ( .A(status_i[255]), .Q(n257) );
  bufx05_u U258 ( .A(status_i[256]), .Q(n258) );
  bufx05_u U259 ( .A(status_i[257]), .Q(n259) );
  bufx05_u U260 ( .A(status_i[258]), .Q(n260) );
  bufx05_u U261 ( .A(status_i[259]), .Q(n261) );
  bufx05_u U262 ( .A(status_i[260]), .Q(n262) );
  bufx05_u U263 ( .A(status_i[261]), .Q(n263) );
  bufx05_u U264 ( .A(status_i[262]), .Q(n264) );
  bufx05_u U265 ( .A(status_i[263]), .Q(n265) );
  bufx05_u U266 ( .A(status_i[264]), .Q(n266) );
  bufx05_u U267 ( .A(status_i[265]), .Q(n267) );
  bufx05_u U268 ( .A(status_i[266]), .Q(n268) );
  bufx05_u U269 ( .A(status_i[267]), .Q(n269) );
  bufx05_u U270 ( .A(status_i[268]), .Q(n270) );
  bufx05_u U271 ( .A(status_i[269]), .Q(n271) );
  bufx05_u U272 ( .A(status_i[270]), .Q(n272) );
  bufx05_u U273 ( .A(status_i[271]), .Q(n273) );
  bufx05_u U274 ( .A(status_i[272]), .Q(n274) );
  bufx05_u U275 ( .A(status_i[273]), .Q(n275) );
  bufx05_u U276 ( .A(status_i[274]), .Q(n276) );
  bufx05_u U277 ( .A(status_i[275]), .Q(n277) );
  bufx05_u U278 ( .A(status_i[276]), .Q(n278) );
  bufx05_u U279 ( .A(status_i[277]), .Q(n279) );
  bufx05_u U280 ( .A(status_i[278]), .Q(n280) );
  bufx05_u U281 ( .A(status_i[279]), .Q(n281) );
  bufx05_u U282 ( .A(status_i[280]), .Q(n282) );
  bufx05_u U283 ( .A(status_i[281]), .Q(n283) );
  bufx05_u U284 ( .A(status_i[282]), .Q(n284) );
  bufx05_u U285 ( .A(status_i[283]), .Q(n285) );
  bufx05_u U286 ( .A(status_i[284]), .Q(n286) );
  bufx05_u U287 ( .A(status_i[285]), .Q(n287) );
  bufx05_u U288 ( .A(status_i[286]), .Q(n288) );
  bufx05_u U289 ( .A(status_i[287]), .Q(n289) );
  bufx05_u U290 ( .A(status_i[288]), .Q(n290) );
  bufx05_u U291 ( .A(status_i[289]), .Q(n291) );
  bufx05_u U292 ( .A(status_i[290]), .Q(n292) );
  bufx05_u U293 ( .A(status_i[291]), .Q(n293) );
  bufx05_u U294 ( .A(status_i[292]), .Q(n294) );
  bufx05_u U295 ( .A(status_i[293]), .Q(n295) );
  bufx05_u U296 ( .A(status_i[294]), .Q(n296) );
  bufx05_u U297 ( .A(status_i[295]), .Q(n297) );
  bufx05_u U298 ( .A(status_i[296]), .Q(n298) );
  bufx05_u U299 ( .A(status_i[297]), .Q(n299) );
  bufx05_u U300 ( .A(status_i[298]), .Q(n300) );
  bufx05_u U301 ( .A(status_i[299]), .Q(n301) );
  bufx05_u U302 ( .A(status_i[300]), .Q(n302) );
  bufx05_u U303 ( .A(status_i[301]), .Q(n303) );
  bufx05_u U304 ( .A(status_i[302]), .Q(n304) );
  bufx05_u U305 ( .A(status_i[303]), .Q(n305) );
  bufx05_u U306 ( .A(status_i[304]), .Q(n306) );
  bufx05_u U307 ( .A(status_i[305]), .Q(n307) );
  bufx05_u U308 ( .A(status_i[306]), .Q(n308) );
  bufx05_u U309 ( .A(status_i[307]), .Q(n309) );
  bufx05_u U310 ( .A(status_i[308]), .Q(n310) );
  bufx05_u U311 ( .A(status_i[309]), .Q(n311) );
  bufx05_u U312 ( .A(status_i[310]), .Q(n312) );
  bufx05_u U313 ( .A(status_i[311]), .Q(n313) );
  bufx05_u U314 ( .A(status_i[312]), .Q(n314) );
  bufx05_u U315 ( .A(status_i[313]), .Q(n315) );
  bufx05_u U316 ( .A(status_i[314]), .Q(n316) );
  bufx05_u U317 ( .A(status_i[315]), .Q(n317) );
  bufx05_u U318 ( .A(status_i[316]), .Q(n318) );
  bufx05_u U319 ( .A(status_i[317]), .Q(n319) );
  bufx05_u U320 ( .A(status_i[318]), .Q(n320) );
  bufx05_u U321 ( .A(status_i[319]), .Q(n321) );
  bufx05_u U322 ( .A(rst_n), .Q(n325) );
  bufx05_u U323 ( .A(SPI_MOSI), .Q(n322) );
  bufx05_u U324 ( .A(SPI_SS), .Q(n323) );
  tohlx1_u U325 ( .TL(n324) );
endmodule

