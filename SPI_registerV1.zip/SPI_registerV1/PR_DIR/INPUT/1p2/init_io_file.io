 Version = 1



Pad: cornerBL SW 
Pad: VDD_1	S
Pad: VSS_1	S
Pad: VDDIO_1	S
Pad: VSSIO_1	S
Pad: PVDDESD_1  S

Pad: i2c_scl_IO S
Pad: i2c_sda_IO S
Pad: uart_rx_IO S
Pad: uart_tx_IO S

Pad: sd_clk_o_pad_IO S
Pad: sd_cmd_IO S
Pad: sd_dat_port[0].sd_dat_IO S
Pad: sd_dat_port[1].sd_dat_IO S
Pad: sd_dat_port[2].sd_dat_IO S
Pad: sd_dat_port[3].sd_dat_IO S
Pad: spi_debug_clk_IO S
Pad: spi_debug_cs_IO S
Pad: spi_debug_miso_IO S
Pad: spi_debug_mosi_IO S
Pad: spi_flash_clk_IO S
Pad: spi_flash_cs_IO S
Pad: spi_flash_miso_IO S
Pad: spi_flash_mosi_IO S

Pad: VDD_12  S
Pad: VSS_12  S
Pad: VDDIO_12    S
Pad: VSSIO_12    S
Pad: PVDDESD_12  S










Pad: cornerBR SE 
Pad: VDD_4  E
Pad: VSS_4  E
Pad: VDDIO_4    E
Pad: VSSIO_4    E
Pad: PVDDESD_4  E

Pad: VDDA_CUT21 E
Pad: VDDA2 E
Pad: VSSA2 E
Pad: VDDA_CUT22 E

Pad: VDD_42  E
Pad: VSS_42  E
Pad: VDDIO_42    E
Pad: VSSIO_42    E
Pad: PVDDESD_42  E


    

Pad: cornerTR NE 
Pad: VDD_3  N
Pad: VSS_3  N
Pad: VDDIO_3    N
Pad: VSSIO_3    N
Pad: PVDDESD_3  N

Pad: VDDA_CUT31 N
Pad: VDDA3 N
Pad: VSSA3 N
Pad: VDDA_CUT32 N

Pad: VDD_32  N
Pad: VSS_32  N
Pad: VDDIO_32    N
Pad: VSSIO_32    N
Pad: PVDDESD_32  N
    

Pad: cornerTL NW 

Pad: VDD_23  W
Pad: VSS_23  W
Pad: VDDIO_23    W
Pad: VSSIO_23    W
Pad: PVDDESD_23  W
Pad: PVDDESD_231  W



Pad: xtal_IO W
Pad: clk_sel_IO W
Pad: rst_n_IO W
Pad: LD_OUT_IO W

Pad: VDDA_CUT11 W
Pad: PLL_out_check W
Pad: VDDA1 W
Pad: RX_out_chenck W
Pad: VSSA1 W
Pad: clk_chenk W
Pad: VDDA_CUT12 W

Pad: VDD_2  W
Pad: VSS_2  W
Pad: VDDIO_2    W
Pad: VSSIO_2    W
Pad: PVDDESD_2  W

Pad: VDD_22  W
Pad: VSS_22  W
Pad: VDDIO_22    W
Pad: VSSIO_22    W
Pad: PVDDESD_22  W




