/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Ultra(TM) in wire load mode
// Version   : O-2018.06-SP1
// Date      : Fri Oct 28 14:44:50 2022
/////////////////////////////////////////////////////////////


module SNPS_CLOCK_GATE_HIGH_spi_reg_interface_3 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  clksgpx1_u latch ( .CK(CLK), .E(EN), .SE(TE), .Q(ENCLK) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_25 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  clksgpx1_u latch ( .CK(CLK), .E(EN), .SE(TE), .Q(ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_spi_slave_2 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;


  clksgpx1_u latch ( .CK(CLK), .E(EN), .SE(TE), .Q(ENCLK) );
endmodule


module SNPS_CLOCK_GATE_HIGH_spi_slave_0 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule


module SNPS_CLOCK_GATE_HIGH_spi_slave_1 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_0 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_1 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_2 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_3 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_4 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_5 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_6 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_7 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_8 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_9 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_10 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_11 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_12 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_13 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_14 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_15 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_16 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_17 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_18 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_19 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_20 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_21 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_22 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_23 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule



    module SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_24 ( 
        CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule


module SNPS_CLOCK_GATE_HIGH_spi_reg_interface_1 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule


module SNPS_CLOCK_GATE_HIGH_spi_reg_interface_2 ( CLK, EN, ENCLK, TE );
  input CLK, EN, TE;
  output ENCLK;
  wire   n1, n2;
  assign ENCLK = n1;
  assign n2 = CLK;

  clksgpx1_u latch ( .CK(n2), .E(EN), .SE(TE), .Q(n1) );
endmodule


module spi_top ( clk, rst_n, SPI_CLK, SPI_MOSI, SPI_SS, SPI_MISO, control_o, 
        status_i );
  output [191:0] control_o;
  input [319:0] status_i;
  input clk, rst_n, SPI_CLK, SPI_MOSI, SPI_SS;
  output SPI_MISO;
  wire   reg_wr_en, reg_rd_en, \u_spi_reg_interface/net810 ,
         \u_spi_reg_interface/net805 , \u_spi_reg_interface/net800 ,
         \u_spi_reg_interface/N52 , \u_spi_reg_interface/N51 ,
         \u_spi_reg_interface/N47 , \u_spi_reg_interface/N45 ,
         \u_spi_reg_interface/byte_cnt , \u_spi_reg_interface/spi_tx_busy ,
         \u_spi_reg_interface/spi_rx_vaild , \u_inst_reg/net777 ,
         \u_inst_reg/net772 , \u_inst_reg/net767 , \u_inst_reg/net762 ,
         \u_inst_reg/net757 , \u_inst_reg/net752 , \u_inst_reg/net747 ,
         \u_inst_reg/net742 , \u_inst_reg/net737 , \u_inst_reg/net732 ,
         \u_inst_reg/net727 , \u_inst_reg/net722 , \u_inst_reg/net717 ,
         \u_inst_reg/net712 , \u_inst_reg/net707 , \u_inst_reg/net702 ,
         \u_inst_reg/net697 , \u_inst_reg/net692 , \u_inst_reg/net687 ,
         \u_inst_reg/net682 , \u_inst_reg/net677 , \u_inst_reg/net672 ,
         \u_inst_reg/net667 , \u_inst_reg/net662 , \u_inst_reg/net657 ,
         \u_inst_reg/net651 , \u_inst_reg/N723 , \u_inst_reg/N722 ,
         \u_inst_reg/N721 , \u_inst_reg/N720 , \u_inst_reg/N719 ,
         \u_inst_reg/N718 , \u_inst_reg/N717 , \u_inst_reg/N716 ,
         \u_inst_reg/N155 , \u_inst_reg/N154 , \u_inst_reg/N153 ,
         \u_inst_reg/N152 , \u_inst_reg/N151 , \u_inst_reg/N150 ,
         \u_inst_reg/N149 , \u_inst_reg/N148 , \u_inst_reg/N147 ,
         \u_inst_reg/N146 , \u_inst_reg/N145 , \u_inst_reg/N144 ,
         \u_inst_reg/N143 , \u_inst_reg/N142 , \u_inst_reg/N141 ,
         \u_inst_reg/N140 , \u_inst_reg/N139 , \u_inst_reg/N138 ,
         \u_inst_reg/N137 , \u_inst_reg/N136 , \u_inst_reg/N135 ,
         \u_inst_reg/N134 , \u_inst_reg/N133 , \u_inst_reg/N132 ,
         \u_inst_reg/reg_array[24][0] , \u_inst_reg/reg_array[24][1] ,
         \u_inst_reg/reg_array[24][2] , \u_inst_reg/reg_array[24][3] ,
         \u_inst_reg/reg_array[24][4] , \u_inst_reg/reg_array[24][5] ,
         \u_inst_reg/reg_array[24][6] , \u_inst_reg/reg_array[24][7] ,
         \u_inst_reg/reg_array[25][0] , \u_inst_reg/reg_array[25][1] ,
         \u_inst_reg/reg_array[25][2] , \u_inst_reg/reg_array[25][3] ,
         \u_inst_reg/reg_array[25][4] , \u_inst_reg/reg_array[25][5] ,
         \u_inst_reg/reg_array[25][6] , \u_inst_reg/reg_array[25][7] ,
         \u_inst_reg/reg_array[26][0] , \u_inst_reg/reg_array[26][1] ,
         \u_inst_reg/reg_array[26][2] , \u_inst_reg/reg_array[26][3] ,
         \u_inst_reg/reg_array[26][4] , \u_inst_reg/reg_array[26][5] ,
         \u_inst_reg/reg_array[26][6] , \u_inst_reg/reg_array[26][7] ,
         \u_inst_reg/reg_array[27][0] , \u_inst_reg/reg_array[27][1] ,
         \u_inst_reg/reg_array[27][2] , \u_inst_reg/reg_array[27][3] ,
         \u_inst_reg/reg_array[27][4] , \u_inst_reg/reg_array[27][5] ,
         \u_inst_reg/reg_array[27][6] , \u_inst_reg/reg_array[27][7] ,
         \u_inst_reg/reg_array[28][0] , \u_inst_reg/reg_array[28][1] ,
         \u_inst_reg/reg_array[28][2] , \u_inst_reg/reg_array[28][3] ,
         \u_inst_reg/reg_array[28][4] , \u_inst_reg/reg_array[28][5] ,
         \u_inst_reg/reg_array[28][6] , \u_inst_reg/reg_array[28][7] ,
         \u_inst_reg/reg_array[29][0] , \u_inst_reg/reg_array[29][1] ,
         \u_inst_reg/reg_array[29][2] , \u_inst_reg/reg_array[29][3] ,
         \u_inst_reg/reg_array[29][4] , \u_inst_reg/reg_array[29][5] ,
         \u_inst_reg/reg_array[29][6] , \u_inst_reg/reg_array[29][7] ,
         \u_inst_reg/reg_array[30][0] , \u_inst_reg/reg_array[30][1] ,
         \u_inst_reg/reg_array[30][2] , \u_inst_reg/reg_array[30][3] ,
         \u_inst_reg/reg_array[30][4] , \u_inst_reg/reg_array[30][5] ,
         \u_inst_reg/reg_array[30][6] , \u_inst_reg/reg_array[30][7] ,
         \u_inst_reg/reg_array[31][0] , \u_inst_reg/reg_array[31][1] ,
         \u_inst_reg/reg_array[31][2] , \u_inst_reg/reg_array[31][3] ,
         \u_inst_reg/reg_array[31][4] , \u_inst_reg/reg_array[31][5] ,
         \u_inst_reg/reg_array[31][6] , \u_inst_reg/reg_array[31][7] ,
         \u_inst_reg/reg_array[32][0] , \u_inst_reg/reg_array[32][1] ,
         \u_inst_reg/reg_array[32][2] , \u_inst_reg/reg_array[32][3] ,
         \u_inst_reg/reg_array[32][4] , \u_inst_reg/reg_array[32][5] ,
         \u_inst_reg/reg_array[32][6] , \u_inst_reg/reg_array[32][7] ,
         \u_inst_reg/reg_array[33][0] , \u_inst_reg/reg_array[33][1] ,
         \u_inst_reg/reg_array[33][2] , \u_inst_reg/reg_array[33][3] ,
         \u_inst_reg/reg_array[33][4] , \u_inst_reg/reg_array[33][5] ,
         \u_inst_reg/reg_array[33][6] , \u_inst_reg/reg_array[33][7] ,
         \u_inst_reg/reg_array[34][0] , \u_inst_reg/reg_array[34][1] ,
         \u_inst_reg/reg_array[34][2] , \u_inst_reg/reg_array[34][3] ,
         \u_inst_reg/reg_array[34][4] , \u_inst_reg/reg_array[34][5] ,
         \u_inst_reg/reg_array[34][6] , \u_inst_reg/reg_array[34][7] ,
         \u_inst_reg/reg_array[35][0] , \u_inst_reg/reg_array[35][1] ,
         \u_inst_reg/reg_array[35][2] , \u_inst_reg/reg_array[35][3] ,
         \u_inst_reg/reg_array[35][4] , \u_inst_reg/reg_array[35][5] ,
         \u_inst_reg/reg_array[35][6] , \u_inst_reg/reg_array[35][7] ,
         \u_inst_reg/reg_array[36][0] , \u_inst_reg/reg_array[36][1] ,
         \u_inst_reg/reg_array[36][2] , \u_inst_reg/reg_array[36][3] ,
         \u_inst_reg/reg_array[36][4] , \u_inst_reg/reg_array[36][5] ,
         \u_inst_reg/reg_array[36][6] , \u_inst_reg/reg_array[36][7] ,
         \u_inst_reg/reg_array[37][0] , \u_inst_reg/reg_array[37][1] ,
         \u_inst_reg/reg_array[37][2] , \u_inst_reg/reg_array[37][3] ,
         \u_inst_reg/reg_array[37][4] , \u_inst_reg/reg_array[37][5] ,
         \u_inst_reg/reg_array[37][6] , \u_inst_reg/reg_array[37][7] ,
         \u_inst_reg/reg_array[38][0] , \u_inst_reg/reg_array[38][1] ,
         \u_inst_reg/reg_array[38][2] , \u_inst_reg/reg_array[38][3] ,
         \u_inst_reg/reg_array[38][4] , \u_inst_reg/reg_array[38][5] ,
         \u_inst_reg/reg_array[38][6] , \u_inst_reg/reg_array[38][7] ,
         \u_inst_reg/reg_array[39][0] , \u_inst_reg/reg_array[39][1] ,
         \u_inst_reg/reg_array[39][2] , \u_inst_reg/reg_array[39][3] ,
         \u_inst_reg/reg_array[39][4] , \u_inst_reg/reg_array[39][5] ,
         \u_inst_reg/reg_array[39][6] , \u_inst_reg/reg_array[39][7] ,
         \u_inst_reg/reg_array[40][0] , \u_inst_reg/reg_array[40][1] ,
         \u_inst_reg/reg_array[40][2] , \u_inst_reg/reg_array[40][3] ,
         \u_inst_reg/reg_array[40][4] , \u_inst_reg/reg_array[40][5] ,
         \u_inst_reg/reg_array[40][6] , \u_inst_reg/reg_array[40][7] ,
         \u_inst_reg/reg_array[41][0] , \u_inst_reg/reg_array[41][1] ,
         \u_inst_reg/reg_array[41][2] , \u_inst_reg/reg_array[41][3] ,
         \u_inst_reg/reg_array[41][4] , \u_inst_reg/reg_array[41][5] ,
         \u_inst_reg/reg_array[41][6] , \u_inst_reg/reg_array[41][7] ,
         \u_inst_reg/reg_array[42][0] , \u_inst_reg/reg_array[42][1] ,
         \u_inst_reg/reg_array[42][2] , \u_inst_reg/reg_array[42][3] ,
         \u_inst_reg/reg_array[42][4] , \u_inst_reg/reg_array[42][5] ,
         \u_inst_reg/reg_array[42][6] , \u_inst_reg/reg_array[42][7] ,
         \u_inst_reg/reg_array[43][0] , \u_inst_reg/reg_array[43][1] ,
         \u_inst_reg/reg_array[43][2] , \u_inst_reg/reg_array[43][3] ,
         \u_inst_reg/reg_array[43][4] , \u_inst_reg/reg_array[43][5] ,
         \u_inst_reg/reg_array[43][6] , \u_inst_reg/reg_array[43][7] ,
         \u_inst_reg/reg_array[44][0] , \u_inst_reg/reg_array[44][1] ,
         \u_inst_reg/reg_array[44][2] , \u_inst_reg/reg_array[44][3] ,
         \u_inst_reg/reg_array[44][4] , \u_inst_reg/reg_array[44][5] ,
         \u_inst_reg/reg_array[44][6] , \u_inst_reg/reg_array[44][7] ,
         \u_inst_reg/reg_array[45][0] , \u_inst_reg/reg_array[45][1] ,
         \u_inst_reg/reg_array[45][2] , \u_inst_reg/reg_array[45][3] ,
         \u_inst_reg/reg_array[45][4] , \u_inst_reg/reg_array[45][5] ,
         \u_inst_reg/reg_array[45][6] , \u_inst_reg/reg_array[45][7] ,
         \u_inst_reg/reg_array[46][0] , \u_inst_reg/reg_array[46][1] ,
         \u_inst_reg/reg_array[46][2] , \u_inst_reg/reg_array[46][3] ,
         \u_inst_reg/reg_array[46][4] , \u_inst_reg/reg_array[46][5] ,
         \u_inst_reg/reg_array[46][6] , \u_inst_reg/reg_array[46][7] ,
         \u_inst_reg/reg_array[47][0] , \u_inst_reg/reg_array[47][1] ,
         \u_inst_reg/reg_array[47][2] , \u_inst_reg/reg_array[47][3] ,
         \u_inst_reg/reg_array[47][4] , \u_inst_reg/reg_array[47][5] ,
         \u_inst_reg/reg_array[47][6] , \u_inst_reg/reg_array[47][7] ,
         \u_inst_reg/reg_array[48][0] , \u_inst_reg/reg_array[48][1] ,
         \u_inst_reg/reg_array[48][2] , \u_inst_reg/reg_array[48][3] ,
         \u_inst_reg/reg_array[48][4] , \u_inst_reg/reg_array[48][5] ,
         \u_inst_reg/reg_array[48][6] , \u_inst_reg/reg_array[48][7] ,
         \u_inst_reg/reg_array[49][0] , \u_inst_reg/reg_array[49][1] ,
         \u_inst_reg/reg_array[49][2] , \u_inst_reg/reg_array[49][3] ,
         \u_inst_reg/reg_array[49][4] , \u_inst_reg/reg_array[49][5] ,
         \u_inst_reg/reg_array[49][6] , \u_inst_reg/reg_array[49][7] ,
         \u_inst_reg/reg_array[50][0] , \u_inst_reg/reg_array[50][1] ,
         \u_inst_reg/reg_array[50][2] , \u_inst_reg/reg_array[50][3] ,
         \u_inst_reg/reg_array[50][4] , \u_inst_reg/reg_array[50][5] ,
         \u_inst_reg/reg_array[50][6] , \u_inst_reg/reg_array[50][7] ,
         \u_inst_reg/reg_array[51][0] , \u_inst_reg/reg_array[51][1] ,
         \u_inst_reg/reg_array[51][2] , \u_inst_reg/reg_array[51][3] ,
         \u_inst_reg/reg_array[51][4] , \u_inst_reg/reg_array[51][5] ,
         \u_inst_reg/reg_array[51][6] , \u_inst_reg/reg_array[51][7] ,
         \u_inst_reg/reg_array[52][0] , \u_inst_reg/reg_array[52][1] ,
         \u_inst_reg/reg_array[52][2] , \u_inst_reg/reg_array[52][3] ,
         \u_inst_reg/reg_array[52][4] , \u_inst_reg/reg_array[52][5] ,
         \u_inst_reg/reg_array[52][6] , \u_inst_reg/reg_array[52][7] ,
         \u_inst_reg/reg_array[53][0] , \u_inst_reg/reg_array[53][1] ,
         \u_inst_reg/reg_array[53][2] , \u_inst_reg/reg_array[53][3] ,
         \u_inst_reg/reg_array[53][4] , \u_inst_reg/reg_array[53][5] ,
         \u_inst_reg/reg_array[53][6] , \u_inst_reg/reg_array[53][7] ,
         \u_inst_reg/reg_array[54][0] , \u_inst_reg/reg_array[54][1] ,
         \u_inst_reg/reg_array[54][2] , \u_inst_reg/reg_array[54][3] ,
         \u_inst_reg/reg_array[54][4] , \u_inst_reg/reg_array[54][5] ,
         \u_inst_reg/reg_array[54][6] , \u_inst_reg/reg_array[54][7] ,
         \u_inst_reg/reg_array[55][0] , \u_inst_reg/reg_array[55][1] ,
         \u_inst_reg/reg_array[55][2] , \u_inst_reg/reg_array[55][3] ,
         \u_inst_reg/reg_array[55][4] , \u_inst_reg/reg_array[55][5] ,
         \u_inst_reg/reg_array[55][6] , \u_inst_reg/reg_array[55][7] ,
         \u_inst_reg/reg_array[56][0] , \u_inst_reg/reg_array[56][1] ,
         \u_inst_reg/reg_array[56][2] , \u_inst_reg/reg_array[56][3] ,
         \u_inst_reg/reg_array[56][4] , \u_inst_reg/reg_array[56][5] ,
         \u_inst_reg/reg_array[56][6] , \u_inst_reg/reg_array[56][7] ,
         \u_inst_reg/reg_array[57][0] , \u_inst_reg/reg_array[57][1] ,
         \u_inst_reg/reg_array[57][2] , \u_inst_reg/reg_array[57][3] ,
         \u_inst_reg/reg_array[57][4] , \u_inst_reg/reg_array[57][5] ,
         \u_inst_reg/reg_array[57][6] , \u_inst_reg/reg_array[57][7] ,
         \u_inst_reg/reg_array[58][0] , \u_inst_reg/reg_array[58][1] ,
         \u_inst_reg/reg_array[58][2] , \u_inst_reg/reg_array[58][3] ,
         \u_inst_reg/reg_array[58][4] , \u_inst_reg/reg_array[58][5] ,
         \u_inst_reg/reg_array[58][6] , \u_inst_reg/reg_array[58][7] ,
         \u_inst_reg/reg_array[59][0] , \u_inst_reg/reg_array[59][1] ,
         \u_inst_reg/reg_array[59][2] , \u_inst_reg/reg_array[59][3] ,
         \u_inst_reg/reg_array[59][4] , \u_inst_reg/reg_array[59][5] ,
         \u_inst_reg/reg_array[59][6] , \u_inst_reg/reg_array[59][7] ,
         \u_inst_reg/reg_array[60][0] , \u_inst_reg/reg_array[60][1] ,
         \u_inst_reg/reg_array[60][2] , \u_inst_reg/reg_array[60][3] ,
         \u_inst_reg/reg_array[60][4] , \u_inst_reg/reg_array[60][5] ,
         \u_inst_reg/reg_array[60][6] , \u_inst_reg/reg_array[60][7] ,
         \u_inst_reg/reg_array[61][0] , \u_inst_reg/reg_array[61][1] ,
         \u_inst_reg/reg_array[61][2] , \u_inst_reg/reg_array[61][3] ,
         \u_inst_reg/reg_array[61][4] , \u_inst_reg/reg_array[61][5] ,
         \u_inst_reg/reg_array[61][6] , \u_inst_reg/reg_array[61][7] ,
         \u_inst_reg/reg_array[62][0] , \u_inst_reg/reg_array[62][1] ,
         \u_inst_reg/reg_array[62][2] , \u_inst_reg/reg_array[62][3] ,
         \u_inst_reg/reg_array[62][4] , \u_inst_reg/reg_array[62][5] ,
         \u_inst_reg/reg_array[62][6] , \u_inst_reg/reg_array[62][7] ,
         \u_inst_reg/reg_array[63][0] , \u_inst_reg/reg_array[63][1] ,
         \u_inst_reg/reg_array[63][2] , \u_inst_reg/reg_array[63][3] ,
         \u_inst_reg/reg_array[63][4] , \u_inst_reg/reg_array[63][5] ,
         \u_inst_reg/reg_array[63][6] , \u_inst_reg/reg_array[63][7] ,
         \u_spi_reg_interface/u_spi_slave/net838 ,
         \u_spi_reg_interface/u_spi_slave/net833 ,
         \u_spi_reg_interface/u_spi_slave/net828 ,
         \u_spi_reg_interface/u_spi_slave/net827 ,
         \u_spi_reg_interface/u_spi_slave/N93 ,
         \u_spi_reg_interface/u_spi_slave/r_SPI_MISO_Bit ,
         \u_spi_reg_interface/u_spi_slave/N58 , n593, n594, n595, n596, n597,
         n598, n599, n600, n601, n602, n603, n604, n605, n606, n607, n608,
         n609, n610, n611, n612, n613, n614, n615, n616, n617, n618, n619,
         n620, n621, n622, n623, n624, n625, n626, n627, n628, n629, n630,
         n631, n632, n633, n634, n635, n636, n637, n638, n639, n640, n641,
         n642, n643, n644, n645, n646, n647, n648, n649, n650, n651, n652,
         n653, n654, n655, n656, n657, n658, n659, n660, n661, n662, n663,
         n664, n665, n666, n667, n668, n669, n670, n671, n672, n673, n674,
         n675, n676, n677, n678, n679, n680, n681, n682, n683, n684, n685,
         n686, n687, n688, n689, n690, n691, n692, n693, n694, n695, n696,
         n697, n698, n699, n700, n701, n702, n703, n704, n705, n706, n707,
         n708, n709, n710, n711, n712, n713, n714, n715, n716, n717, n718,
         n719, n720, n721, n722, n723, n724, n725, n726, n727, n728, n729,
         n730, n731, n732, n733, n734, n735, n736, n737, n738, n739, n740,
         n741, n742, n743, n744, n745, n746, n747, n748, n749, n750, n751,
         n752, n753, n754, n755, n756, n757, n758, n759, n760, n761, n762,
         n763, n764, n765, n766, n767, n768, n769, n770, n771, n772, n773,
         n774, n775, n776, n777, n778, n779, n780, n781, n782, n783, n784,
         n785, n786, n787, n788, n789, n790, n791, n792, n793, n794, n795,
         n796, n797, n798, n799, n800, n801, n802, n803, n804, n805, n806,
         n807, n808, n809, n810, n811, n812, n813, n814, n815, n816, n817,
         n818, n819, n820, n821, n822, n823, n824, n825, n826, n827, n828,
         n829, n830, n831, n832, n833, n834, n835, n836, n837, n838, n839,
         n840, n841, n842, n843, n844, n845, n846, n847, n848, n849, n850,
         n851, n852, n853, n854, n855, n856, n857, n858, n859, n860, n861,
         n862, n863, n864, n865, n866, n867, n868, n869, n870, n871, n872,
         n873, n874, n875, n876, n877, n878, n879, n880, n881, n882, n883,
         n884, n885, n886, n887, n888, n889, n890, n891, n892, n893, n894,
         n895, n896, n897, n898, n899, n900, n901, n902, n903, n904, n905,
         n906, n907, n908, n909, n910, n911, n912, n913, n914, n915, n916,
         n917, n918, n919, n920, n921, n922, n923, n924, n925, n926, n927,
         n928, n929, n930, n931, n932, n933, n934, n935, n936, n937, n938,
         n939, n940, n941, n942, n943, n944, n945, n946, n947, n948, n949,
         n950, n951, n952, n953, n954, n955, n956, n957, n958, n959, n960,
         n961, n962, n963, n964, n965, n966, n967, n968, n969, n970, n971,
         n972, n973, n974, n975, n976, n977, n978, n979, n980, n981, n982,
         n983, n984, n985, n986, n987, n988, n989, n990, n991, n992, n993,
         n994, n995, n996, n997, n998, n999, n1000, n1001, n1002, n1003, n1004,
         n1005, n1006, n1007, n1008, n1009, n1010, n1011, n1012, n1013, n1014,
         n1015, n1016, n1017, n1018, n1019, n1020, n1021, n1022, n1023, n1024,
         n1025, n1026, n1027, n1028, n1029, n1030, n1031, n1032, n1033, n1034,
         n1035, n1036, n1037, n1038, n1039, n1040, n1041, n1042, n1043, n1044,
         n1045, n1046, n1047, n1048, n1049, n1050, n1051, n1052, n1053, n1054,
         n1055, n1056, n1057, n1058, n1059, n1060, n1061, n1062, n1063, n1064,
         n1065, n1066, n1067, n1068, n1069, n1070, n1071, n1072, n1073, n1074,
         n1075, n1076, n1077, n1078, n1079, n1080, n1081, n1082, n1083, n1084,
         n1085, n1086, n1087, n1088, n1089, n1090, n1091, n1092, n1093, n1094,
         n1095, n1096, n1097, n1098, n1099, n1100, n1101, n1102, n1103, n1104,
         n1105, n1106, n1107, n1108, n1109, n1110, n1111, n1112, n1113, n1114,
         n1115, n1116, n1117, n1118, n1119, n1120, n1121, n1122, n1123, n1124,
         n1125, n1126, n1127, n1128, n1129, n1130, n1131, n1132, n1133, n1134,
         n1135, n1136, n1137, n1138, n1139, n1140, n1141, n1142, n1143, n1144,
         n1145, n1146, n1147, n1148, n1149, n1150, n1151, n1152, n1153, n1154,
         n1155, n1156, n1157, n1158, n1159, n1160, n1161, n1162, n1163, n1164,
         n1165, n1166, n1167, n1168, n1169, n1170, n1171, n1172, n1173, n1174,
         n1175, n1176, n1177, n1178, n1179, n1180, n1181, n1182, n1183, n1184,
         n1185, n1186, n1187, n1188, n1189, n1190, n1191, n1192, n1193, n1194,
         n1195, n1196, n1197, n1198, n1199;
  wire   [5:0] reg_addr;
  wire   [7:0] reg_wr_data;
  wire   [7:0] reg_rd_data;
  wire   [3:0] \u_spi_reg_interface/state ;
  wire   [7:0] \u_spi_reg_interface/spi_tx_byte ;
  wire   [7:0] \u_spi_reg_interface/spi_rx_byte ;
  wire   [2:0] \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count ;
  wire   [2:0] \u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count ;
  wire   [6:0] \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte ;
  wire   [1:0] \u_spi_reg_interface/u_spi_slave/r_SPI_CS ;
  wire   [1:0] \u_spi_reg_interface/u_spi_slave/r_SPI_CLK ;

  SNPS_CLOCK_GATE_HIGH_spi_reg_interface_3 \u_spi_reg_interface/clk_gate_spi_tx_byte_reg  ( 
        .CLK(clk), .EN(\u_spi_reg_interface/N52 ), .ENCLK(
        \u_spi_reg_interface/net810 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_spi_reg_interface_2 \u_spi_reg_interface/clk_gate_reg_reg_addr_reg  ( 
        .CLK(clk), .EN(\u_spi_reg_interface/N45 ), .ENCLK(
        \u_spi_reg_interface/net805 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_spi_reg_interface_1 \u_spi_reg_interface/clk_gate_reg_wr_data_reg  ( 
        .CLK(clk), .EN(\u_spi_reg_interface/N51 ), .ENCLK(
        \u_spi_reg_interface/net800 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_25 \u_inst_reg/clk_gate_r_rd_data_reg  ( 
        .CLK(clk), .EN(reg_rd_en), .ENCLK(\u_inst_reg/net777 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_24 \u_inst_reg/clk_gate_reg_array_reg[0]  ( 
        .CLK(clk), .EN(\u_inst_reg/N132 ), .ENCLK(\u_inst_reg/net772 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_23 \u_inst_reg/clk_gate_reg_array_reg[1]  ( 
        .CLK(clk), .EN(\u_inst_reg/N133 ), .ENCLK(\u_inst_reg/net767 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_22 \u_inst_reg/clk_gate_reg_array_reg[2]  ( 
        .CLK(clk), .EN(\u_inst_reg/N134 ), .ENCLK(\u_inst_reg/net762 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_21 \u_inst_reg/clk_gate_reg_array_reg[3]  ( 
        .CLK(clk), .EN(\u_inst_reg/N135 ), .ENCLK(\u_inst_reg/net757 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_20 \u_inst_reg/clk_gate_reg_array_reg[4]  ( 
        .CLK(clk), .EN(\u_inst_reg/N136 ), .ENCLK(\u_inst_reg/net752 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_19 \u_inst_reg/clk_gate_reg_array_reg[5]  ( 
        .CLK(clk), .EN(\u_inst_reg/N137 ), .ENCLK(\u_inst_reg/net747 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_18 \u_inst_reg/clk_gate_reg_array_reg[6]  ( 
        .CLK(clk), .EN(\u_inst_reg/N138 ), .ENCLK(\u_inst_reg/net742 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_17 \u_inst_reg/clk_gate_reg_array_reg[7]  ( 
        .CLK(clk), .EN(\u_inst_reg/N139 ), .ENCLK(\u_inst_reg/net737 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_16 \u_inst_reg/clk_gate_reg_array_reg[8]  ( 
        .CLK(clk), .EN(\u_inst_reg/N140 ), .ENCLK(\u_inst_reg/net732 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_15 \u_inst_reg/clk_gate_reg_array_reg[9]  ( 
        .CLK(clk), .EN(\u_inst_reg/N141 ), .ENCLK(\u_inst_reg/net727 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_14 \u_inst_reg/clk_gate_reg_array_reg[10]  ( 
        .CLK(clk), .EN(\u_inst_reg/N142 ), .ENCLK(\u_inst_reg/net722 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_13 \u_inst_reg/clk_gate_reg_array_reg[11]  ( 
        .CLK(clk), .EN(\u_inst_reg/N143 ), .ENCLK(\u_inst_reg/net717 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_12 \u_inst_reg/clk_gate_reg_array_reg[12]  ( 
        .CLK(clk), .EN(\u_inst_reg/N144 ), .ENCLK(\u_inst_reg/net712 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_11 \u_inst_reg/clk_gate_reg_array_reg[13]  ( 
        .CLK(clk), .EN(\u_inst_reg/N145 ), .ENCLK(\u_inst_reg/net707 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_10 \u_inst_reg/clk_gate_reg_array_reg[14]  ( 
        .CLK(clk), .EN(\u_inst_reg/N146 ), .ENCLK(\u_inst_reg/net702 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_9 \u_inst_reg/clk_gate_reg_array_reg[15]  ( 
        .CLK(clk), .EN(\u_inst_reg/N147 ), .ENCLK(\u_inst_reg/net697 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_8 \u_inst_reg/clk_gate_reg_array_reg[16]  ( 
        .CLK(clk), .EN(\u_inst_reg/N148 ), .ENCLK(\u_inst_reg/net692 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_7 \u_inst_reg/clk_gate_reg_array_reg[17]  ( 
        .CLK(clk), .EN(\u_inst_reg/N149 ), .ENCLK(\u_inst_reg/net687 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_6 \u_inst_reg/clk_gate_reg_array_reg[18]  ( 
        .CLK(clk), .EN(\u_inst_reg/N150 ), .ENCLK(\u_inst_reg/net682 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_5 \u_inst_reg/clk_gate_reg_array_reg[19]  ( 
        .CLK(clk), .EN(\u_inst_reg/N151 ), .ENCLK(\u_inst_reg/net677 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_4 \u_inst_reg/clk_gate_reg_array_reg[20]  ( 
        .CLK(clk), .EN(\u_inst_reg/N152 ), .ENCLK(\u_inst_reg/net672 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_3 \u_inst_reg/clk_gate_reg_array_reg[21]  ( 
        .CLK(clk), .EN(\u_inst_reg/N153 ), .ENCLK(\u_inst_reg/net667 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_2 \u_inst_reg/clk_gate_reg_array_reg[22]  ( 
        .CLK(clk), .EN(\u_inst_reg/N154 ), .ENCLK(\u_inst_reg/net662 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_1 \u_inst_reg/clk_gate_reg_array_reg[23]  ( 
        .CLK(clk), .EN(\u_inst_reg/N155 ), .ENCLK(\u_inst_reg/net657 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_inst_reg_REG_WIDTH8_REG_DEEPTH_O24_REG_DEEPTH_I40_0 \u_inst_reg/clk_gate_reg_array_reg[63]  ( 
        .CLK(clk), .EN(n1182), .ENCLK(\u_inst_reg/net651 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_spi_slave_2 \u_spi_reg_interface/u_spi_slave/clk_gate_r_TX_Bit_Count_reg  ( 
        .CLK(clk), .EN(n597), .ENCLK(\u_spi_reg_interface/u_spi_slave/net838 ), 
        .TE(\u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_spi_slave_1 \u_spi_reg_interface/u_spi_slave/clk_gate_r_Temp_RX_Byte_reg  ( 
        .CLK(clk), .EN(n598), .ENCLK(\u_spi_reg_interface/u_spi_slave/net833 ), 
        .TE(\u_spi_reg_interface/u_spi_slave/net828 ) );
  SNPS_CLOCK_GATE_HIGH_spi_slave_0 \u_spi_reg_interface/u_spi_slave/clk_gate_r_RX_Byte_reg  ( 
        .CLK(clk), .EN(\u_spi_reg_interface/u_spi_slave/N58 ), .ENCLK(
        \u_spi_reg_interface/u_spi_slave/net827 ), .TE(
        \u_spi_reg_interface/u_spi_slave/net828 ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[24][0]  ( .D(status_i[0]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[24][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[24][1]  ( .D(status_i[1]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[24][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[24][2]  ( .D(status_i[2]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[24][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[24][3]  ( .D(status_i[3]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[24][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[24][4]  ( .D(status_i[4]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[24][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[24][5]  ( .D(status_i[5]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[24][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[24][6]  ( .D(status_i[6]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[24][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[24][7]  ( .D(status_i[7]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[24][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[25][0]  ( .D(status_i[8]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[25][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[25][1]  ( .D(status_i[9]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[25][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[25][2]  ( .D(status_i[10]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[25][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[25][3]  ( .D(status_i[11]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[25][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[25][4]  ( .D(status_i[12]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[25][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[25][5]  ( .D(status_i[13]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[25][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[25][6]  ( .D(status_i[14]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[25][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[25][7]  ( .D(status_i[15]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[25][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[26][0]  ( .D(status_i[16]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[26][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[26][1]  ( .D(status_i[17]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[26][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[26][2]  ( .D(status_i[18]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[26][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[26][3]  ( .D(status_i[19]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[26][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[26][4]  ( .D(status_i[20]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[26][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[26][5]  ( .D(status_i[21]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[26][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[26][6]  ( .D(status_i[22]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[26][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[26][7]  ( .D(status_i[23]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[26][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[27][0]  ( .D(status_i[24]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[27][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[27][1]  ( .D(status_i[25]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[27][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[27][2]  ( .D(status_i[26]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[27][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[27][3]  ( .D(status_i[27]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[27][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[27][4]  ( .D(status_i[28]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[27][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[27][5]  ( .D(status_i[29]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[27][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[27][6]  ( .D(status_i[30]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[27][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[27][7]  ( .D(status_i[31]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[27][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[28][0]  ( .D(status_i[32]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[28][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[28][1]  ( .D(status_i[33]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[28][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[28][2]  ( .D(status_i[34]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[28][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[28][3]  ( .D(status_i[35]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[28][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[28][4]  ( .D(status_i[36]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[28][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[28][5]  ( .D(status_i[37]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[28][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[28][6]  ( .D(status_i[38]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[28][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[28][7]  ( .D(status_i[39]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[28][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[29][0]  ( .D(status_i[40]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[29][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[29][1]  ( .D(status_i[41]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[29][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[29][2]  ( .D(status_i[42]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[29][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[29][3]  ( .D(status_i[43]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[29][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[29][4]  ( .D(status_i[44]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[29][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[29][5]  ( .D(status_i[45]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[29][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[29][6]  ( .D(status_i[46]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[29][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[29][7]  ( .D(status_i[47]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[29][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[30][0]  ( .D(status_i[48]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[30][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[30][1]  ( .D(status_i[49]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[30][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[30][2]  ( .D(status_i[50]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[30][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[30][3]  ( .D(status_i[51]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[30][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[30][4]  ( .D(status_i[52]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[30][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[30][5]  ( .D(status_i[53]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[30][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[30][6]  ( .D(status_i[54]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[30][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[30][7]  ( .D(status_i[55]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[30][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[31][0]  ( .D(status_i[56]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[31][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[31][1]  ( .D(status_i[57]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[31][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[31][2]  ( .D(status_i[58]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[31][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[31][3]  ( .D(status_i[59]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[31][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[31][4]  ( .D(status_i[60]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[31][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[31][5]  ( .D(status_i[61]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[31][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[31][6]  ( .D(status_i[62]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[31][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[31][7]  ( .D(status_i[63]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[31][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[32][0]  ( .D(status_i[64]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[32][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[32][1]  ( .D(status_i[65]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[32][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[32][2]  ( .D(status_i[66]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[32][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[32][3]  ( .D(status_i[67]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[32][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[32][4]  ( .D(status_i[68]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[32][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[32][5]  ( .D(status_i[69]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[32][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[32][6]  ( .D(status_i[70]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[32][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[32][7]  ( .D(status_i[71]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[32][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[33][0]  ( .D(status_i[72]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[33][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[33][1]  ( .D(status_i[73]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[33][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[33][2]  ( .D(status_i[74]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[33][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[33][3]  ( .D(status_i[75]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[33][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[33][4]  ( .D(status_i[76]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[33][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[33][5]  ( .D(status_i[77]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[33][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[33][6]  ( .D(status_i[78]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[33][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[33][7]  ( .D(status_i[79]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[33][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[34][0]  ( .D(status_i[80]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[34][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[34][1]  ( .D(status_i[81]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[34][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[34][2]  ( .D(status_i[82]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[34][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[34][3]  ( .D(status_i[83]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[34][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[34][4]  ( .D(status_i[84]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[34][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[34][5]  ( .D(status_i[85]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[34][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[34][6]  ( .D(status_i[86]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[34][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[34][7]  ( .D(status_i[87]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[34][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[35][0]  ( .D(status_i[88]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[35][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[35][1]  ( .D(status_i[89]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[35][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[35][2]  ( .D(status_i[90]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[35][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[35][3]  ( .D(status_i[91]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[35][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[35][4]  ( .D(status_i[92]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[35][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[35][5]  ( .D(status_i[93]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[35][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[35][6]  ( .D(status_i[94]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[35][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[35][7]  ( .D(status_i[95]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[35][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[36][0]  ( .D(status_i[96]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[36][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[36][1]  ( .D(status_i[97]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[36][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[36][2]  ( .D(status_i[98]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[36][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[36][3]  ( .D(status_i[99]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[36][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[36][4]  ( .D(status_i[100]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[36][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[36][5]  ( .D(status_i[101]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[36][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[36][6]  ( .D(status_i[102]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[36][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[36][7]  ( .D(status_i[103]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[36][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[37][0]  ( .D(status_i[104]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[37][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[37][1]  ( .D(status_i[105]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[37][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[37][2]  ( .D(status_i[106]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[37][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[37][3]  ( .D(status_i[107]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[37][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[37][4]  ( .D(status_i[108]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[37][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[37][5]  ( .D(status_i[109]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[37][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[37][6]  ( .D(status_i[110]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[37][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[37][7]  ( .D(status_i[111]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[37][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[38][0]  ( .D(status_i[112]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[38][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[38][1]  ( .D(status_i[113]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[38][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[38][2]  ( .D(status_i[114]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[38][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[38][3]  ( .D(status_i[115]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[38][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[38][4]  ( .D(status_i[116]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[38][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[38][5]  ( .D(status_i[117]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[38][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[38][6]  ( .D(status_i[118]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[38][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[38][7]  ( .D(status_i[119]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[38][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[39][0]  ( .D(status_i[120]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[39][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[39][1]  ( .D(status_i[121]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[39][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[39][2]  ( .D(status_i[122]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[39][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[39][3]  ( .D(status_i[123]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[39][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[39][4]  ( .D(status_i[124]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[39][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[39][5]  ( .D(status_i[125]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[39][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[39][6]  ( .D(status_i[126]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[39][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[39][7]  ( .D(status_i[127]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[39][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[40][0]  ( .D(status_i[128]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[40][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[40][1]  ( .D(status_i[129]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[40][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[40][2]  ( .D(status_i[130]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[40][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[40][3]  ( .D(status_i[131]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[40][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[40][4]  ( .D(status_i[132]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[40][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[40][5]  ( .D(status_i[133]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[40][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[40][6]  ( .D(status_i[134]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[40][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[40][7]  ( .D(status_i[135]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[40][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[41][0]  ( .D(status_i[136]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[41][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[41][1]  ( .D(status_i[137]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[41][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[41][2]  ( .D(status_i[138]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[41][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[41][3]  ( .D(status_i[139]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[41][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[41][4]  ( .D(status_i[140]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[41][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[41][5]  ( .D(status_i[141]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[41][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[41][6]  ( .D(status_i[142]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[41][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[41][7]  ( .D(status_i[143]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[41][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[42][0]  ( .D(status_i[144]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[42][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[42][1]  ( .D(status_i[145]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[42][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[42][2]  ( .D(status_i[146]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[42][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[42][3]  ( .D(status_i[147]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[42][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[42][4]  ( .D(status_i[148]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[42][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[42][5]  ( .D(status_i[149]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[42][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[42][6]  ( .D(status_i[150]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[42][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[42][7]  ( .D(status_i[151]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[42][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[43][0]  ( .D(status_i[152]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[43][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[43][1]  ( .D(status_i[153]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[43][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[43][2]  ( .D(status_i[154]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[43][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[43][3]  ( .D(status_i[155]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[43][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[43][4]  ( .D(status_i[156]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[43][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[43][5]  ( .D(status_i[157]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[43][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[43][6]  ( .D(status_i[158]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[43][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[43][7]  ( .D(status_i[159]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[43][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[44][0]  ( .D(status_i[160]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[44][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[44][1]  ( .D(status_i[161]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[44][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[44][2]  ( .D(status_i[162]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[44][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[44][3]  ( .D(status_i[163]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[44][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[44][4]  ( .D(status_i[164]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[44][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[44][5]  ( .D(status_i[165]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[44][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[44][6]  ( .D(status_i[166]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[44][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[44][7]  ( .D(status_i[167]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[44][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[45][0]  ( .D(status_i[168]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[45][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[45][1]  ( .D(status_i[169]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[45][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[45][2]  ( .D(status_i[170]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[45][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[45][3]  ( .D(status_i[171]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[45][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[45][4]  ( .D(status_i[172]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[45][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[45][5]  ( .D(status_i[173]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[45][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[45][6]  ( .D(status_i[174]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[45][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[45][7]  ( .D(status_i[175]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[45][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[46][0]  ( .D(status_i[176]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[46][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[46][1]  ( .D(status_i[177]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[46][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[46][2]  ( .D(status_i[178]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[46][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[46][3]  ( .D(status_i[179]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[46][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[46][4]  ( .D(status_i[180]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[46][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[46][5]  ( .D(status_i[181]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[46][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[46][6]  ( .D(status_i[182]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[46][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[46][7]  ( .D(status_i[183]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[46][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[47][0]  ( .D(status_i[184]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[47][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[47][1]  ( .D(status_i[185]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[47][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[47][2]  ( .D(status_i[186]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[47][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[47][3]  ( .D(status_i[187]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[47][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[47][4]  ( .D(status_i[188]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[47][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[47][5]  ( .D(status_i[189]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[47][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[47][6]  ( .D(status_i[190]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[47][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[47][7]  ( .D(status_i[191]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[47][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[48][0]  ( .D(status_i[192]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[48][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[48][1]  ( .D(status_i[193]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[48][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[48][2]  ( .D(status_i[194]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[48][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[48][3]  ( .D(status_i[195]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[48][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[48][4]  ( .D(status_i[196]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[48][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[48][5]  ( .D(status_i[197]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[48][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[48][6]  ( .D(status_i[198]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[48][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[48][7]  ( .D(status_i[199]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[48][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[49][0]  ( .D(status_i[200]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[49][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[49][1]  ( .D(status_i[201]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[49][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[49][2]  ( .D(status_i[202]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[49][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[49][3]  ( .D(status_i[203]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[49][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[49][4]  ( .D(status_i[204]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[49][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[49][5]  ( .D(status_i[205]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[49][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[49][6]  ( .D(status_i[206]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[49][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[49][7]  ( .D(status_i[207]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[49][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[50][0]  ( .D(status_i[208]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[50][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[50][1]  ( .D(status_i[209]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[50][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[50][2]  ( .D(status_i[210]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[50][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[50][3]  ( .D(status_i[211]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[50][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[50][4]  ( .D(status_i[212]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[50][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[50][5]  ( .D(status_i[213]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[50][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[50][6]  ( .D(status_i[214]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[50][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[50][7]  ( .D(status_i[215]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[50][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[51][0]  ( .D(status_i[216]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[51][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[51][1]  ( .D(status_i[217]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[51][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[51][2]  ( .D(status_i[218]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[51][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[51][3]  ( .D(status_i[219]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[51][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[51][4]  ( .D(status_i[220]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[51][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[51][5]  ( .D(status_i[221]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[51][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[51][6]  ( .D(status_i[222]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[51][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[51][7]  ( .D(status_i[223]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[51][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[52][0]  ( .D(status_i[224]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[52][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[52][1]  ( .D(status_i[225]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[52][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[52][2]  ( .D(status_i[226]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[52][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[52][3]  ( .D(status_i[227]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[52][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[52][4]  ( .D(status_i[228]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[52][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[52][5]  ( .D(status_i[229]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[52][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[52][6]  ( .D(status_i[230]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[52][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[52][7]  ( .D(status_i[231]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[52][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[53][0]  ( .D(status_i[232]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[53][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[53][1]  ( .D(status_i[233]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[53][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[53][2]  ( .D(status_i[234]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[53][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[53][3]  ( .D(status_i[235]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[53][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[53][4]  ( .D(status_i[236]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[53][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[53][5]  ( .D(status_i[237]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[53][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[53][6]  ( .D(status_i[238]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[53][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[53][7]  ( .D(status_i[239]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[53][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[54][0]  ( .D(status_i[240]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[54][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[54][1]  ( .D(status_i[241]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[54][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[54][2]  ( .D(status_i[242]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[54][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[54][3]  ( .D(status_i[243]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[54][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[54][4]  ( .D(status_i[244]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[54][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[54][5]  ( .D(status_i[245]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[54][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[54][6]  ( .D(status_i[246]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[54][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[54][7]  ( .D(status_i[247]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[54][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[55][0]  ( .D(status_i[248]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[55][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[55][1]  ( .D(status_i[249]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[55][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[55][2]  ( .D(status_i[250]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[55][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[55][3]  ( .D(status_i[251]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[55][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[55][4]  ( .D(status_i[252]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[55][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[55][5]  ( .D(status_i[253]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[55][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[55][6]  ( .D(status_i[254]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[55][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[55][7]  ( .D(status_i[255]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[55][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[56][0]  ( .D(status_i[256]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[56][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[56][1]  ( .D(status_i[257]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[56][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[56][2]  ( .D(status_i[258]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[56][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[56][3]  ( .D(status_i[259]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[56][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[56][4]  ( .D(status_i[260]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[56][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[56][5]  ( .D(status_i[261]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[56][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[56][6]  ( .D(status_i[262]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[56][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[56][7]  ( .D(status_i[263]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[56][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[57][0]  ( .D(status_i[264]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[57][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[57][1]  ( .D(status_i[265]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[57][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[57][2]  ( .D(status_i[266]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[57][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[57][3]  ( .D(status_i[267]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[57][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[57][4]  ( .D(status_i[268]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[57][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[57][5]  ( .D(status_i[269]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[57][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[57][6]  ( .D(status_i[270]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[57][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[57][7]  ( .D(status_i[271]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[57][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[58][0]  ( .D(status_i[272]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[58][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[58][1]  ( .D(status_i[273]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[58][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[58][2]  ( .D(status_i[274]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[58][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[58][3]  ( .D(status_i[275]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[58][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[58][4]  ( .D(status_i[276]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[58][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[58][5]  ( .D(status_i[277]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[58][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[58][6]  ( .D(status_i[278]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[58][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[58][7]  ( .D(status_i[279]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[58][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[59][0]  ( .D(status_i[280]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[59][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[59][1]  ( .D(status_i[281]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[59][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[59][2]  ( .D(status_i[282]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[59][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[59][3]  ( .D(status_i[283]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[59][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[59][4]  ( .D(status_i[284]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[59][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[59][5]  ( .D(status_i[285]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[59][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[59][6]  ( .D(status_i[286]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[59][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[59][7]  ( .D(status_i[287]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[59][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[60][0]  ( .D(status_i[288]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[60][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[60][1]  ( .D(status_i[289]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[60][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[60][2]  ( .D(status_i[290]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[60][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[60][3]  ( .D(status_i[291]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[60][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[60][4]  ( .D(status_i[292]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[60][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[60][5]  ( .D(status_i[293]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[60][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[60][6]  ( .D(status_i[294]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[60][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[60][7]  ( .D(status_i[295]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[60][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[61][0]  ( .D(status_i[296]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[61][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[61][1]  ( .D(status_i[297]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[61][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[61][2]  ( .D(status_i[298]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[61][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[61][3]  ( .D(status_i[299]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[61][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[61][4]  ( .D(status_i[300]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[61][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[61][5]  ( .D(status_i[301]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[61][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[61][6]  ( .D(status_i[302]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[61][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[61][7]  ( .D(status_i[303]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[61][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[62][0]  ( .D(status_i[304]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[62][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[62][1]  ( .D(status_i[305]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[62][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[62][2]  ( .D(status_i[306]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[62][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[62][3]  ( .D(status_i[307]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[62][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[62][4]  ( .D(status_i[308]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[62][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[62][5]  ( .D(status_i[309]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[62][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[62][6]  ( .D(status_i[310]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[62][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[62][7]  ( .D(status_i[311]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[62][7] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[63][0]  ( .D(status_i[312]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[63][0] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[63][1]  ( .D(status_i[313]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[63][1] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[63][2]  ( .D(status_i[314]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[63][2] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[63][3]  ( .D(status_i[315]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[63][3] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[63][4]  ( .D(status_i[316]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[63][4] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[63][5]  ( .D(status_i[317]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[63][5] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[63][6]  ( .D(status_i[318]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[63][6] ) );
  dffpqx05_u \u_inst_reg/reg_array_reg[63][7]  ( .D(status_i[319]), .CK(
        \u_inst_reg/net651 ), .Q(\u_inst_reg/reg_array[63][7] ) );
  dffpqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Byte_reg[7]  ( .D(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [6]), .CK(
        \u_spi_reg_interface/u_spi_slave/net827 ), .Q(
        \u_spi_reg_interface/spi_rx_byte [7]) );
  dffpqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Byte_reg[6]  ( .D(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [5]), .CK(
        \u_spi_reg_interface/u_spi_slave/net827 ), .Q(
        \u_spi_reg_interface/spi_rx_byte [6]) );
  dffpqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Byte_reg[5]  ( .D(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [4]), .CK(
        \u_spi_reg_interface/u_spi_slave/net827 ), .Q(
        \u_spi_reg_interface/spi_rx_byte [5]) );
  dffpqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Byte_reg[4]  ( .D(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [3]), .CK(
        \u_spi_reg_interface/u_spi_slave/net827 ), .Q(
        \u_spi_reg_interface/spi_rx_byte [4]) );
  dffpqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Byte_reg[3]  ( .D(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [2]), .CK(
        \u_spi_reg_interface/u_spi_slave/net827 ), .Q(
        \u_spi_reg_interface/spi_rx_byte [3]) );
  dffpqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Byte_reg[2]  ( .D(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [1]), .CK(
        \u_spi_reg_interface/u_spi_slave/net827 ), .Q(
        \u_spi_reg_interface/spi_rx_byte [2]) );
  dffpqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Byte_reg[1]  ( .D(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [0]), .CK(
        \u_spi_reg_interface/u_spi_slave/net827 ), .Q(
        \u_spi_reg_interface/spi_rx_byte [1]) );
  dffpqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Byte_reg[0]  ( .D(SPI_MOSI), 
        .CK(\u_spi_reg_interface/u_spi_slave/net827 ), .Q(
        \u_spi_reg_interface/spi_rx_byte [0]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_SPI_CS_reg[1]  ( .D(SPI_SS), 
        .CK(clk), .RN(n1180), .Q(\u_spi_reg_interface/u_spi_slave/r_SPI_CS [1]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_SPI_CS_reg[0]  ( .D(
        \u_spi_reg_interface/u_spi_slave/r_SPI_CS [1]), .CK(clk), .RN(n1181), 
        .Q(\u_spi_reg_interface/u_spi_slave/r_SPI_CS [0]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_SPI_CLK_reg[1]  ( .D(SPI_CLK), 
        .CK(clk), .RN(n1182), .Q(
        \u_spi_reg_interface/u_spi_slave/r_SPI_CLK [1]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_SPI_CLK_reg[0]  ( .D(
        \u_spi_reg_interface/u_spi_slave/r_SPI_CLK [1]), .CK(clk), .RN(n1181), 
        .Q(\u_spi_reg_interface/u_spi_slave/r_SPI_CLK [0]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte_reg[0]  ( .D(
        n1199), .CK(\u_spi_reg_interface/u_spi_slave/net833 ), .RN(n1182), .Q(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [0]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte_reg[1]  ( .D(
        n1198), .CK(\u_spi_reg_interface/u_spi_slave/net833 ), .RN(n1180), .Q(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [1]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte_reg[2]  ( .D(
        n1197), .CK(\u_spi_reg_interface/u_spi_slave/net833 ), .RN(n1180), .Q(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [2]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte_reg[3]  ( .D(
        n1196), .CK(\u_spi_reg_interface/u_spi_slave/net833 ), .RN(n1181), .Q(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [3]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte_reg[4]  ( .D(
        n1195), .CK(\u_spi_reg_interface/u_spi_slave/net833 ), .RN(n1182), .Q(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [4]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte_reg[5]  ( .D(
        n1194), .CK(\u_spi_reg_interface/u_spi_slave/net833 ), .RN(n1180), .Q(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [5]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte_reg[6]  ( .D(
        n1193), .CK(\u_spi_reg_interface/u_spi_slave/net833 ), .RN(n1180), .Q(
        \u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [6]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count_reg[0]  ( .D(
        n1192), .CK(\u_spi_reg_interface/u_spi_slave/net833 ), .RN(n1180), .Q(
        \u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count [0]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count_reg[1]  ( .D(
        n1191), .CK(\u_spi_reg_interface/u_spi_slave/net833 ), .RN(n1181), .Q(
        \u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count [1]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count_reg[2]  ( .D(
        n1190), .CK(\u_spi_reg_interface/u_spi_slave/net833 ), .RN(n1182), .Q(
        \u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count [2]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_TX_Busy_reg  ( .D(
        \u_spi_reg_interface/u_spi_slave/N93 ), .CK(clk), .RN(n1182), .Q(
        \u_spi_reg_interface/spi_tx_busy ) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_RX_Done_reg  ( .D(n596), .CK(
        clk), .RN(n1181), .Q(\u_spi_reg_interface/spi_rx_vaild ) );
  dffprqx05_u \u_spi_reg_interface/byte_cnt_reg  ( .D(n594), .CK(clk), .RN(
        n1180), .Q(\u_spi_reg_interface/byte_cnt ) );
  dffprqx05_u \u_spi_reg_interface/reg_reg_addr_reg[5]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [5]), .CK(
        \u_spi_reg_interface/net805 ), .RN(n1181), .Q(reg_addr[5]) );
  dffprqx05_u \u_spi_reg_interface/reg_reg_addr_reg[3]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [3]), .CK(
        \u_spi_reg_interface/net805 ), .RN(n1180), .Q(reg_addr[3]) );
  dffprqx05_u \u_spi_reg_interface/reg_wr_en_reg  ( .D(n595), .CK(clk), .RN(
        n1180), .Q(reg_wr_en) );
  dffprqx05_u \u_spi_reg_interface/reg_rd_en_reg  ( .D(n593), .CK(clk), .RN(
        n1180), .Q(reg_rd_en) );
  dffprqx05_u \u_spi_reg_interface/spi_tx_byte_reg[7]  ( .D(reg_rd_data[7]), 
        .CK(\u_spi_reg_interface/net810 ), .RN(n1181), .Q(
        \u_spi_reg_interface/spi_tx_byte [7]) );
  dffprqx05_u \u_spi_reg_interface/spi_tx_byte_reg[6]  ( .D(reg_rd_data[6]), 
        .CK(\u_spi_reg_interface/net810 ), .RN(n1182), .Q(
        \u_spi_reg_interface/spi_tx_byte [6]) );
  dffprqx05_u \u_spi_reg_interface/spi_tx_byte_reg[5]  ( .D(reg_rd_data[5]), 
        .CK(\u_spi_reg_interface/net810 ), .RN(n1180), .Q(
        \u_spi_reg_interface/spi_tx_byte [5]) );
  dffprqx05_u \u_spi_reg_interface/spi_tx_byte_reg[4]  ( .D(reg_rd_data[4]), 
        .CK(\u_spi_reg_interface/net810 ), .RN(n1181), .Q(
        \u_spi_reg_interface/spi_tx_byte [4]) );
  dffprqx05_u \u_spi_reg_interface/spi_tx_byte_reg[3]  ( .D(reg_rd_data[3]), 
        .CK(\u_spi_reg_interface/net810 ), .RN(n1182), .Q(
        \u_spi_reg_interface/spi_tx_byte [3]) );
  dffprqx05_u \u_inst_reg/r_rd_data_reg[2]  ( .D(\u_inst_reg/N718 ), .CK(
        \u_inst_reg/net777 ), .RN(n1180), .Q(reg_rd_data[2]) );
  dffprqx05_u \u_spi_reg_interface/spi_tx_byte_reg[2]  ( .D(reg_rd_data[2]), 
        .CK(\u_spi_reg_interface/net810 ), .RN(n1181), .Q(
        \u_spi_reg_interface/spi_tx_byte [2]) );
  dffprqx05_u \u_spi_reg_interface/spi_tx_byte_reg[1]  ( .D(reg_rd_data[1]), 
        .CK(\u_spi_reg_interface/net810 ), .RN(n1180), .Q(
        \u_spi_reg_interface/spi_tx_byte [1]) );
  dffprqx05_u \u_inst_reg/r_rd_data_reg[0]  ( .D(\u_inst_reg/N716 ), .CK(
        \u_inst_reg/net777 ), .RN(n1182), .Q(reg_rd_data[0]) );
  dffprqx05_u \u_spi_reg_interface/spi_tx_byte_reg[0]  ( .D(reg_rd_data[0]), 
        .CK(\u_spi_reg_interface/net810 ), .RN(n1180), .Q(
        \u_spi_reg_interface/spi_tx_byte [0]) );
  dffprqx05_u \u_spi_reg_interface/u_spi_slave/r_SPI_MISO_Bit_reg  ( .D(n1189), 
        .CK(\u_spi_reg_interface/u_spi_slave/net838 ), .RN(n1180), .Q(
        \u_spi_reg_interface/u_spi_slave/r_SPI_MISO_Bit ) );
  dffpsqx05_u \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count_reg[0]  ( .D(
        n1188), .CK(\u_spi_reg_interface/u_spi_slave/net838 ), .SN(n1182), .Q(
        \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [0]) );
  dffpsqx05_u \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count_reg[1]  ( .D(
        n1187), .CK(\u_spi_reg_interface/u_spi_slave/net838 ), .SN(n1182), .Q(
        \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [1]) );
  dffpsqx05_u \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count_reg[2]  ( .D(
        n1186), .CK(\u_spi_reg_interface/u_spi_slave/net838 ), .SN(n1182), .Q(
        \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [2]) );
  dffphrqx1_u \u_spi_reg_interface/state_reg[2]  ( .D(n1185), .E(
        \u_spi_reg_interface/N47 ), .CK(clk), .RN(n1182), .Q(
        \u_spi_reg_interface/state [2]) );
  dffprqx05_u \u_spi_reg_interface/reg_wr_data_reg[7]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [7]), .CK(
        \u_spi_reg_interface/net800 ), .RN(n1182), .Q(reg_wr_data[7]) );
  dffprqx05_u \u_spi_reg_interface/reg_wr_data_reg[6]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [6]), .CK(
        \u_spi_reg_interface/net800 ), .RN(n1181), .Q(reg_wr_data[6]) );
  dffprqx05_u \u_spi_reg_interface/reg_wr_data_reg[5]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [5]), .CK(
        \u_spi_reg_interface/net800 ), .RN(n1182), .Q(reg_wr_data[5]) );
  dffprqx05_u \u_spi_reg_interface/reg_wr_data_reg[4]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [4]), .CK(
        \u_spi_reg_interface/net800 ), .RN(n1182), .Q(reg_wr_data[4]) );
  dffprqx05_u \u_spi_reg_interface/reg_wr_data_reg[3]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [3]), .CK(
        \u_spi_reg_interface/net800 ), .RN(n1180), .Q(reg_wr_data[3]) );
  dffprqx05_u \u_spi_reg_interface/reg_wr_data_reg[2]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [2]), .CK(
        \u_spi_reg_interface/net800 ), .RN(n1182), .Q(reg_wr_data[2]) );
  dffprqx05_u \u_spi_reg_interface/reg_wr_data_reg[1]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [1]), .CK(
        \u_spi_reg_interface/net800 ), .RN(n1181), .Q(reg_wr_data[1]) );
  dffprqx05_u \u_spi_reg_interface/reg_wr_data_reg[0]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [0]), .CK(
        \u_spi_reg_interface/net800 ), .RN(rst_n), .Q(reg_wr_data[0]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[18][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net682 ), .RN(n1181), .Q(control_o[144]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[15][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net697 ), .RN(n1181), .Q(control_o[120]) );
  dffprqx05_u \u_spi_reg_interface/reg_reg_addr_reg[1]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [1]), .CK(
        \u_spi_reg_interface/net805 ), .RN(n1180), .Q(reg_addr[1]) );
  dffprqx05_u \u_spi_reg_interface/reg_reg_addr_reg[0]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [0]), .CK(
        \u_spi_reg_interface/net805 ), .RN(n1182), .Q(reg_addr[0]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[9][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net727 ), .RN(n1182), .Q(control_o[72]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[10][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net722 ), .RN(n1182), .Q(control_o[82]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[3][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net757 ), .RN(n1180), .Q(control_o[26]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[2][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net762 ), .RN(n1182), .Q(control_o[18]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[1][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net767 ), .RN(n1180), .Q(control_o[8]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[1][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net767 ), .RN(n1182), .Q(control_o[10]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[7][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net737 ), .RN(n1180), .Q(control_o[56]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[7][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net737 ), .RN(n1180), .Q(control_o[58]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[4][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net752 ), .RN(n1180), .Q(control_o[32]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[4][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net752 ), .RN(n1182), .Q(control_o[34]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[3][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net757 ), .RN(n1180), .Q(control_o[24]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[2][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net762 ), .RN(n1181), .Q(control_o[16]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[9][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net727 ), .RN(n1181), .Q(control_o[74]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[12][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net712 ), .RN(n1182), .Q(control_o[96]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[8][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net732 ), .RN(n1180), .Q(control_o[66]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[11][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net717 ), .RN(n1180), .Q(control_o[88]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[11][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net717 ), .RN(n1181), .Q(control_o[90]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[10][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net722 ), .RN(n1182), .Q(control_o[81]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[10][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net722 ), .RN(n1182), .Q(control_o[83]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[6][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net742 ), .RN(n1180), .Q(control_o[48]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[5][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net747 ), .RN(n1182), .Q(control_o[40]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[0][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net772 ), .RN(n1180), .Q(control_o[0]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[14][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net702 ), .RN(n1182), .Q(control_o[114]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[8][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net732 ), .RN(n1182), .Q(control_o[64]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[10][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net722 ), .RN(rst_n), .Q(control_o[80]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[10][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net722 ), .RN(n1182), .Q(control_o[84]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[10][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net722 ), .RN(n1182), .Q(control_o[85]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[10][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net722 ), .RN(n1182), .Q(control_o[86]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[10][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net722 ), .RN(n1181), .Q(control_o[87]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[13][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net707 ), .RN(n1181), .Q(control_o[104]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[14][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net702 ), .RN(n1181), .Q(control_o[112]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[4][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net752 ), .RN(n1181), .Q(control_o[33]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[4][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net752 ), .RN(n1180), .Q(control_o[35]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[4][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net752 ), .RN(n1180), .Q(control_o[36]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[4][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net752 ), .RN(n1182), .Q(control_o[37]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[4][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net752 ), .RN(n1180), .Q(control_o[38]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[4][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net752 ), .RN(n1180), .Q(control_o[39]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[3][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net757 ), .RN(n1182), .Q(control_o[25]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[3][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net757 ), .RN(n1182), .Q(control_o[27]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[3][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net757 ), .RN(n1181), .Q(control_o[28]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[3][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net757 ), .RN(n1180), .Q(control_o[29]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[3][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net757 ), .RN(n1182), .Q(control_o[30]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[3][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net757 ), .RN(n1181), .Q(control_o[31]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[2][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net762 ), .RN(n1180), .Q(control_o[17]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[2][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net762 ), .RN(n1182), .Q(control_o[19]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[2][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net762 ), .RN(n1181), .Q(control_o[20]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[2][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net762 ), .RN(n1182), .Q(control_o[21]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[2][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net762 ), .RN(n1182), .Q(control_o[22]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[2][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net762 ), .RN(n1182), .Q(control_o[23]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[1][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net767 ), .RN(n1180), .Q(control_o[9]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[1][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net767 ), .RN(n1181), .Q(control_o[11]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[1][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net767 ), .RN(n1180), .Q(control_o[12]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[1][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net767 ), .RN(n1182), .Q(control_o[13]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[1][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net767 ), .RN(n1180), .Q(control_o[14]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[1][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net767 ), .RN(n1182), .Q(control_o[15]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[11][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net717 ), .RN(n1180), .Q(control_o[89]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[11][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net717 ), .RN(n1181), .Q(control_o[91]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[6][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net742 ), .RN(n1180), .Q(control_o[52]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[6][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net742 ), .RN(n1182), .Q(control_o[53]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[6][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net742 ), .RN(n1182), .Q(control_o[54]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[6][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net742 ), .RN(n1181), .Q(control_o[55]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[5][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net747 ), .RN(n1180), .Q(control_o[44]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[5][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net747 ), .RN(n1182), .Q(control_o[45]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[5][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net747 ), .RN(n1180), .Q(control_o[46]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[5][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net747 ), .RN(n1180), .Q(control_o[47]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[0][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net772 ), .RN(n1180), .Q(control_o[4]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[0][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net772 ), .RN(n1180), .Q(control_o[5]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[0][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net772 ), .RN(n1180), .Q(control_o[6]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[0][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net772 ), .RN(n1181), .Q(control_o[7]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[7][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net737 ), .RN(n1180), .Q(control_o[57]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[7][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net737 ), .RN(n1180), .Q(control_o[59]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[7][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net737 ), .RN(n1180), .Q(control_o[60]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[7][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net737 ), .RN(n1180), .Q(control_o[61]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[7][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net737 ), .RN(n1180), .Q(control_o[62]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[7][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net737 ), .RN(n1180), .Q(control_o[63]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[9][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net727 ), .RN(n1181), .Q(control_o[73]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[9][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net727 ), .RN(n1182), .Q(control_o[75]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[9][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net727 ), .RN(n1182), .Q(control_o[76]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[9][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net727 ), .RN(n1182), .Q(control_o[77]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[9][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net727 ), .RN(n1181), .Q(control_o[78]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[9][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net727 ), .RN(n1182), .Q(control_o[79]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[8][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net732 ), .RN(n1182), .Q(control_o[65]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[8][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net732 ), .RN(n1180), .Q(control_o[67]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[8][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net732 ), .RN(n1180), .Q(control_o[68]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[8][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net732 ), .RN(n1180), .Q(control_o[69]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[8][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net732 ), .RN(n1181), .Q(control_o[70]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[8][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net732 ), .RN(n1180), .Q(control_o[71]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[11][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net717 ), .RN(n1180), .Q(control_o[92]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[11][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net717 ), .RN(n1181), .Q(control_o[93]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[11][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net717 ), .RN(n1182), .Q(control_o[94]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[11][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net717 ), .RN(n1180), .Q(control_o[95]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[13][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net707 ), .RN(n1180), .Q(control_o[111]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[12][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net712 ), .RN(n1180), .Q(control_o[100]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[12][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net712 ), .RN(n1181), .Q(control_o[101]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[12][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net712 ), .RN(n1182), .Q(control_o[102]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[12][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net712 ), .RN(n1180), .Q(control_o[103]) );
  dffprqx05_u \u_spi_reg_interface/reg_reg_addr_reg[2]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [2]), .CK(
        \u_spi_reg_interface/net805 ), .RN(rst_n), .Q(reg_addr[2]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[15][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net697 ), .RN(n1181), .Q(control_o[122]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[22][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net662 ), .RN(n1180), .Q(control_o[179]) );
  dffprqx1_u \u_inst_reg/r_rd_data_reg[7]  ( .D(\u_inst_reg/N723 ), .CK(
        \u_inst_reg/net777 ), .RN(n1181), .Q(reg_rd_data[7]) );
  dffphrx1_u \u_spi_reg_interface/state_reg[3]  ( .D(n1184), .E(
        \u_spi_reg_interface/N47 ), .CK(clk), .RN(n1182), .Q(
        \u_spi_reg_interface/state [3]), .QN(n1183) );
  dffprqx1_u \u_inst_reg/reg_array_reg[21][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net667 ), .RN(n1182), .Q(control_o[174]) );
  dffprqx05_u \u_inst_reg/r_rd_data_reg[5]  ( .D(\u_inst_reg/N721 ), .CK(
        \u_inst_reg/net777 ), .RN(rst_n), .Q(reg_rd_data[5]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[20][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net672 ), .RN(n1181), .Q(control_o[167]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[17][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net687 ), .RN(n1181), .Q(control_o[143]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[19][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net677 ), .RN(n1181), .Q(control_o[159]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[16][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net692 ), .RN(n1181), .Q(control_o[130]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[22][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net662 ), .RN(n1181), .Q(control_o[178]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[16][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net692 ), .RN(n1181), .Q(control_o[131]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[22][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net662 ), .RN(n1180), .Q(control_o[180]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[22][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net662 ), .RN(n1181), .Q(control_o[181]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[22][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net662 ), .RN(n1180), .Q(control_o[182]) );
  dffprqx05_u \u_inst_reg/r_rd_data_reg[1]  ( .D(\u_inst_reg/N717 ), .CK(
        \u_inst_reg/net777 ), .RN(n1182), .Q(reg_rd_data[1]) );
  dffprqx05_u \u_inst_reg/r_rd_data_reg[3]  ( .D(\u_inst_reg/N719 ), .CK(
        \u_inst_reg/net777 ), .RN(n1182), .Q(reg_rd_data[3]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[15][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net697 ), .RN(n1181), .Q(control_o[126]) );
  dffprqx05_u \u_inst_reg/r_rd_data_reg[4]  ( .D(\u_inst_reg/N720 ), .CK(
        \u_inst_reg/net777 ), .RN(n1182), .Q(reg_rd_data[4]) );
  dffprqx05_u \u_inst_reg/r_rd_data_reg[6]  ( .D(\u_inst_reg/N722 ), .CK(
        \u_inst_reg/net777 ), .RN(n1181), .Q(reg_rd_data[6]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[19][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net677 ), .RN(n1181), .Q(control_o[155]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[18][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net682 ), .RN(n1181), .Q(control_o[145]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[15][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net697 ), .RN(n1181), .Q(control_o[121]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[18][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net682 ), .RN(n1180), .Q(control_o[147]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[20][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net672 ), .RN(n1180), .Q(control_o[161]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[19][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net677 ), .RN(n1181), .Q(control_o[153]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[15][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net697 ), .RN(n1181), .Q(control_o[123]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[17][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net687 ), .RN(n1180), .Q(control_o[136]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[19][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net677 ), .RN(n1181), .Q(control_o[152]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[17][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net687 ), .RN(n1181), .Q(control_o[142]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[16][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net692 ), .RN(n1181), .Q(control_o[129]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[23][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net657 ), .RN(n1181), .Q(control_o[185]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[20][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net672 ), .RN(n1181), .Q(control_o[164]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[19][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net677 ), .RN(n1182), .Q(control_o[158]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[16][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net692 ), .RN(n1181), .Q(control_o[135]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[22][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net662 ), .RN(rst_n), .Q(control_o[183]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[20][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net672 ), .RN(n1180), .Q(control_o[160]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[16][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net692 ), .RN(n1182), .Q(control_o[128]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[20][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net672 ), .RN(n1180), .Q(control_o[163]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[20][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net672 ), .RN(n1182), .Q(control_o[165]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[22][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net662 ), .RN(n1182), .Q(control_o[176]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[21][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net667 ), .RN(n1181), .Q(control_o[175]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[23][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net657 ), .RN(n1182), .Q(control_o[191]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[18][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net682 ), .RN(n1180), .Q(control_o[149]) );
  dffprqx1_u \u_spi_reg_interface/reg_reg_addr_reg[4]  ( .D(
        \u_spi_reg_interface/spi_rx_byte [4]), .CK(
        \u_spi_reg_interface/net805 ), .RN(n1181), .Q(reg_addr[4]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[21][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net667 ), .RN(n1180), .Q(control_o[169]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[18][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net682 ), .RN(n1181), .Q(control_o[148]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[17][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net687 ), .RN(n1181), .Q(control_o[137]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[17][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net687 ), .RN(n1181), .Q(control_o[140]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[18][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net682 ), .RN(n1180), .Q(control_o[151]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[16][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net692 ), .RN(n1181), .Q(control_o[134]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[23][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net657 ), .RN(n1182), .Q(control_o[188]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[22][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net662 ), .RN(n1180), .Q(control_o[177]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[17][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net687 ), .RN(n1180), .Q(control_o[139]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[20][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net672 ), .RN(n1181), .Q(control_o[166]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[21][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net667 ), .RN(n1181), .Q(control_o[173]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[18][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net682 ), .RN(n1181), .Q(control_o[150]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[21][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net667 ), .RN(n1181), .Q(control_o[171]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[17][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net687 ), .RN(n1181), .Q(control_o[141]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[19][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net677 ), .RN(n1181), .Q(control_o[157]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[20][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net672 ), .RN(n1180), .Q(control_o[162]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[14][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net702 ), .RN(n1181), .Q(control_o[116]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[14][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net702 ), .RN(n1182), .Q(control_o[118]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[23][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net657 ), .RN(n1182), .Q(control_o[189]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[21][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net667 ), .RN(n1182), .Q(control_o[172]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[17][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net687 ), .RN(n1181), .Q(control_o[138]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[18][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net682 ), .RN(n1181), .Q(control_o[146]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[19][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net677 ), .RN(n1181), .Q(control_o[154]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[15][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net697 ), .RN(n1181), .Q(control_o[127]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[21][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net667 ), .RN(n1182), .Q(control_o[168]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[23][0]  ( .D(reg_wr_data[0]), .CK(
        \u_inst_reg/net657 ), .RN(n1182), .Q(control_o[184]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[15][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net697 ), .RN(n1182), .Q(control_o[124]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[15][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net697 ), .RN(n1181), .Q(control_o[125]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[21][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net667 ), .RN(n1181), .Q(control_o[170]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[16][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net692 ), .RN(n1181), .Q(control_o[132]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[16][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net692 ), .RN(n1181), .Q(control_o[133]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[19][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net677 ), .RN(n1180), .Q(control_o[156]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[23][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net657 ), .RN(n1182), .Q(control_o[186]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[12][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net712 ), .RN(n1180), .Q(control_o[98]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[14][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net702 ), .RN(n1182), .Q(control_o[117]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[23][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net657 ), .RN(n1180), .Q(control_o[187]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[12][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net712 ), .RN(n1181), .Q(control_o[97]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[12][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net712 ), .RN(n1182), .Q(control_o[99]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[6][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net742 ), .RN(n1180), .Q(control_o[50]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[5][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net747 ), .RN(n1181), .Q(control_o[41]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[5][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net747 ), .RN(n1182), .Q(control_o[43]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[23][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net657 ), .RN(n1182), .Q(control_o[190]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[5][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net747 ), .RN(n1182), .Q(control_o[42]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[6][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net742 ), .RN(n1180), .Q(control_o[49]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[6][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net742 ), .RN(n1180), .Q(control_o[51]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[0][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net772 ), .RN(n1181), .Q(control_o[1]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[0][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net772 ), .RN(n1180), .Q(control_o[3]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[0][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net772 ), .RN(n1181), .Q(control_o[2]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[14][7]  ( .D(reg_wr_data[7]), .CK(
        \u_inst_reg/net702 ), .RN(n1182), .Q(control_o[119]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[13][6]  ( .D(reg_wr_data[6]), .CK(
        \u_inst_reg/net707 ), .RN(n1182), .Q(control_o[110]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[13][5]  ( .D(reg_wr_data[5]), .CK(
        \u_inst_reg/net707 ), .RN(n1180), .Q(control_o[109]) );
  dffprqx2_u \u_inst_reg/reg_array_reg[13][4]  ( .D(reg_wr_data[4]), .CK(
        \u_inst_reg/net707 ), .RN(n1182), .Q(control_o[108]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[13][2]  ( .D(reg_wr_data[2]), .CK(
        \u_inst_reg/net707 ), .RN(n1182), .Q(control_o[106]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[13][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net707 ), .RN(n1182), .Q(control_o[105]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[13][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net707 ), .RN(n1182), .Q(control_o[107]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[14][1]  ( .D(reg_wr_data[1]), .CK(
        \u_inst_reg/net702 ), .RN(n1181), .Q(control_o[113]) );
  dffprqx1_u \u_inst_reg/reg_array_reg[14][3]  ( .D(reg_wr_data[3]), .CK(
        \u_inst_reg/net702 ), .RN(n1181), .Q(control_o[115]) );
  or3x1_u U655 ( .A(n651), .B(n646), .C(n645), .Q(n650) );
  nor2x1_u U656 ( .A(n692), .B(n666), .Q(n1131) );
  bufx1_u U657 ( .A(n1123), .Q(n599) );
  aoi22x05_u U658 ( .A(n601), .B(control_o[135]), .C(n1086), .D(control_o[143]), .Q(n796) );
  aoi22x05_u U659 ( .A(n1085), .B(control_o[183]), .C(n1084), .D(
        control_o[159]), .Q(n797) );
  oa22x05_u U660 ( .A(n1060), .B(n1059), .C(n1058), .D(n1057), .Q(n1067) );
  aoi22x05_u U661 ( .A(n1083), .B(\u_inst_reg/reg_array[24][7] ), .C(n1082), 
        .D(\u_inst_reg/reg_array[26][7] ), .Q(n798) );
  bufx1_u U662 ( .A(n1087), .Q(n601) );
  nand2x05_u U663 ( .A(n608), .B(reg_addr[4]), .Q(n613) );
  invx05_u U664 ( .A(n989), .Q(n1058) );
  aoi22x1_u U665 ( .A(n990), .B(control_o[126]), .C(n989), .D(control_o[150]), 
        .Q(n891) );
  aoi22x05_u U666 ( .A(n1064), .B(control_o[169]), .C(n1063), .D(
        control_o[161]), .Q(n850) );
  nor2x1_u U667 ( .A(n692), .B(n668), .Q(n1132) );
  invx1_u U668 ( .A(n764), .Q(n1085) );
  invx05_u U669 ( .A(n657), .Q(n608) );
  nand2x1_u U670 ( .A(n605), .B(reg_addr[0]), .Q(n667) );
  invx1_u U671 ( .A(n1166), .Q(n1176) );
  nor2ax1_u U672 ( .AN(\u_spi_reg_interface/u_spi_slave/r_SPI_CS [0]), .B(
        \u_spi_reg_interface/u_spi_slave/r_SPI_CS [1]), .Q(n1166) );
  invx1_u U673 ( .A(reg_wr_en), .Q(n1167) );
  oai21x1_u U674 ( .A(n612), .B(n675), .C(n613), .Q(n1133) );
  invx1_u U675 ( .A(n668), .Q(n678) );
  nor2x1_u U676 ( .A(n623), .B(n668), .Q(n1069) );
  invx1_u U677 ( .A(reg_addr[4]), .Q(n638) );
  aoi22x1_u U678 ( .A(n601), .B(control_o[130]), .C(n1086), .D(control_o[138]), 
        .Q(n634) );
  aoi22x05_u U679 ( .A(n1086), .B(control_o[137]), .C(n601), .D(control_o[129]), .Q(n844) );
  nor2x1_u U680 ( .A(n640), .B(n667), .Q(n1086) );
  bufx1_u U681 ( .A(n1126), .Q(n600) );
  aoi22x05_u U682 ( .A(n990), .B(control_o[125]), .C(n989), .D(control_o[149]), 
        .Q(n941) );
  aoi22x05_u U683 ( .A(n1085), .B(control_o[176]), .C(n1084), .D(
        control_o[152]), .Q(n727) );
  aoi22x1_u U684 ( .A(n1085), .B(control_o[178]), .C(n1084), .D(control_o[154]), .Q(n635) );
  aoi22x1_u U685 ( .A(n1085), .B(control_o[182]), .C(n1084), .D(control_o[158]), .Q(n897) );
  aoi22x1_u U686 ( .A(n1085), .B(control_o[181]), .C(n1084), .D(control_o[157]), .Q(n947) );
  aoi22x05_u U687 ( .A(n990), .B(control_o[124]), .C(n989), .D(control_o[148]), 
        .Q(n993) );
  aoi22x1_u U688 ( .A(n1046), .B(control_o[66]), .C(n1045), .D(control_o[106]), 
        .Q(n682) );
  aoi22x1_u U689 ( .A(n1048), .B(control_o[74]), .C(n1047), .D(control_o[114]), 
        .Q(n681) );
  aoi22x05_u U690 ( .A(n1062), .B(control_o[184]), .C(n1061), .D(
        \u_inst_reg/reg_array[28][0] ), .Q(n733) );
  nand2x2_u U691 ( .A(n621), .B(reg_addr[4]), .Q(n652) );
  aoi22x05_u U692 ( .A(n1064), .B(control_o[168]), .C(n1063), .D(
        control_o[160]), .Q(n732) );
  aoi22x05_u U693 ( .A(n990), .B(control_o[127]), .C(n989), .D(control_o[151]), 
        .Q(n802) );
  aoi22x1_u U694 ( .A(n990), .B(control_o[122]), .C(n989), .D(control_o[146]), 
        .Q(n644) );
  aoi211x1_u U695 ( .A(n877), .B(n1150), .C(n876), .D(n875), .Q(n878) );
  aoi211x1_u U696 ( .A(n927), .B(n1150), .C(n926), .D(n925), .Q(n928) );
  aoi211x1_u U697 ( .A(n1029), .B(n1150), .C(n1028), .D(n1027), .Q(n1030) );
  aoi211x1_u U698 ( .A(n1151), .B(n1150), .C(n1149), .D(n1148), .Q(n1152) );
  nor3x1_u U699 ( .A(n1133), .B(n693), .C(n1125), .Q(n1150) );
  aoi22x05_u U700 ( .A(n1064), .B(control_o[172]), .C(n1063), .D(
        control_o[164]), .Q(n991) );
  aoi22x05_u U701 ( .A(n1048), .B(control_o[76]), .C(n1047), .D(control_o[116]), .Q(n984) );
  aoi22x1_u U702 ( .A(n1046), .B(control_o[67]), .C(n1045), .D(control_o[107]), 
        .Q(n1052) );
  aoi22x1_u U703 ( .A(n1046), .B(control_o[65]), .C(n1045), .D(control_o[105]), 
        .Q(n836) );
  aoi22x1_u U704 ( .A(n1048), .B(control_o[75]), .C(n1047), .D(control_o[115]), 
        .Q(n1051) );
  aoi22x1_u U705 ( .A(n1048), .B(control_o[73]), .C(n1047), .D(control_o[113]), 
        .Q(n835) );
  nor2ax1_u U706 ( .AN(reg_addr[2]), .B(n1056), .Q(n677) );
  nor2ax1_u U707 ( .AN(reg_addr[5]), .B(n631), .Q(n659) );
  aoi22x1_u U708 ( .A(n1064), .B(control_o[174]), .C(n1063), .D(control_o[166]), .Q(n889) );
  aoi22x05_u U709 ( .A(n1085), .B(control_o[177]), .C(n1084), .D(
        control_o[153]), .Q(n846) );
  nor3x1_u U710 ( .A(reg_addr[4]), .B(reg_addr[5]), .C(reg_addr[3]), .Q(n665)
         );
  nand2x1_u U711 ( .A(n639), .B(reg_addr[4]), .Q(n686) );
  aoi22x1_u U712 ( .A(n1085), .B(control_o[180]), .C(n1084), .D(control_o[156]), .Q(n999) );
  aoi22x1_u U713 ( .A(n1085), .B(control_o[179]), .C(n1084), .D(control_o[155]), .Q(n1089) );
  nor2x1_u U714 ( .A(n640), .B(n666), .Q(n1084) );
  aoi22x05_u U715 ( .A(n1062), .B(control_o[185]), .C(n1061), .D(
        \u_inst_reg/reg_array[28][1] ), .Q(n851) );
  nor2ax1_u U716 ( .AN(n675), .B(n630), .Q(n1083) );
  nand2x1_u U717 ( .A(n659), .B(reg_addr[4]), .Q(n692) );
  nor2x2_u U718 ( .A(n640), .B(n668), .Q(n989) );
  invx05_u U719 ( .A(control_o[145]), .Q(n848) );
  nand2x05_u U720 ( .A(n1074), .B(\u_inst_reg/reg_array[31][4] ), .Q(n994) );
  nor2x05_u U721 ( .A(n622), .B(n666), .Q(n1072) );
  nor2x05_u U722 ( .A(n668), .B(n622), .Q(n1073) );
  nor2x05_u U723 ( .A(n628), .B(n664), .Q(n620) );
  aoi22x05_u U724 ( .A(n1100), .B(\u_inst_reg/reg_array[49][0] ), .C(n1099), 
        .D(\u_inst_reg/reg_array[48][0] ), .Q(n717) );
  and2x05_u U725 ( .A(n659), .B(n675), .Q(n1115) );
  and2x05_u U726 ( .A(n659), .B(n674), .Q(n1116) );
  and2x05_u U727 ( .A(n659), .B(n676), .Q(n1113) );
  and2x05_u U728 ( .A(n659), .B(n678), .Q(n1114) );
  nor2x05_u U729 ( .A(n658), .B(n666), .Q(n1111) );
  nor2x05_u U730 ( .A(n657), .B(n668), .Q(n1112) );
  and4x05_u U731 ( .A(n656), .B(n655), .C(n654), .D(n653), .Q(n663) );
  aoi22x05_u U732 ( .A(n1104), .B(\u_inst_reg/reg_array[42][2] ), .C(n1103), 
        .D(\u_inst_reg/reg_array[47][2] ), .Q(n654) );
  aoi22x05_u U733 ( .A(n1102), .B(\u_inst_reg/reg_array[40][2] ), .C(n1101), 
        .D(\u_inst_reg/reg_array[41][2] ), .Q(n655) );
  nand2x1_u U734 ( .A(reg_addr[1]), .B(n606), .Q(n668) );
  nand2x1_u U735 ( .A(reg_addr[0]), .B(reg_addr[1]), .Q(n666) );
  nor2x05_u U736 ( .A(n612), .B(n666), .Q(n1137) );
  nor2x05_u U737 ( .A(n612), .B(n667), .Q(n1138) );
  nor2x05_u U738 ( .A(n612), .B(n668), .Q(n1140) );
  nor2x05_u U739 ( .A(n613), .B(n667), .Q(n1139) );
  nor2x05_u U740 ( .A(n613), .B(n668), .Q(n1141) );
  nor2x05_u U741 ( .A(n613), .B(n757), .Q(n1142) );
  nand2x05_u U742 ( .A(n1143), .B(\u_inst_reg/reg_array[63][2] ), .Q(n614) );
  invx05_u U743 ( .A(reg_addr[3]), .Q(n628) );
  aoi22x05_u U744 ( .A(n1100), .B(\u_inst_reg/reg_array[49][2] ), .C(n1099), 
        .D(\u_inst_reg/reg_array[48][2] ), .Q(n656) );
  nand4x05_u U745 ( .A(n945), .B(n944), .C(n943), .D(n942), .Q(n951) );
  nand4x05_u U746 ( .A(n997), .B(n996), .C(n995), .D(n994), .Q(n1003) );
  invx05_u U747 ( .A(n768), .Q(n1049) );
  and2x05_u U748 ( .A(n669), .B(n675), .Q(n1033) );
  invx05_u U749 ( .A(n756), .Q(n1047) );
  invx05_u U750 ( .A(n759), .Q(n1043) );
  invx05_u U751 ( .A(n766), .Q(n1046) );
  invx05_u U752 ( .A(n769), .Q(n1044) );
  invx05_u U753 ( .A(n767), .Q(n1048) );
  nor2x05_u U754 ( .A(n657), .B(n667), .Q(n1105) );
  nor2x05_u U755 ( .A(n657), .B(n757), .Q(n1106) );
  nor2x05_u U756 ( .A(n658), .B(n667), .Q(n1101) );
  nor2x05_u U757 ( .A(n658), .B(n757), .Q(n1102) );
  nor2x05_u U758 ( .A(n657), .B(n666), .Q(n1103) );
  nor2x05_u U759 ( .A(n658), .B(n668), .Q(n1104) );
  nand2x05_u U760 ( .A(n1074), .B(\u_inst_reg/reg_array[31][0] ), .Q(n722) );
  nand3x05_u U761 ( .A(n734), .B(n733), .C(n732), .Q(n735) );
  invx05_u U762 ( .A(n761), .Q(n1064) );
  invx05_u U763 ( .A(n763), .Q(n1062) );
  nor2x05_u U764 ( .A(n667), .B(n622), .Q(n1070) );
  nor2x05_u U765 ( .A(n757), .B(n622), .Q(n1071) );
  nand2x05_u U766 ( .A(n665), .B(reg_addr[2]), .Q(n669) );
  nand2x1_u U767 ( .A(n633), .B(n632), .Q(n640) );
  nor2x05_u U768 ( .A(reg_addr[3]), .B(reg_addr[2]), .Q(n632) );
  invx05_u U769 ( .A(n667), .Q(n676) );
  invx05_u U770 ( .A(n666), .Q(n674) );
  nor2x05_u U771 ( .A(n692), .B(n757), .Q(n1128) );
  nor2x05_u U772 ( .A(n652), .B(n668), .Q(n1129) );
  nor2x05_u U773 ( .A(n692), .B(n667), .Q(n1130) );
  nand2x05_u U774 ( .A(n1143), .B(\u_inst_reg/reg_array[63][5] ), .Q(n971) );
  aoi22x05_u U775 ( .A(n1142), .B(\u_inst_reg/reg_array[60][5] ), .C(n1141), 
        .D(\u_inst_reg/reg_array[62][5] ), .Q(n972) );
  invx05_u U776 ( .A(n955), .Q(n965) );
  nand2x05_u U777 ( .A(n1143), .B(\u_inst_reg/reg_array[63][6] ), .Q(n921) );
  aoi22x05_u U778 ( .A(n1142), .B(\u_inst_reg/reg_array[60][6] ), .C(n1141), 
        .D(\u_inst_reg/reg_array[62][6] ), .Q(n922) );
  nand2x05_u U779 ( .A(n1143), .B(\u_inst_reg/reg_array[63][4] ), .Q(n1023) );
  aoi22x05_u U780 ( .A(n1142), .B(\u_inst_reg/reg_array[60][4] ), .C(n1141), 
        .D(\u_inst_reg/reg_array[62][4] ), .Q(n1024) );
  nand2x05_u U781 ( .A(n1143), .B(\u_inst_reg/reg_array[63][3] ), .Q(n1144) );
  aoi22x05_u U782 ( .A(n1142), .B(\u_inst_reg/reg_array[60][3] ), .C(n1141), 
        .D(\u_inst_reg/reg_array[62][3] ), .Q(n1145) );
  oai211x05_u U783 ( .A(n1124), .B(n599), .C(n1122), .D(n1121), .Q(n1151) );
  nand2x05_u U784 ( .A(n1143), .B(\u_inst_reg/reg_array[63][1] ), .Q(n871) );
  aoi22x05_u U785 ( .A(n1142), .B(\u_inst_reg/reg_array[60][1] ), .C(n1141), 
        .D(\u_inst_reg/reg_array[62][1] ), .Q(n872) );
  oai211x05_u U786 ( .A(n866), .B(n599), .C(n865), .D(n864), .Q(n877) );
  nand2x05_u U787 ( .A(n1143), .B(\u_inst_reg/reg_array[63][7] ), .Q(n822) );
  aoi22x05_u U788 ( .A(n1142), .B(\u_inst_reg/reg_array[60][7] ), .C(n1141), 
        .D(\u_inst_reg/reg_array[62][7] ), .Q(n823) );
  nand2x05_u U789 ( .A(n774), .B(\u_spi_reg_interface/spi_rx_vaild ), .Q(n1174) );
  nor2x05_u U790 ( .A(\u_spi_reg_interface/state [2]), .B(
        \u_spi_reg_interface/state [3]), .Q(n774) );
  invx05_u U791 ( .A(\u_spi_reg_interface/spi_rx_byte [7]), .Q(n1175) );
  aoi21x05_u U792 ( .A(n1158), .B(n1157), .C(n1188), .Q(n1159) );
  nand2x05_u U793 ( .A(n1156), .B(n1163), .Q(n1155) );
  nand2x05_u U794 ( .A(n1143), .B(\u_inst_reg/reg_array[63][0] ), .Q(n747) );
  aoi22x05_u U795 ( .A(n1142), .B(\u_inst_reg/reg_array[60][0] ), .C(n1141), 
        .D(\u_inst_reg/reg_array[62][0] ), .Q(n748) );
  and4x05_u U796 ( .A(n721), .B(n720), .C(n719), .D(n718), .Q(n740) );
  nor2ax05_u U797 ( .AN(n689), .B(n688), .Q(n690) );
  invx05_u U798 ( .A(n692), .Q(n693) );
  aoi22x05_u U799 ( .A(n1142), .B(\u_inst_reg/reg_array[60][2] ), .C(n1141), 
        .D(\u_inst_reg/reg_array[62][2] ), .Q(n615) );
  nand2x05_u U800 ( .A(\u_spi_reg_interface/state [2]), .B(n1183), .Q(n1168)
         );
  invx05_u U801 ( .A(\u_spi_reg_interface/byte_cnt ), .Q(n1171) );
  nor2x05_u U802 ( .A(\u_spi_reg_interface/state [2]), .B(n1183), .Q(
        \u_spi_reg_interface/N52 ) );
  nand2x05_u U803 ( .A(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [0]), 
        .B(n1176), .Q(n1188) );
  nand2x05_u U804 ( .A(n633), .B(n629), .Q(n630) );
  and2x05_u U805 ( .A(reg_addr[5]), .B(reg_addr[3]), .Q(n607) );
  invx05_u U806 ( .A(n686), .Q(n633) );
  nand2x05_u U807 ( .A(n628), .B(reg_addr[2]), .Q(n631) );
  invx05_u U808 ( .A(reg_addr[5]), .Q(n639) );
  nand2x05_u U809 ( .A(n1049), .B(control_o[82]), .Q(n680) );
  invx05_u U810 ( .A(reg_addr[2]), .Q(n664) );
  invx05_u U811 ( .A(reg_addr[1]), .Q(n605) );
  nor2x05_u U812 ( .A(n1056), .B(reg_addr[2]), .Q(n679) );
  nor2x05_u U813 ( .A(n686), .B(n631), .Q(n641) );
  nand4x05_u U814 ( .A(n936), .B(n935), .C(n934), .D(n933), .Q(n937) );
  nand2x05_u U815 ( .A(n1049), .B(control_o[85]), .Q(n933) );
  nand4x05_u U816 ( .A(n932), .B(n931), .C(n930), .D(n929), .Q(n938) );
  aoi21x05_u U817 ( .A(n954), .B(n953), .C(n952), .Q(n955) );
  and3x05_u U818 ( .A(n941), .B(n940), .C(n939), .Q(n954) );
  nor2x05_u U819 ( .A(n951), .B(n950), .Q(n953) );
  aoi21x05_u U820 ( .A(n904), .B(n903), .C(n902), .Q(n905) );
  nor2x05_u U821 ( .A(n901), .B(n900), .Q(n903) );
  nand4x05_u U822 ( .A(n886), .B(n885), .C(n884), .D(n883), .Q(n887) );
  nand2x05_u U823 ( .A(n1049), .B(control_o[86]), .Q(n883) );
  nand4x05_u U824 ( .A(n882), .B(n881), .C(n880), .D(n879), .Q(n888) );
  nand4x05_u U825 ( .A(n986), .B(n985), .C(n984), .D(n983), .Q(n987) );
  nand2x05_u U826 ( .A(n1049), .B(control_o[84]), .Q(n983) );
  nand4x05_u U827 ( .A(n982), .B(n981), .C(n980), .D(n979), .Q(n988) );
  and3x05_u U828 ( .A(n993), .B(n992), .C(n991), .Q(n1006) );
  nor2x05_u U829 ( .A(n1003), .B(n1002), .Q(n1005) );
  nand4x05_u U830 ( .A(n1053), .B(n1052), .C(n1051), .D(n1050), .Q(n1054) );
  nand2x05_u U831 ( .A(n1049), .B(control_o[83]), .Q(n1050) );
  nand4x05_u U832 ( .A(n1042), .B(n1041), .C(n1040), .D(n1039), .Q(n1055) );
  nand2x05_u U833 ( .A(n603), .B(n1079), .Q(n1098) );
  nand4x05_u U834 ( .A(n837), .B(n836), .C(n835), .D(n834), .Q(n838) );
  nand2x05_u U835 ( .A(n1049), .B(control_o[81]), .Q(n834) );
  nand4x05_u U836 ( .A(n843), .B(n842), .C(n841), .D(n840), .Q(n855) );
  nand2x05_u U837 ( .A(n1074), .B(\u_inst_reg/reg_array[31][1] ), .Q(n840) );
  nand4x05_u U838 ( .A(n795), .B(n794), .C(n793), .D(n792), .Q(n806) );
  nand2x05_u U839 ( .A(n1074), .B(\u_inst_reg/reg_array[31][7] ), .Q(n792) );
  nand4x05_u U840 ( .A(n789), .B(n788), .C(n787), .D(n786), .Q(n790) );
  nand2x05_u U841 ( .A(n1049), .B(control_o[87]), .Q(n786) );
  nand4x05_u U842 ( .A(n785), .B(n784), .C(n783), .D(n782), .Q(n791) );
  nand4x05_u U843 ( .A(n707), .B(n706), .C(n705), .D(n704), .Q(n713) );
  nand4x05_u U844 ( .A(n711), .B(n710), .C(n709), .D(n708), .Q(n712) );
  nand2x05_u U845 ( .A(n1048), .B(control_o[72]), .Q(n708) );
  nand3x1_u U846 ( .A(n639), .B(n638), .C(reg_addr[3]), .Q(n1056) );
  and4x05_u U847 ( .A(n717), .B(n716), .C(n715), .D(n714), .Q(n721) );
  aoi22x05_u U848 ( .A(n1104), .B(\u_inst_reg/reg_array[42][0] ), .C(n1103), 
        .D(\u_inst_reg/reg_array[47][0] ), .Q(n715) );
  aoi22x05_u U849 ( .A(n1102), .B(\u_inst_reg/reg_array[40][0] ), .C(n1101), 
        .D(\u_inst_reg/reg_array[41][0] ), .Q(n716) );
  nand4x05_u U850 ( .A(n725), .B(n724), .C(n723), .D(n722), .Q(n738) );
  nand4x05_u U851 ( .A(n729), .B(n728), .C(n727), .D(n726), .Q(n736) );
  nor2x05_u U852 ( .A(n652), .B(n666), .Q(n1126) );
  nand3x05_u U853 ( .A(n644), .B(n643), .C(n642), .Q(n645) );
  nand4x05_u U854 ( .A(n627), .B(n626), .C(n625), .D(n624), .Q(n651) );
  nand2x05_u U855 ( .A(n1074), .B(\u_inst_reg/reg_array[31][2] ), .Q(n624) );
  nor2x05_u U856 ( .A(n649), .B(n648), .Q(n1093) );
  nand2x05_u U857 ( .A(n647), .B(n658), .Q(n649) );
  nand2x05_u U858 ( .A(n652), .B(n657), .Q(n648) );
  invx05_u U859 ( .A(n659), .Q(n647) );
  aoi21x05_u U860 ( .A(n1061), .B(n757), .C(n621), .Q(n1094) );
  and4x05_u U861 ( .A(n663), .B(n662), .C(n661), .D(n660), .Q(n689) );
  nand3x05_u U862 ( .A(\u_spi_reg_interface/spi_rx_byte [6]), .B(
        \u_spi_reg_interface/spi_rx_byte [0]), .C(
        \u_spi_reg_interface/spi_rx_byte [1]), .Q(n697) );
  nand4x05_u U863 ( .A(\u_spi_reg_interface/spi_rx_byte [2]), .B(
        \u_spi_reg_interface/spi_rx_byte [3]), .C(
        \u_spi_reg_interface/spi_rx_byte [4]), .D(
        \u_spi_reg_interface/spi_rx_byte [5]), .Q(n698) );
  nand2x05_u U864 ( .A(n665), .B(n664), .Q(n758) );
  nand2x1_u U865 ( .A(n605), .B(n606), .Q(n757) );
  nor2x05_u U866 ( .A(n758), .B(n667), .Q(n1032) );
  nor2x05_u U867 ( .A(n758), .B(n668), .Q(n1034) );
  nor2x05_u U868 ( .A(n758), .B(n666), .Q(n1036) );
  nor2x05_u U869 ( .A(n669), .B(n757), .Q(n1038) );
  nor2x05_u U870 ( .A(n669), .B(n667), .Q(n1035) );
  nor2x05_u U871 ( .A(n669), .B(n668), .Q(n1037) );
  nor2x05_u U872 ( .A(n669), .B(n666), .Q(n1031) );
  nand2x05_u U873 ( .A(n679), .B(n674), .Q(n769) );
  nor2ax05_u U874 ( .AN(n675), .B(n640), .Q(n1087) );
  nand2x05_u U875 ( .A(n641), .B(n675), .Q(n762) );
  nand2x05_u U876 ( .A(n641), .B(n676), .Q(n761) );
  nand2x05_u U877 ( .A(n641), .B(n678), .Q(n764) );
  nand2x05_u U878 ( .A(n641), .B(n674), .Q(n763) );
  nand2x05_u U879 ( .A(\u_spi_reg_interface/u_spi_slave/r_SPI_CLK [1]), .B(
        n772), .Q(n773) );
  invx05_u U880 ( .A(\u_spi_reg_interface/u_spi_slave/r_SPI_CLK [0]), .Q(n772)
         );
  invx05_u U881 ( .A(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [2]), .Q(
        n1163) );
  nor2x05_u U882 ( .A(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [0]), 
        .B(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [1]), .Q(n1164) );
  invx05_u U883 ( .A(n773), .Q(n1177) );
  nand2x05_u U884 ( .A(n1178), .B(n1177), .Q(n1165) );
  invx05_u U885 ( .A(\u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count [2]), .Q(
        n760) );
  nor2x05_u U886 ( .A(n760), .B(n1153), .Q(n1178) );
  nand2x05_u U887 ( .A(\u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count [0]), 
        .B(\u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count [1]), .Q(n1153) );
  nor2ax05_u U888 ( .AN(\u_spi_reg_interface/spi_rx_vaild ), .B(n1168), .Q(
        \u_spi_reg_interface/N51 ) );
  nor3x05_u U889 ( .A(n758), .B(n757), .C(n1167), .Q(\u_inst_reg/N132 ) );
  nor2x05_u U890 ( .A(n775), .B(n1167), .Q(\u_inst_reg/N133 ) );
  invx05_u U891 ( .A(n1032), .Q(n775) );
  nor2x05_u U892 ( .A(n776), .B(n1167), .Q(\u_inst_reg/N134 ) );
  invx05_u U893 ( .A(n1034), .Q(n776) );
  nor2x05_u U894 ( .A(n777), .B(n1167), .Q(\u_inst_reg/N135 ) );
  invx05_u U895 ( .A(n1036), .Q(n777) );
  nor2x05_u U896 ( .A(n781), .B(n1167), .Q(\u_inst_reg/N136 ) );
  invx05_u U897 ( .A(n1038), .Q(n781) );
  nor2x05_u U898 ( .A(n778), .B(n1167), .Q(\u_inst_reg/N137 ) );
  invx05_u U899 ( .A(n1035), .Q(n778) );
  nor2x05_u U900 ( .A(n780), .B(n1167), .Q(\u_inst_reg/N138 ) );
  invx05_u U901 ( .A(n1037), .Q(n780) );
  nor2x05_u U902 ( .A(n779), .B(n1167), .Q(\u_inst_reg/N139 ) );
  invx05_u U903 ( .A(n1031), .Q(n779) );
  nor2x05_u U904 ( .A(n767), .B(n1167), .Q(\u_inst_reg/N141 ) );
  nor2x05_u U905 ( .A(n768), .B(n1167), .Q(\u_inst_reg/N142 ) );
  nor2x05_u U906 ( .A(n769), .B(n1167), .Q(\u_inst_reg/N143 ) );
  nor2x05_u U907 ( .A(n759), .B(n1167), .Q(\u_inst_reg/N144 ) );
  nor2x05_u U908 ( .A(n755), .B(n1167), .Q(\u_inst_reg/N145 ) );
  nor2x05_u U909 ( .A(n756), .B(n1167), .Q(\u_inst_reg/N146 ) );
  nor2x05_u U910 ( .A(n1060), .B(n1167), .Q(\u_inst_reg/N147 ) );
  nor2x05_u U911 ( .A(n765), .B(n1167), .Q(\u_inst_reg/N148 ) );
  invx05_u U912 ( .A(n601), .Q(n765) );
  nor2x05_u U913 ( .A(n771), .B(n1167), .Q(\u_inst_reg/N149 ) );
  invx05_u U914 ( .A(n1086), .Q(n771) );
  nor2x05_u U915 ( .A(n1058), .B(n1167), .Q(\u_inst_reg/N150 ) );
  nor2x05_u U916 ( .A(n770), .B(n1167), .Q(\u_inst_reg/N151 ) );
  invx05_u U917 ( .A(n1084), .Q(n770) );
  nor2x05_u U918 ( .A(n762), .B(n1167), .Q(\u_inst_reg/N152 ) );
  nor2x05_u U919 ( .A(n761), .B(n1167), .Q(\u_inst_reg/N153 ) );
  nor2x05_u U920 ( .A(n764), .B(n1167), .Q(\u_inst_reg/N154 ) );
  nand2x05_u U921 ( .A(n1176), .B(n773), .Q(n598) );
  invx05_u U922 ( .A(n978), .Q(\u_inst_reg/N721 ) );
  nand4x05_u U923 ( .A(n974), .B(n973), .C(n972), .D(n971), .Q(n975) );
  invx05_u U924 ( .A(n928), .Q(\u_inst_reg/N722 ) );
  nand4x05_u U925 ( .A(n924), .B(n923), .C(n922), .D(n921), .Q(n925) );
  invx05_u U926 ( .A(n1030), .Q(\u_inst_reg/N720 ) );
  nand4x05_u U927 ( .A(n1026), .B(n1025), .C(n1024), .D(n1023), .Q(n1027) );
  invx05_u U928 ( .A(n1152), .Q(\u_inst_reg/N719 ) );
  nand4x05_u U929 ( .A(n1147), .B(n1146), .C(n1145), .D(n1144), .Q(n1148) );
  invx05_u U930 ( .A(n878), .Q(\u_inst_reg/N717 ) );
  nand4x05_u U931 ( .A(n874), .B(n873), .C(n872), .D(n871), .Q(n875) );
  invx05_u U932 ( .A(n829), .Q(\u_inst_reg/N723 ) );
  nand4x05_u U933 ( .A(n825), .B(n824), .C(n823), .D(n822), .Q(n826) );
  aoi211x1_u U934 ( .A(n1172), .B(n1171), .C(n1170), .D(n1169), .Q(n1173) );
  nor2x05_u U935 ( .A(n1168), .B(n1167), .Q(n1169) );
  nor2ax05_u U936 ( .AN(n774), .B(n1175), .Q(n1185) );
  aoi21x05_u U937 ( .A(\u_spi_reg_interface/spi_tx_byte [7]), .B(n1162), .C(
        n1159), .Q(n1160) );
  and4x05_u U938 ( .A(n750), .B(n749), .C(n748), .D(n747), .Q(n751) );
  nand2ax05_u U939 ( .AN(n696), .B(n695), .Q(\u_inst_reg/N718 ) );
  nand2x05_u U940 ( .A(n619), .B(n618), .Q(n696) );
  aoi21x05_u U941 ( .A(n1179), .B(n1171), .C(n1172), .Q(n594) );
  nor2ax05_u U942 ( .AN(n1165), .B(SPI_SS), .Q(
        \u_spi_reg_interface/u_spi_slave/N93 ) );
  aoi211x05_u U943 ( .A(n1153), .B(n760), .C(n1166), .D(n1178), .Q(n1190) );
  nor2x05_u U944 ( .A(n1166), .B(
        \u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count [0]), .Q(n1192) );
  nor2ax05_u U945 ( .AN(\u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [5]), 
        .B(n1166), .Q(n1193) );
  nor2ax05_u U946 ( .AN(\u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [4]), 
        .B(n1166), .Q(n1194) );
  nor2ax05_u U947 ( .AN(\u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [2]), 
        .B(n1166), .Q(n1196) );
  nor2ax05_u U948 ( .AN(\u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [1]), 
        .B(n1166), .Q(n1197) );
  nor2ax05_u U949 ( .AN(\u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [0]), 
        .B(n1166), .Q(n1198) );
  nor2ax05_u U950 ( .AN(SPI_MOSI), .B(n1166), .Q(n1199) );
  and3x1_u U951 ( .A(n852), .B(n851), .C(n850), .Q(n602) );
  and3x1_u U952 ( .A(n1067), .B(n1066), .C(n1065), .Q(n603) );
  nand4x05_u U953 ( .A(n1091), .B(n1090), .C(n1089), .D(n1088), .Q(n1092) );
  nand2x05_u U954 ( .A(n1074), .B(\u_inst_reg/reg_array[31][6] ), .Q(n892) );
  nand2x05_u U955 ( .A(n1074), .B(\u_inst_reg/reg_array[31][5] ), .Q(n942) );
  nand2x05_u U956 ( .A(n1074), .B(\u_inst_reg/reg_array[31][3] ), .Q(n1075) );
  nand4x05_u U957 ( .A(n899), .B(n898), .C(n897), .D(n896), .Q(n900) );
  nand4x05_u U958 ( .A(n895), .B(n894), .C(n893), .D(n892), .Q(n901) );
  nand4x05_u U959 ( .A(n1078), .B(n1077), .C(n1076), .D(n1075), .Q(n1095) );
  invx05_u U960 ( .A(n755), .Q(n1045) );
  oai21x05_u U961 ( .A(n901), .B(n1094), .C(n1093), .Q(n902) );
  oai21x05_u U962 ( .A(n1003), .B(n1094), .C(n1093), .Q(n1004) );
  oai21x05_u U963 ( .A(n951), .B(n1094), .C(n1093), .Q(n952) );
  oai21x05_u U964 ( .A(n1095), .B(n1094), .C(n1093), .Q(n1096) );
  aoi21x05_u U965 ( .A(n1056), .B(n685), .C(n684), .Q(n687) );
  aoi21x05_u U966 ( .A(n1006), .B(n1005), .C(n1004), .Q(n1007) );
  invx05_u U967 ( .A(n1096), .Q(n1097) );
  nand4x05_u U968 ( .A(n833), .B(n832), .C(n831), .D(n830), .Q(n839) );
  invx05_u U969 ( .A(n905), .Q(n915) );
  invx05_u U970 ( .A(n1007), .Q(n1017) );
  oai21x05_u U971 ( .A(n1098), .B(n1092), .C(n1097), .Q(n1122) );
  oai211x05_u U972 ( .A(n1094), .B(n855), .C(n854), .D(n1093), .Q(n865) );
  nor2x05_u U973 ( .A(n613), .B(n666), .Q(n1143) );
  nor2ax1_u U974 ( .AN(reg_addr[4]), .B(n658), .Q(n1125) );
  nor2x05_u U975 ( .A(n700), .B(\u_spi_reg_interface/spi_rx_byte [7]), .Q(n701) );
  invx05_u U976 ( .A(reg_addr[0]), .Q(n606) );
  invx05_u U977 ( .A(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [1]), .Q(
        n1156) );
  nor2ax1_u U978 ( .AN(n702), .B(n701), .Q(n703) );
  nand2x05_u U979 ( .A(n677), .B(n674), .Q(n1060) );
  invx05_u U980 ( .A(n1150), .Q(n753) );
  nor2x05_u U981 ( .A(n703), .B(n1174), .Q(\u_spi_reg_interface/N45 ) );
  nor2x05_u U982 ( .A(n766), .B(n1167), .Q(\u_inst_reg/N140 ) );
  nor2x05_u U983 ( .A(n763), .B(n1167), .Q(\u_inst_reg/N155 ) );
  nor2ax05_u U984 ( .AN(\u_spi_reg_interface/u_spi_slave/r_Temp_RX_Byte [3]), 
        .B(n1166), .Q(n1195) );
  tohlx1_u U985 ( .TL(\u_spi_reg_interface/u_spi_slave/net828 ) );
  nand2x1_u U986 ( .A(n664), .B(reg_addr[5]), .Q(n622) );
  invx1_u U987 ( .A(n622), .Q(n621) );
  nand2x1_u U988 ( .A(n607), .B(n664), .Q(n658) );
  aoi22x05_u U989 ( .A(n600), .B(\u_inst_reg/reg_array[51][2] ), .C(n1125), 
        .D(\u_inst_reg/reg_array[56][2] ), .Q(n604) );
  aoi21cx05_u U990 ( .A(n1128), .B(\u_inst_reg/reg_array[52][2] ), .CN(n604), 
        .Q(n611) );
  aoi22x05_u U991 ( .A(n1130), .B(\u_inst_reg/reg_array[53][2] ), .C(n1129), 
        .D(\u_inst_reg/reg_array[50][2] ), .Q(n610) );
  aoi22x05_u U992 ( .A(n1132), .B(\u_inst_reg/reg_array[54][2] ), .C(n1131), 
        .D(\u_inst_reg/reg_array[55][2] ), .Q(n609) );
  invx1_u U993 ( .A(n1125), .Q(n612) );
  invx1_u U994 ( .A(n757), .Q(n675) );
  nand2x1_u U995 ( .A(n607), .B(reg_addr[2]), .Q(n657) );
  ao31x05_u U996 ( .A(n611), .B(n610), .C(n609), .D(n1133), .Q(n619) );
  aoi22x05_u U997 ( .A(n1138), .B(\u_inst_reg/reg_array[57][2] ), .C(n1137), 
        .D(\u_inst_reg/reg_array[59][2] ), .Q(n617) );
  aoi22x05_u U998 ( .A(n1140), .B(\u_inst_reg/reg_array[58][2] ), .C(n1139), 
        .D(\u_inst_reg/reg_array[61][2] ), .Q(n616) );
  and4x1_u U999 ( .A(n617), .B(n616), .C(n615), .D(n614), .Q(n618) );
  nand2x1_u U1000 ( .A(n633), .B(n620), .Q(n623) );
  invx1_u U1001 ( .A(n623), .Q(n1061) );
  nor2x1_u U1002 ( .A(n667), .B(n623), .Q(n1068) );
  aoi22x05_u U1003 ( .A(n1069), .B(\u_inst_reg/reg_array[30][2] ), .C(n1068), 
        .D(\u_inst_reg/reg_array[29][2] ), .Q(n627) );
  aoi22x05_u U1004 ( .A(n1071), .B(\u_inst_reg/reg_array[32][2] ), .C(n1070), 
        .D(\u_inst_reg/reg_array[33][2] ), .Q(n626) );
  aoi22x05_u U1005 ( .A(n1073), .B(\u_inst_reg/reg_array[34][2] ), .C(n1072), 
        .D(\u_inst_reg/reg_array[35][2] ), .Q(n625) );
  nor2x1_u U1006 ( .A(n623), .B(n666), .Q(n1074) );
  nor2x05_u U1007 ( .A(n628), .B(reg_addr[2]), .Q(n629) );
  nor2x1_u U1008 ( .A(n630), .B(n667), .Q(n1081) );
  nor2x1_u U1009 ( .A(n630), .B(n666), .Q(n1080) );
  aoi22x05_u U1010 ( .A(n1081), .B(\u_inst_reg/reg_array[25][2] ), .C(n1080), 
        .D(\u_inst_reg/reg_array[27][2] ), .Q(n637) );
  nor2x1_u U1011 ( .A(n630), .B(n668), .Q(n1082) );
  aoi22x05_u U1012 ( .A(n1083), .B(\u_inst_reg/reg_array[24][2] ), .C(n1082), 
        .D(\u_inst_reg/reg_array[26][2] ), .Q(n636) );
  nand4x1_u U1013 ( .A(n637), .B(n636), .C(n635), .D(n634), .Q(n646) );
  invx1_u U1014 ( .A(n1060), .Q(n990) );
  aoi22x05_u U1015 ( .A(n1062), .B(control_o[186]), .C(n1061), .D(
        \u_inst_reg/reg_array[28][2] ), .Q(n643) );
  invx1_u U1016 ( .A(n762), .Q(n1063) );
  aoi22x05_u U1017 ( .A(n1064), .B(control_o[170]), .C(n1063), .D(
        control_o[162]), .Q(n642) );
  oai211x1_u U1018 ( .A(n1094), .B(n651), .C(n650), .D(n1093), .Q(n691) );
  nor2x1_u U1019 ( .A(n652), .B(n667), .Q(n1100) );
  nor2x1_u U1020 ( .A(n652), .B(n757), .Q(n1099) );
  aoi22x05_u U1021 ( .A(n1106), .B(\u_inst_reg/reg_array[44][2] ), .C(n1105), 
        .D(\u_inst_reg/reg_array[45][2] ), .Q(n653) );
  aoi22x05_u U1022 ( .A(n1112), .B(\u_inst_reg/reg_array[46][2] ), .C(n1111), 
        .D(\u_inst_reg/reg_array[43][2] ), .Q(n662) );
  aoi22x05_u U1023 ( .A(n1114), .B(\u_inst_reg/reg_array[38][2] ), .C(n1113), 
        .D(\u_inst_reg/reg_array[37][2] ), .Q(n661) );
  aoi22x05_u U1024 ( .A(n1116), .B(\u_inst_reg/reg_array[39][2] ), .C(n1115), 
        .D(\u_inst_reg/reg_array[36][2] ), .Q(n660) );
  aoi22x05_u U1025 ( .A(n1032), .B(control_o[10]), .C(n1031), .D(control_o[58]), .Q(n673) );
  aoi22x05_u U1026 ( .A(n1034), .B(control_o[18]), .C(n1033), .D(control_o[2]), 
        .Q(n672) );
  aoi22x05_u U1027 ( .A(n1036), .B(control_o[26]), .C(n1035), .D(control_o[42]), .Q(n671) );
  aoi22x05_u U1028 ( .A(n1038), .B(control_o[34]), .C(n1037), .D(control_o[50]), .Q(n670) );
  nand4x1_u U1029 ( .A(n673), .B(n672), .C(n671), .D(n670), .Q(n685) );
  nand2x05_u U1030 ( .A(n675), .B(n677), .Q(n759) );
  aoi22x05_u U1031 ( .A(n1044), .B(control_o[90]), .C(n1043), .D(control_o[98]), .Q(n683) );
  nand2x05_u U1032 ( .A(n679), .B(n675), .Q(n766) );
  nand2x05_u U1033 ( .A(n676), .B(n677), .Q(n755) );
  nand2x05_u U1034 ( .A(n679), .B(n676), .Q(n767) );
  nand2x05_u U1035 ( .A(n678), .B(n677), .Q(n756) );
  nand2x05_u U1036 ( .A(n679), .B(n678), .Q(n768) );
  nand4x1_u U1037 ( .A(n683), .B(n682), .C(n681), .D(n680), .Q(n684) );
  nand3x1_u U1038 ( .A(n1093), .B(n1094), .C(n686), .Q(n1123) );
  nor2x1_u U1039 ( .A(n687), .B(n599), .Q(n688) );
  nand2x1_u U1040 ( .A(n691), .B(n690), .Q(n694) );
  nand2x1_u U1041 ( .A(n694), .B(n1150), .Q(n695) );
  oai21x05_u U1042 ( .A(n698), .B(n697), .C(
        \u_spi_reg_interface/spi_rx_byte [7]), .Q(n702) );
  or4x1_u U1043 ( .A(\u_spi_reg_interface/spi_rx_byte [2]), .B(
        \u_spi_reg_interface/spi_rx_byte [3]), .C(
        \u_spi_reg_interface/spi_rx_byte [4]), .D(
        \u_spi_reg_interface/spi_rx_byte [5]), .Q(n699) );
  nor4x2_u U1044 ( .A(n699), .B(\u_spi_reg_interface/spi_rx_byte [1]), .C(
        \u_spi_reg_interface/spi_rx_byte [6]), .D(
        \u_spi_reg_interface/spi_rx_byte [0]), .Q(n700) );
  aoi22x05_u U1045 ( .A(n1032), .B(control_o[8]), .C(n1031), .D(control_o[56]), 
        .Q(n707) );
  aoi22x05_u U1046 ( .A(n1034), .B(control_o[16]), .C(n1033), .D(control_o[0]), 
        .Q(n706) );
  aoi22x05_u U1047 ( .A(n1036), .B(control_o[24]), .C(n1035), .D(control_o[40]), .Q(n705) );
  aoi22x05_u U1048 ( .A(n1038), .B(control_o[32]), .C(n1037), .D(control_o[48]), .Q(n704) );
  aoi22x05_u U1049 ( .A(n1044), .B(control_o[88]), .C(n1046), .D(control_o[64]), .Q(n711) );
  aoi22x05_u U1050 ( .A(n1043), .B(control_o[96]), .C(n1047), .D(
        control_o[112]), .Q(n710) );
  aoi22x05_u U1051 ( .A(n1049), .B(control_o[80]), .C(n1045), .D(
        control_o[104]), .Q(n709) );
  aoi21x05_u U1052 ( .A(n1056), .B(n713), .C(n712), .Q(n741) );
  aoi22x05_u U1053 ( .A(n1106), .B(\u_inst_reg/reg_array[44][0] ), .C(n1105), 
        .D(\u_inst_reg/reg_array[45][0] ), .Q(n714) );
  aoi22x05_u U1054 ( .A(n1112), .B(\u_inst_reg/reg_array[46][0] ), .C(n1111), 
        .D(\u_inst_reg/reg_array[43][0] ), .Q(n720) );
  aoi22x05_u U1055 ( .A(n1114), .B(\u_inst_reg/reg_array[38][0] ), .C(n1113), 
        .D(\u_inst_reg/reg_array[37][0] ), .Q(n719) );
  aoi22x05_u U1056 ( .A(n1116), .B(\u_inst_reg/reg_array[39][0] ), .C(n1115), 
        .D(\u_inst_reg/reg_array[36][0] ), .Q(n718) );
  aoi22x05_u U1057 ( .A(n1069), .B(\u_inst_reg/reg_array[30][0] ), .C(n1068), 
        .D(\u_inst_reg/reg_array[29][0] ), .Q(n725) );
  aoi22x05_u U1058 ( .A(n1071), .B(\u_inst_reg/reg_array[32][0] ), .C(n1070), 
        .D(\u_inst_reg/reg_array[33][0] ), .Q(n724) );
  aoi22x05_u U1059 ( .A(n1073), .B(\u_inst_reg/reg_array[34][0] ), .C(n1072), 
        .D(\u_inst_reg/reg_array[35][0] ), .Q(n723) );
  aoi22x05_u U1060 ( .A(n1081), .B(\u_inst_reg/reg_array[25][0] ), .C(n1080), 
        .D(\u_inst_reg/reg_array[27][0] ), .Q(n729) );
  aoi22x05_u U1061 ( .A(n1083), .B(\u_inst_reg/reg_array[24][0] ), .C(n1082), 
        .D(\u_inst_reg/reg_array[26][0] ), .Q(n728) );
  aoi22x05_u U1062 ( .A(n601), .B(control_o[128]), .C(n1086), .D(
        control_o[136]), .Q(n726) );
  invx05_u U1063 ( .A(control_o[120]), .Q(n731) );
  invx05_u U1064 ( .A(control_o[144]), .Q(n730) );
  oa22x05_u U1065 ( .A(n1060), .B(n731), .C(n1058), .D(n730), .Q(n734) );
  or3x1_u U1066 ( .A(n738), .B(n736), .C(n735), .Q(n737) );
  oai211x1_u U1067 ( .A(n1094), .B(n738), .C(n737), .D(n1093), .Q(n739) );
  oai211x1_u U1068 ( .A(n741), .B(n599), .C(n740), .D(n739), .Q(n742) );
  invx1_u U1069 ( .A(n742), .Q(n754) );
  aoi22x05_u U1070 ( .A(n600), .B(\u_inst_reg/reg_array[51][0] ), .C(n1125), 
        .D(\u_inst_reg/reg_array[56][0] ), .Q(n743) );
  aoi21cx05_u U1071 ( .A(n1128), .B(\u_inst_reg/reg_array[52][0] ), .CN(n743), 
        .Q(n746) );
  aoi22x05_u U1072 ( .A(n1130), .B(\u_inst_reg/reg_array[53][0] ), .C(n1129), 
        .D(\u_inst_reg/reg_array[50][0] ), .Q(n745) );
  aoi22x05_u U1073 ( .A(n1132), .B(\u_inst_reg/reg_array[54][0] ), .C(n1131), 
        .D(\u_inst_reg/reg_array[55][0] ), .Q(n744) );
  ao31x05_u U1074 ( .A(n746), .B(n745), .C(n744), .D(n1133), .Q(n752) );
  aoi22x05_u U1075 ( .A(n1138), .B(\u_inst_reg/reg_array[57][0] ), .C(n1137), 
        .D(\u_inst_reg/reg_array[59][0] ), .Q(n750) );
  aoi22x05_u U1076 ( .A(n1140), .B(\u_inst_reg/reg_array[58][0] ), .C(n1139), 
        .D(\u_inst_reg/reg_array[61][0] ), .Q(n749) );
  oai211x1_u U1077 ( .A(n754), .B(n753), .C(n752), .D(n751), .Q(
        \u_inst_reg/N716 ) );
  nand3x1_u U1078 ( .A(\u_spi_reg_interface/N45 ), .B(
        \u_spi_reg_interface/spi_rx_byte [6]), .C(n1175), .Q(n1179) );
  nor2ax05_u U1079 ( .AN(\u_spi_reg_interface/N52 ), .B(
        \u_spi_reg_interface/spi_tx_busy ), .Q(n1172) );
  invx05_u U1080 ( .A(control_o[147]), .Q(n1057) );
  invx05_u U1081 ( .A(control_o[123]), .Q(n1059) );
  invx05_u U1082 ( .A(control_o[121]), .Q(n849) );
  bufx1_u U1083 ( .A(n1182), .Q(n1180) );
  bufx1_u U1084 ( .A(rst_n), .Q(n1181) );
  nor2ax05_u U1085 ( .AN(n774), .B(\u_spi_reg_interface/spi_rx_byte [7]), .Q(
        n1184) );
  oai21x05_u U1086 ( .A(\u_spi_reg_interface/u_spi_slave/r_SPI_CLK [1]), .B(
        n772), .C(n1176), .Q(n597) );
  bufx1_u U1087 ( .A(rst_n), .Q(n1182) );
  nor2ax2_u U1088 ( .AN(\u_spi_reg_interface/u_spi_slave/r_SPI_MISO_Bit ), .B(
        SPI_SS), .Q(SPI_MISO) );
  aoi22x05_u U1089 ( .A(n1032), .B(control_o[15]), .C(n1031), .D(control_o[63]), .Q(n785) );
  aoi22x05_u U1090 ( .A(n1034), .B(control_o[23]), .C(n1033), .D(control_o[7]), 
        .Q(n784) );
  aoi22x05_u U1091 ( .A(n1036), .B(control_o[31]), .C(n1035), .D(control_o[47]), .Q(n783) );
  aoi22x05_u U1092 ( .A(n1038), .B(control_o[39]), .C(n1037), .D(control_o[55]), .Q(n782) );
  aoi22x05_u U1093 ( .A(n1044), .B(control_o[95]), .C(n1043), .D(
        control_o[103]), .Q(n789) );
  aoi22x05_u U1094 ( .A(n1046), .B(control_o[71]), .C(n1045), .D(
        control_o[111]), .Q(n788) );
  aoi22x05_u U1095 ( .A(n1048), .B(control_o[79]), .C(n1047), .D(
        control_o[119]), .Q(n787) );
  aoi21x05_u U1096 ( .A(n1056), .B(n791), .C(n790), .Q(n817) );
  aoi22x05_u U1097 ( .A(n1069), .B(\u_inst_reg/reg_array[30][7] ), .C(n1068), 
        .D(\u_inst_reg/reg_array[29][7] ), .Q(n795) );
  aoi22x05_u U1098 ( .A(n1071), .B(\u_inst_reg/reg_array[32][7] ), .C(n1070), 
        .D(\u_inst_reg/reg_array[33][7] ), .Q(n794) );
  aoi22x05_u U1099 ( .A(n1073), .B(\u_inst_reg/reg_array[34][7] ), .C(n1072), 
        .D(\u_inst_reg/reg_array[35][7] ), .Q(n793) );
  aoi22x05_u U1100 ( .A(n1081), .B(\u_inst_reg/reg_array[25][7] ), .C(n1080), 
        .D(\u_inst_reg/reg_array[27][7] ), .Q(n799) );
  nand4x1_u U1101 ( .A(n799), .B(n798), .C(n797), .D(n796), .Q(n804) );
  aoi22x05_u U1102 ( .A(n1062), .B(control_o[191]), .C(n1061), .D(
        \u_inst_reg/reg_array[28][7] ), .Q(n801) );
  aoi22x05_u U1103 ( .A(n1064), .B(control_o[175]), .C(n1063), .D(
        control_o[167]), .Q(n800) );
  nand3x1_u U1104 ( .A(n802), .B(n801), .C(n800), .Q(n803) );
  or3x1_u U1105 ( .A(n806), .B(n804), .C(n803), .Q(n805) );
  oai211x1_u U1106 ( .A(n1094), .B(n806), .C(n805), .D(n1093), .Q(n816) );
  aoi22x05_u U1107 ( .A(n1100), .B(\u_inst_reg/reg_array[49][7] ), .C(n1099), 
        .D(\u_inst_reg/reg_array[48][7] ), .Q(n810) );
  aoi22x05_u U1108 ( .A(n1102), .B(\u_inst_reg/reg_array[40][7] ), .C(n1101), 
        .D(\u_inst_reg/reg_array[41][7] ), .Q(n809) );
  aoi22x05_u U1109 ( .A(n1104), .B(\u_inst_reg/reg_array[42][7] ), .C(n1103), 
        .D(\u_inst_reg/reg_array[47][7] ), .Q(n808) );
  aoi22x05_u U1110 ( .A(n1106), .B(\u_inst_reg/reg_array[44][7] ), .C(n1105), 
        .D(\u_inst_reg/reg_array[45][7] ), .Q(n807) );
  and4x05_u U1111 ( .A(n810), .B(n809), .C(n808), .D(n807), .Q(n814) );
  aoi22x05_u U1112 ( .A(n1112), .B(\u_inst_reg/reg_array[46][7] ), .C(n1111), 
        .D(\u_inst_reg/reg_array[43][7] ), .Q(n813) );
  aoi22x05_u U1113 ( .A(n1114), .B(\u_inst_reg/reg_array[38][7] ), .C(n1113), 
        .D(\u_inst_reg/reg_array[37][7] ), .Q(n812) );
  aoi22x05_u U1114 ( .A(n1116), .B(\u_inst_reg/reg_array[39][7] ), .C(n1115), 
        .D(\u_inst_reg/reg_array[36][7] ), .Q(n811) );
  and4x05_u U1115 ( .A(n814), .B(n813), .C(n812), .D(n811), .Q(n815) );
  oai211x1_u U1116 ( .A(n817), .B(n599), .C(n816), .D(n815), .Q(n828) );
  aoi22x05_u U1117 ( .A(n600), .B(\u_inst_reg/reg_array[51][7] ), .C(n1125), 
        .D(\u_inst_reg/reg_array[56][7] ), .Q(n818) );
  aoi21cx05_u U1118 ( .A(n1128), .B(\u_inst_reg/reg_array[52][7] ), .CN(n818), 
        .Q(n821) );
  aoi22x05_u U1119 ( .A(n1130), .B(\u_inst_reg/reg_array[53][7] ), .C(n1129), 
        .D(\u_inst_reg/reg_array[50][7] ), .Q(n820) );
  aoi22x05_u U1120 ( .A(n1132), .B(\u_inst_reg/reg_array[54][7] ), .C(n1131), 
        .D(\u_inst_reg/reg_array[55][7] ), .Q(n819) );
  aoi31x05_u U1121 ( .A(n821), .B(n820), .C(n819), .D(n1133), .Q(n827) );
  aoi22x05_u U1122 ( .A(n1138), .B(\u_inst_reg/reg_array[57][7] ), .C(n1137), 
        .D(\u_inst_reg/reg_array[59][7] ), .Q(n825) );
  aoi22x05_u U1123 ( .A(n1140), .B(\u_inst_reg/reg_array[58][7] ), .C(n1139), 
        .D(\u_inst_reg/reg_array[61][7] ), .Q(n824) );
  aoi211x1_u U1124 ( .A(n828), .B(n1150), .C(n827), .D(n826), .Q(n829) );
  aoi22x05_u U1125 ( .A(n1032), .B(control_o[9]), .C(n1031), .D(control_o[57]), 
        .Q(n833) );
  aoi22x05_u U1126 ( .A(n1034), .B(control_o[17]), .C(n1033), .D(control_o[1]), 
        .Q(n832) );
  aoi22x05_u U1127 ( .A(n1036), .B(control_o[25]), .C(n1035), .D(control_o[41]), .Q(n831) );
  aoi22x05_u U1128 ( .A(n1038), .B(control_o[33]), .C(n1037), .D(control_o[49]), .Q(n830) );
  aoi22x05_u U1129 ( .A(n1044), .B(control_o[89]), .C(n1043), .D(control_o[97]), .Q(n837) );
  aoi21x05_u U1130 ( .A(n1056), .B(n839), .C(n838), .Q(n866) );
  aoi22x05_u U1131 ( .A(n1069), .B(\u_inst_reg/reg_array[30][1] ), .C(n1068), 
        .D(\u_inst_reg/reg_array[29][1] ), .Q(n843) );
  aoi22x05_u U1132 ( .A(n1071), .B(\u_inst_reg/reg_array[32][1] ), .C(n1070), 
        .D(\u_inst_reg/reg_array[33][1] ), .Q(n842) );
  aoi22x05_u U1133 ( .A(n1073), .B(\u_inst_reg/reg_array[34][1] ), .C(n1072), 
        .D(\u_inst_reg/reg_array[35][1] ), .Q(n841) );
  aoi22x05_u U1134 ( .A(n1081), .B(\u_inst_reg/reg_array[25][1] ), .C(n1080), 
        .D(\u_inst_reg/reg_array[27][1] ), .Q(n847) );
  aoi22x05_u U1135 ( .A(n1082), .B(\u_inst_reg/reg_array[26][1] ), .C(n1083), 
        .D(\u_inst_reg/reg_array[24][1] ), .Q(n845) );
  nand4x1_u U1136 ( .A(n847), .B(n846), .C(n845), .D(n844), .Q(n853) );
  oa22x1_u U1137 ( .A(n1060), .B(n849), .C(n1058), .D(n848), .Q(n852) );
  nand3abx1_u U1138 ( .AN(n855), .BN(n853), .C(n602), .Q(n854) );
  aoi22x05_u U1139 ( .A(n1100), .B(\u_inst_reg/reg_array[49][1] ), .C(n1099), 
        .D(\u_inst_reg/reg_array[48][1] ), .Q(n859) );
  aoi22x05_u U1140 ( .A(n1102), .B(\u_inst_reg/reg_array[40][1] ), .C(n1101), 
        .D(\u_inst_reg/reg_array[41][1] ), .Q(n858) );
  aoi22x05_u U1141 ( .A(n1104), .B(\u_inst_reg/reg_array[42][1] ), .C(n1103), 
        .D(\u_inst_reg/reg_array[47][1] ), .Q(n857) );
  aoi22x05_u U1142 ( .A(n1106), .B(\u_inst_reg/reg_array[44][1] ), .C(n1105), 
        .D(\u_inst_reg/reg_array[45][1] ), .Q(n856) );
  and4x05_u U1143 ( .A(n859), .B(n858), .C(n857), .D(n856), .Q(n863) );
  aoi22x05_u U1144 ( .A(n1112), .B(\u_inst_reg/reg_array[46][1] ), .C(n1111), 
        .D(\u_inst_reg/reg_array[43][1] ), .Q(n862) );
  aoi22x05_u U1145 ( .A(n1114), .B(\u_inst_reg/reg_array[38][1] ), .C(n1113), 
        .D(\u_inst_reg/reg_array[37][1] ), .Q(n861) );
  aoi22x05_u U1146 ( .A(n1116), .B(\u_inst_reg/reg_array[39][1] ), .C(n1115), 
        .D(\u_inst_reg/reg_array[36][1] ), .Q(n860) );
  and4x05_u U1147 ( .A(n863), .B(n862), .C(n861), .D(n860), .Q(n864) );
  aoi22x05_u U1148 ( .A(n600), .B(\u_inst_reg/reg_array[51][1] ), .C(n1125), 
        .D(\u_inst_reg/reg_array[56][1] ), .Q(n867) );
  aoi21cx05_u U1149 ( .A(n1128), .B(\u_inst_reg/reg_array[52][1] ), .CN(n867), 
        .Q(n870) );
  aoi22x05_u U1150 ( .A(n1130), .B(\u_inst_reg/reg_array[53][1] ), .C(n1129), 
        .D(\u_inst_reg/reg_array[50][1] ), .Q(n869) );
  aoi22x05_u U1151 ( .A(n1132), .B(\u_inst_reg/reg_array[54][1] ), .C(n1131), 
        .D(\u_inst_reg/reg_array[55][1] ), .Q(n868) );
  aoi31x05_u U1152 ( .A(n870), .B(n869), .C(n868), .D(n1133), .Q(n876) );
  aoi22x05_u U1153 ( .A(n1138), .B(\u_inst_reg/reg_array[57][1] ), .C(n1137), 
        .D(\u_inst_reg/reg_array[59][1] ), .Q(n874) );
  aoi22x05_u U1154 ( .A(n1140), .B(\u_inst_reg/reg_array[58][1] ), .C(n1139), 
        .D(\u_inst_reg/reg_array[61][1] ), .Q(n873) );
  aoi22x05_u U1155 ( .A(n1032), .B(control_o[14]), .C(n1031), .D(control_o[62]), .Q(n882) );
  aoi22x05_u U1156 ( .A(n1034), .B(control_o[22]), .C(n1033), .D(control_o[6]), 
        .Q(n881) );
  aoi22x05_u U1157 ( .A(n1036), .B(control_o[30]), .C(n1035), .D(control_o[46]), .Q(n880) );
  aoi22x05_u U1158 ( .A(n1038), .B(control_o[38]), .C(n1037), .D(control_o[54]), .Q(n879) );
  aoi22x05_u U1159 ( .A(n1044), .B(control_o[94]), .C(n1043), .D(
        control_o[102]), .Q(n886) );
  aoi22x05_u U1160 ( .A(n1046), .B(control_o[70]), .C(n1045), .D(
        control_o[110]), .Q(n885) );
  aoi22x05_u U1161 ( .A(n1048), .B(control_o[78]), .C(n1047), .D(
        control_o[118]), .Q(n884) );
  aoi21x05_u U1162 ( .A(n1056), .B(n888), .C(n887), .Q(n916) );
  aoi22x05_u U1163 ( .A(control_o[190]), .B(n1062), .C(n1061), .D(
        \u_inst_reg/reg_array[28][6] ), .Q(n890) );
  and3x1_u U1164 ( .A(n891), .B(n890), .C(n889), .Q(n904) );
  aoi22x05_u U1165 ( .A(n1069), .B(\u_inst_reg/reg_array[30][6] ), .C(n1068), 
        .D(\u_inst_reg/reg_array[29][6] ), .Q(n895) );
  aoi22x05_u U1166 ( .A(n1071), .B(\u_inst_reg/reg_array[32][6] ), .C(n1070), 
        .D(\u_inst_reg/reg_array[33][6] ), .Q(n894) );
  aoi22x05_u U1167 ( .A(n1073), .B(\u_inst_reg/reg_array[34][6] ), .C(n1072), 
        .D(\u_inst_reg/reg_array[35][6] ), .Q(n893) );
  aoi22x05_u U1168 ( .A(n1081), .B(\u_inst_reg/reg_array[25][6] ), .C(n1080), 
        .D(\u_inst_reg/reg_array[27][6] ), .Q(n899) );
  aoi22x05_u U1169 ( .A(n1083), .B(\u_inst_reg/reg_array[24][6] ), .C(n1082), 
        .D(\u_inst_reg/reg_array[26][6] ), .Q(n898) );
  aoi22x05_u U1170 ( .A(n601), .B(control_o[134]), .C(n1086), .D(
        control_o[142]), .Q(n896) );
  aoi22x05_u U1171 ( .A(n1100), .B(\u_inst_reg/reg_array[49][6] ), .C(n1099), 
        .D(\u_inst_reg/reg_array[48][6] ), .Q(n909) );
  aoi22x05_u U1172 ( .A(n1102), .B(\u_inst_reg/reg_array[40][6] ), .C(n1101), 
        .D(\u_inst_reg/reg_array[41][6] ), .Q(n908) );
  aoi22x05_u U1173 ( .A(n1104), .B(\u_inst_reg/reg_array[42][6] ), .C(n1103), 
        .D(\u_inst_reg/reg_array[47][6] ), .Q(n907) );
  aoi22x05_u U1174 ( .A(n1106), .B(\u_inst_reg/reg_array[44][6] ), .C(n1105), 
        .D(\u_inst_reg/reg_array[45][6] ), .Q(n906) );
  and4x05_u U1175 ( .A(n909), .B(n908), .C(n907), .D(n906), .Q(n913) );
  aoi22x05_u U1176 ( .A(n1112), .B(\u_inst_reg/reg_array[46][6] ), .C(n1111), 
        .D(\u_inst_reg/reg_array[43][6] ), .Q(n912) );
  aoi22x05_u U1177 ( .A(n1114), .B(\u_inst_reg/reg_array[38][6] ), .C(n1113), 
        .D(\u_inst_reg/reg_array[37][6] ), .Q(n911) );
  aoi22x05_u U1178 ( .A(n1116), .B(\u_inst_reg/reg_array[39][6] ), .C(n1115), 
        .D(\u_inst_reg/reg_array[36][6] ), .Q(n910) );
  and4x05_u U1179 ( .A(n913), .B(n912), .C(n911), .D(n910), .Q(n914) );
  oai211x1_u U1180 ( .A(n916), .B(n599), .C(n915), .D(n914), .Q(n927) );
  aoi22x05_u U1181 ( .A(n600), .B(\u_inst_reg/reg_array[51][6] ), .C(n1125), 
        .D(\u_inst_reg/reg_array[56][6] ), .Q(n917) );
  aoi21cx05_u U1182 ( .A(n1128), .B(\u_inst_reg/reg_array[52][6] ), .CN(n917), 
        .Q(n920) );
  aoi22x05_u U1183 ( .A(n1130), .B(\u_inst_reg/reg_array[53][6] ), .C(n1129), 
        .D(\u_inst_reg/reg_array[50][6] ), .Q(n919) );
  aoi22x05_u U1184 ( .A(n1132), .B(\u_inst_reg/reg_array[54][6] ), .C(n1131), 
        .D(\u_inst_reg/reg_array[55][6] ), .Q(n918) );
  aoi31x05_u U1185 ( .A(n920), .B(n919), .C(n918), .D(n1133), .Q(n926) );
  aoi22x05_u U1186 ( .A(n1138), .B(\u_inst_reg/reg_array[57][6] ), .C(n1137), 
        .D(\u_inst_reg/reg_array[59][6] ), .Q(n924) );
  aoi22x05_u U1187 ( .A(n1140), .B(\u_inst_reg/reg_array[58][6] ), .C(n1139), 
        .D(\u_inst_reg/reg_array[61][6] ), .Q(n923) );
  aoi22x05_u U1188 ( .A(n1032), .B(control_o[13]), .C(n1031), .D(control_o[61]), .Q(n932) );
  aoi22x05_u U1189 ( .A(n1034), .B(control_o[21]), .C(n1033), .D(control_o[5]), 
        .Q(n931) );
  aoi22x05_u U1190 ( .A(n1036), .B(control_o[29]), .C(n1035), .D(control_o[45]), .Q(n930) );
  aoi22x05_u U1191 ( .A(n1038), .B(control_o[37]), .C(n1037), .D(control_o[53]), .Q(n929) );
  aoi22x05_u U1192 ( .A(n1044), .B(control_o[93]), .C(n1043), .D(
        control_o[101]), .Q(n936) );
  aoi22x05_u U1193 ( .A(n1046), .B(control_o[69]), .C(n1045), .D(
        control_o[109]), .Q(n935) );
  aoi22x05_u U1194 ( .A(n1048), .B(control_o[77]), .C(n1047), .D(
        control_o[117]), .Q(n934) );
  aoi21x05_u U1195 ( .A(n1056), .B(n938), .C(n937), .Q(n966) );
  aoi22x05_u U1196 ( .A(control_o[189]), .B(n1062), .C(n1061), .D(
        \u_inst_reg/reg_array[28][5] ), .Q(n940) );
  aoi22x05_u U1197 ( .A(n1064), .B(control_o[173]), .C(n1063), .D(
        control_o[165]), .Q(n939) );
  aoi22x05_u U1198 ( .A(n1069), .B(\u_inst_reg/reg_array[30][5] ), .C(n1068), 
        .D(\u_inst_reg/reg_array[29][5] ), .Q(n945) );
  aoi22x05_u U1199 ( .A(n1071), .B(\u_inst_reg/reg_array[32][5] ), .C(n1070), 
        .D(\u_inst_reg/reg_array[33][5] ), .Q(n944) );
  aoi22x05_u U1200 ( .A(n1073), .B(\u_inst_reg/reg_array[34][5] ), .C(n1072), 
        .D(\u_inst_reg/reg_array[35][5] ), .Q(n943) );
  aoi22x05_u U1201 ( .A(n1081), .B(\u_inst_reg/reg_array[25][5] ), .C(n1080), 
        .D(\u_inst_reg/reg_array[27][5] ), .Q(n949) );
  aoi22x05_u U1202 ( .A(n1083), .B(\u_inst_reg/reg_array[24][5] ), .C(n1082), 
        .D(\u_inst_reg/reg_array[26][5] ), .Q(n948) );
  aoi22x05_u U1203 ( .A(n601), .B(control_o[133]), .C(n1086), .D(
        control_o[141]), .Q(n946) );
  nand4x1_u U1204 ( .A(n949), .B(n948), .C(n947), .D(n946), .Q(n950) );
  aoi22x05_u U1205 ( .A(n1100), .B(\u_inst_reg/reg_array[49][5] ), .C(n1099), 
        .D(\u_inst_reg/reg_array[48][5] ), .Q(n959) );
  aoi22x05_u U1206 ( .A(n1102), .B(\u_inst_reg/reg_array[40][5] ), .C(n1101), 
        .D(\u_inst_reg/reg_array[41][5] ), .Q(n958) );
  aoi22x05_u U1207 ( .A(n1104), .B(\u_inst_reg/reg_array[42][5] ), .C(n1103), 
        .D(\u_inst_reg/reg_array[47][5] ), .Q(n957) );
  aoi22x05_u U1208 ( .A(n1106), .B(\u_inst_reg/reg_array[44][5] ), .C(n1105), 
        .D(\u_inst_reg/reg_array[45][5] ), .Q(n956) );
  and4x05_u U1209 ( .A(n959), .B(n958), .C(n957), .D(n956), .Q(n963) );
  aoi22x05_u U1210 ( .A(n1112), .B(\u_inst_reg/reg_array[46][5] ), .C(n1111), 
        .D(\u_inst_reg/reg_array[43][5] ), .Q(n962) );
  aoi22x05_u U1211 ( .A(n1114), .B(\u_inst_reg/reg_array[38][5] ), .C(n1113), 
        .D(\u_inst_reg/reg_array[37][5] ), .Q(n961) );
  aoi22x05_u U1212 ( .A(n1116), .B(\u_inst_reg/reg_array[39][5] ), .C(n1115), 
        .D(\u_inst_reg/reg_array[36][5] ), .Q(n960) );
  and4x05_u U1213 ( .A(n963), .B(n962), .C(n961), .D(n960), .Q(n964) );
  oai211x1_u U1214 ( .A(n966), .B(n599), .C(n965), .D(n964), .Q(n977) );
  aoi22x05_u U1215 ( .A(n600), .B(\u_inst_reg/reg_array[51][5] ), .C(n1125), 
        .D(\u_inst_reg/reg_array[56][5] ), .Q(n967) );
  aoi21cx05_u U1216 ( .A(n1128), .B(\u_inst_reg/reg_array[52][5] ), .CN(n967), 
        .Q(n970) );
  aoi22x05_u U1217 ( .A(n1130), .B(\u_inst_reg/reg_array[53][5] ), .C(n1129), 
        .D(\u_inst_reg/reg_array[50][5] ), .Q(n969) );
  aoi22x05_u U1218 ( .A(n1132), .B(\u_inst_reg/reg_array[54][5] ), .C(n1131), 
        .D(\u_inst_reg/reg_array[55][5] ), .Q(n968) );
  aoi31x05_u U1219 ( .A(n970), .B(n969), .C(n968), .D(n1133), .Q(n976) );
  aoi22x05_u U1220 ( .A(n1138), .B(\u_inst_reg/reg_array[57][5] ), .C(n1137), 
        .D(\u_inst_reg/reg_array[59][5] ), .Q(n974) );
  aoi22x05_u U1221 ( .A(n1140), .B(\u_inst_reg/reg_array[58][5] ), .C(n1139), 
        .D(\u_inst_reg/reg_array[61][5] ), .Q(n973) );
  aoi211x1_u U1222 ( .A(n977), .B(n1150), .C(n976), .D(n975), .Q(n978) );
  aoi22x05_u U1223 ( .A(n1032), .B(control_o[12]), .C(n1031), .D(control_o[60]), .Q(n982) );
  aoi22x05_u U1224 ( .A(n1034), .B(control_o[20]), .C(n1033), .D(control_o[4]), 
        .Q(n981) );
  aoi22x05_u U1225 ( .A(n1036), .B(control_o[28]), .C(n1035), .D(control_o[44]), .Q(n980) );
  aoi22x05_u U1226 ( .A(n1038), .B(control_o[36]), .C(n1037), .D(control_o[52]), .Q(n979) );
  aoi22x05_u U1227 ( .A(n1044), .B(control_o[92]), .C(n1043), .D(
        control_o[100]), .Q(n986) );
  aoi22x05_u U1228 ( .A(n1046), .B(control_o[68]), .C(n1045), .D(
        control_o[108]), .Q(n985) );
  aoi21x05_u U1229 ( .A(n1056), .B(n988), .C(n987), .Q(n1018) );
  aoi22x05_u U1230 ( .A(n1062), .B(control_o[188]), .C(n1061), .D(
        \u_inst_reg/reg_array[28][4] ), .Q(n992) );
  aoi22x05_u U1231 ( .A(n1069), .B(\u_inst_reg/reg_array[30][4] ), .C(n1068), 
        .D(\u_inst_reg/reg_array[29][4] ), .Q(n997) );
  aoi22x05_u U1232 ( .A(n1071), .B(\u_inst_reg/reg_array[32][4] ), .C(n1070), 
        .D(\u_inst_reg/reg_array[33][4] ), .Q(n996) );
  aoi22x05_u U1233 ( .A(n1073), .B(\u_inst_reg/reg_array[34][4] ), .C(n1072), 
        .D(\u_inst_reg/reg_array[35][4] ), .Q(n995) );
  aoi22x05_u U1234 ( .A(n1081), .B(\u_inst_reg/reg_array[25][4] ), .C(n1080), 
        .D(\u_inst_reg/reg_array[27][4] ), .Q(n1001) );
  aoi22x05_u U1235 ( .A(n1083), .B(\u_inst_reg/reg_array[24][4] ), .C(n1082), 
        .D(\u_inst_reg/reg_array[26][4] ), .Q(n1000) );
  aoi22x05_u U1236 ( .A(n601), .B(control_o[132]), .C(n1086), .D(
        control_o[140]), .Q(n998) );
  nand4x1_u U1237 ( .A(n1001), .B(n1000), .C(n999), .D(n998), .Q(n1002) );
  aoi22x05_u U1238 ( .A(n1100), .B(\u_inst_reg/reg_array[49][4] ), .C(n1099), 
        .D(\u_inst_reg/reg_array[48][4] ), .Q(n1011) );
  aoi22x05_u U1239 ( .A(n1102), .B(\u_inst_reg/reg_array[40][4] ), .C(n1101), 
        .D(\u_inst_reg/reg_array[41][4] ), .Q(n1010) );
  aoi22x05_u U1240 ( .A(n1104), .B(\u_inst_reg/reg_array[42][4] ), .C(n1103), 
        .D(\u_inst_reg/reg_array[47][4] ), .Q(n1009) );
  aoi22x05_u U1241 ( .A(n1106), .B(\u_inst_reg/reg_array[44][4] ), .C(n1105), 
        .D(\u_inst_reg/reg_array[45][4] ), .Q(n1008) );
  and4x05_u U1242 ( .A(n1011), .B(n1010), .C(n1009), .D(n1008), .Q(n1015) );
  aoi22x05_u U1243 ( .A(n1112), .B(\u_inst_reg/reg_array[46][4] ), .C(n1111), 
        .D(\u_inst_reg/reg_array[43][4] ), .Q(n1014) );
  aoi22x05_u U1244 ( .A(n1114), .B(\u_inst_reg/reg_array[38][4] ), .C(n1113), 
        .D(\u_inst_reg/reg_array[37][4] ), .Q(n1013) );
  aoi22x05_u U1245 ( .A(n1116), .B(\u_inst_reg/reg_array[39][4] ), .C(n1115), 
        .D(\u_inst_reg/reg_array[36][4] ), .Q(n1012) );
  and4x05_u U1246 ( .A(n1015), .B(n1014), .C(n1013), .D(n1012), .Q(n1016) );
  oai211x1_u U1247 ( .A(n1018), .B(n599), .C(n1017), .D(n1016), .Q(n1029) );
  aoi22x05_u U1248 ( .A(n600), .B(\u_inst_reg/reg_array[51][4] ), .C(n1125), 
        .D(\u_inst_reg/reg_array[56][4] ), .Q(n1019) );
  aoi21cx05_u U1249 ( .A(n1128), .B(\u_inst_reg/reg_array[52][4] ), .CN(n1019), 
        .Q(n1022) );
  aoi22x05_u U1250 ( .A(n1130), .B(\u_inst_reg/reg_array[53][4] ), .C(n1129), 
        .D(\u_inst_reg/reg_array[50][4] ), .Q(n1021) );
  aoi22x05_u U1251 ( .A(n1132), .B(\u_inst_reg/reg_array[54][4] ), .C(n1131), 
        .D(\u_inst_reg/reg_array[55][4] ), .Q(n1020) );
  aoi31x05_u U1252 ( .A(n1022), .B(n1021), .C(n1020), .D(n1133), .Q(n1028) );
  aoi22x05_u U1253 ( .A(n1138), .B(\u_inst_reg/reg_array[57][4] ), .C(n1137), 
        .D(\u_inst_reg/reg_array[59][4] ), .Q(n1026) );
  aoi22x05_u U1254 ( .A(n1140), .B(\u_inst_reg/reg_array[58][4] ), .C(n1139), 
        .D(\u_inst_reg/reg_array[61][4] ), .Q(n1025) );
  aoi22x05_u U1255 ( .A(n1032), .B(control_o[11]), .C(n1031), .D(control_o[59]), .Q(n1042) );
  aoi22x05_u U1256 ( .A(n1034), .B(control_o[19]), .C(n1033), .D(control_o[3]), 
        .Q(n1041) );
  aoi22x05_u U1257 ( .A(n1036), .B(control_o[27]), .C(n1035), .D(control_o[43]), .Q(n1040) );
  aoi22x05_u U1258 ( .A(n1038), .B(control_o[35]), .C(n1037), .D(control_o[51]), .Q(n1039) );
  aoi22x05_u U1259 ( .A(n1044), .B(control_o[91]), .C(n1043), .D(control_o[99]), .Q(n1053) );
  aoi21x05_u U1260 ( .A(n1056), .B(n1055), .C(n1054), .Q(n1124) );
  aoi22x05_u U1261 ( .A(control_o[187]), .B(n1062), .C(n1061), .D(
        \u_inst_reg/reg_array[28][3] ), .Q(n1066) );
  aoi22x05_u U1262 ( .A(n1064), .B(control_o[171]), .C(n1063), .D(
        control_o[163]), .Q(n1065) );
  aoi22x05_u U1263 ( .A(n1069), .B(\u_inst_reg/reg_array[30][3] ), .C(n1068), 
        .D(\u_inst_reg/reg_array[29][3] ), .Q(n1078) );
  aoi22x05_u U1264 ( .A(n1071), .B(\u_inst_reg/reg_array[32][3] ), .C(n1070), 
        .D(\u_inst_reg/reg_array[33][3] ), .Q(n1077) );
  aoi22x05_u U1265 ( .A(n1073), .B(\u_inst_reg/reg_array[34][3] ), .C(n1072), 
        .D(\u_inst_reg/reg_array[35][3] ), .Q(n1076) );
  invx05_u U1266 ( .A(n1095), .Q(n1079) );
  aoi22x05_u U1267 ( .A(n1081), .B(\u_inst_reg/reg_array[25][3] ), .C(n1080), 
        .D(\u_inst_reg/reg_array[27][3] ), .Q(n1091) );
  aoi22x05_u U1268 ( .A(n1083), .B(\u_inst_reg/reg_array[24][3] ), .C(n1082), 
        .D(\u_inst_reg/reg_array[26][3] ), .Q(n1090) );
  aoi22x05_u U1269 ( .A(n601), .B(control_o[131]), .C(n1086), .D(
        control_o[139]), .Q(n1088) );
  aoi22x05_u U1270 ( .A(n1100), .B(\u_inst_reg/reg_array[49][3] ), .C(n1099), 
        .D(\u_inst_reg/reg_array[48][3] ), .Q(n1110) );
  aoi22x05_u U1271 ( .A(n1102), .B(\u_inst_reg/reg_array[40][3] ), .C(n1101), 
        .D(\u_inst_reg/reg_array[41][3] ), .Q(n1109) );
  aoi22x05_u U1272 ( .A(n1104), .B(\u_inst_reg/reg_array[42][3] ), .C(n1103), 
        .D(\u_inst_reg/reg_array[47][3] ), .Q(n1108) );
  aoi22x05_u U1273 ( .A(n1106), .B(\u_inst_reg/reg_array[44][3] ), .C(n1105), 
        .D(\u_inst_reg/reg_array[45][3] ), .Q(n1107) );
  and4x05_u U1274 ( .A(n1110), .B(n1109), .C(n1108), .D(n1107), .Q(n1120) );
  aoi22x05_u U1275 ( .A(n1112), .B(\u_inst_reg/reg_array[46][3] ), .C(n1111), 
        .D(\u_inst_reg/reg_array[43][3] ), .Q(n1119) );
  aoi22x05_u U1276 ( .A(n1114), .B(\u_inst_reg/reg_array[38][3] ), .C(n1113), 
        .D(\u_inst_reg/reg_array[37][3] ), .Q(n1118) );
  aoi22x05_u U1277 ( .A(n1116), .B(\u_inst_reg/reg_array[39][3] ), .C(n1115), 
        .D(\u_inst_reg/reg_array[36][3] ), .Q(n1117) );
  and4x05_u U1278 ( .A(n1120), .B(n1119), .C(n1118), .D(n1117), .Q(n1121) );
  aoi22x05_u U1279 ( .A(n600), .B(\u_inst_reg/reg_array[51][3] ), .C(n1125), 
        .D(\u_inst_reg/reg_array[56][3] ), .Q(n1127) );
  aoi21cx05_u U1280 ( .A(n1128), .B(\u_inst_reg/reg_array[52][3] ), .CN(n1127), 
        .Q(n1136) );
  aoi22x05_u U1281 ( .A(n1130), .B(\u_inst_reg/reg_array[53][3] ), .C(n1129), 
        .D(\u_inst_reg/reg_array[50][3] ), .Q(n1135) );
  aoi22x05_u U1282 ( .A(n1132), .B(\u_inst_reg/reg_array[54][3] ), .C(n1131), 
        .D(\u_inst_reg/reg_array[55][3] ), .Q(n1134) );
  aoi31x05_u U1283 ( .A(n1136), .B(n1135), .C(n1134), .D(n1133), .Q(n1149) );
  aoi22x05_u U1284 ( .A(n1138), .B(\u_inst_reg/reg_array[57][3] ), .C(n1137), 
        .D(\u_inst_reg/reg_array[59][3] ), .Q(n1147) );
  aoi22x05_u U1285 ( .A(n1140), .B(\u_inst_reg/reg_array[58][3] ), .C(n1139), 
        .D(\u_inst_reg/reg_array[61][3] ), .Q(n1146) );
  mux2x05_u U1286 ( .D0(\u_spi_reg_interface/N51 ), .D1(n1168), .SL0(reg_wr_en), .Q(n595) );
  oa211x05_u U1287 ( .A(\u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count [0]), 
        .B(\u_spi_reg_interface/u_spi_slave/r_RX_Bit_Count [1]), .C(n1176), 
        .D(n1153), .Q(n1191) );
  mux2x05_u U1288 ( .D0(\u_spi_reg_interface/spi_tx_byte [1]), .D1(
        \u_spi_reg_interface/spi_tx_byte [5]), .SL0(
        \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [2]), .Q(n1154) );
  aoi32x05_u U1289 ( .A(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [2]), 
        .B(n1156), .C(\u_spi_reg_interface/spi_tx_byte [3]), .D(
        \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [1]), .E(n1154), .Q(
        n1161) );
  oai21x05_u U1290 ( .A(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [0]), 
        .B(n1155), .C(n1176), .Q(n1162) );
  oai221x05_u U1291 ( .A(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [1]), 
        .B(\u_spi_reg_interface/spi_tx_byte [0]), .C(n1156), .D(
        \u_spi_reg_interface/spi_tx_byte [2]), .E(n1163), .Q(n1158) );
  oai221x05_u U1292 ( .A(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [1]), 
        .B(\u_spi_reg_interface/spi_tx_byte [4]), .C(n1156), .D(
        \u_spi_reg_interface/spi_tx_byte [6]), .E(
        \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [2]), .Q(n1157) );
  oai31x05_u U1293 ( .A(n1166), .B(
        \u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [0]), .C(n1161), .D(
        n1160), .Q(n1189) );
  ao211x05_u U1294 ( .A(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [0]), 
        .B(\u_spi_reg_interface/u_spi_slave/r_TX_Bit_Count [1]), .C(n1166), 
        .D(n1164), .Q(n1187) );
  oai21cx05_u U1295 ( .A(n1164), .B(n1163), .CN(n1162), .Q(n1186) );
  nor3ax05_u U1296 ( .AN(n1182), .B(n1166), .C(n1165), .Q(
        \u_spi_reg_interface/u_spi_slave/N58 ) );
  invx1_u U1297 ( .A(n1179), .Q(n1170) );
  oai31x05_u U1298 ( .A(\u_spi_reg_interface/spi_rx_byte [6]), .B(n1175), .C(
        n1174), .D(n1173), .Q(\u_spi_reg_interface/N47 ) );
  oa211x05_u U1299 ( .A(\u_spi_reg_interface/spi_rx_vaild ), .B(n1178), .C(
        n1177), .D(n1176), .Q(n596) );
  oai21ax05_u U1300 ( .AN(reg_rd_en), .B(\u_spi_reg_interface/N52 ), .C(n1179), 
        .Q(n593) );
endmodule

